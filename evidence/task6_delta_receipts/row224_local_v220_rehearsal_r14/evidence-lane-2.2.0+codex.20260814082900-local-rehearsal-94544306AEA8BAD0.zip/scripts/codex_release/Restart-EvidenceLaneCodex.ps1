[CmdletBinding()]
param(
    [ValidateSet("Prepare", "Restart", "Relaunch")]
    [string]$Action = "Prepare",
    [Parameter(Mandatory = $true)]
    [string]$InstallReceipt,
    [string]$InstallReceiptSha256,
    [string]$LocalTestCommitReceipt,
    [string]$LocalTestCommitReceiptSha256,
    [string]$CodexConfig,
    [string]$LocalRecoveryRegistry,
    [string]$LocalRecoveryRegistrySha256,
    [Parameter(Mandatory = $true)]
    [string]$ProjectId,
    [Parameter(Mandatory = $true)]
    [string]$EvidenceSessionId,
    [Parameter(Mandatory = $true)]
    [string]$TaskId,
    [Parameter(Mandatory = $true)]
    [string]$HostSessionId,
    [int]$TargetProcessId,
    [string]$PreparationReceipt,
    [string]$PreparationReceiptSha256,
    [string]$ReceiptDirectory = "$env:USERPROFILE\EvidenceLanePV\installations\codex-v200\restart",
    [ValidateSet(
        "OpenAI.Codex_2p2nqsd0c76g0!App",
        "OpenAI.CodexBeta_2p2nqsd0c76g0!App"
    )]
    [string]$AppId,
    [switch]$ConfirmRestart
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$script:HostAppProfiles = [ordered]@{
    "OpenAI.Codex_2p2nqsd0c76g0!App" = [ordered]@{
        app_id = "OpenAI.Codex_2p2nqsd0c76g0!App"
        host_application = "CHATGPT_CODEX"
        desktop_release_channel = "CHATGPT_STABLE"
        available_surfaces = @("CHATGPT", "CODEX")
        governed_surface = "CODEX"
        chatgpt_surface_governed = $false
        package_name = "OpenAI.Codex"
        package_family_name = "OpenAI.Codex_2p2nqsd0c76g0"
        start_app_name = "ChatGPT"
        process_name = "ChatGPT.exe"
        manifest_executable = "app/ChatGPT.exe"
        root_path_pattern = '\\WindowsApps\\OpenAI\.Codex_[^\\]+\\app\\ChatGPT\.exe$'
        package_path_pattern = '\\WindowsApps\\OpenAI\.Codex_[^\\]+\\app\\'
    }
    "OpenAI.CodexBeta_2p2nqsd0c76g0!App" = [ordered]@{
        app_id = "OpenAI.CodexBeta_2p2nqsd0c76g0!App"
        host_application = "CHATGPT_BETA_CODEX"
        desktop_release_channel = "CHATGPT_BETA"
        available_surfaces = @("CHATGPT", "CODEX")
        governed_surface = "CODEX"
        chatgpt_surface_governed = $false
        package_name = "OpenAI.CodexBeta"
        package_family_name = "OpenAI.CodexBeta_2p2nqsd0c76g0"
        start_app_name = "ChatGPT (Beta)"
        process_name = "ChatGPT (Beta).exe"
        manifest_executable = "app/ChatGPT (Beta).exe"
        root_path_pattern = '\\WindowsApps\\OpenAI\.CodexBeta_[^\\]+\\app\\ChatGPT \(Beta\)\.exe$'
        package_path_pattern = '\\WindowsApps\\OpenAI\.CodexBeta_[^\\]+\\app\\'
    }
}

function Get-HostAppProfile([string]$ExactAppId) {
    if ([string]::IsNullOrWhiteSpace($ExactAppId) -or -not $script:HostAppProfiles.Contains($ExactAppId)) {
        throw "The exact Codex AppUserModelID is not in the approved stable/Beta allowlist."
    }
    return $script:HostAppProfiles[$ExactAppId]
}

function Get-Sha256([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Required sealed file is missing: $Path"
    }
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}

function Get-StringSha256([string]$Value) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha256.ComputeHash($bytes))).Replace("-", "")
    }
    finally {
        $sha256.Dispose()
    }
}

function ConvertTo-WindowsCommandLineArgument([AllowEmptyString()][string]$Value) {
    if ($null -eq $Value -or $Value.Length -eq 0) { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }

    $quoted = [System.Text.StringBuilder]::new()
    [void]$quoted.Append([char]34)
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq [char]92) {
            $backslashes += 1
            continue
        }
        if ($character -eq [char]34) {
            [void]$quoted.Append([string]::new([char]92, (2 * $backslashes) + 1))
            [void]$quoted.Append([char]34)
            $backslashes = 0
            continue
        }
        if ($backslashes -gt 0) {
            [void]$quoted.Append([string]::new([char]92, $backslashes))
            $backslashes = 0
        }
        [void]$quoted.Append($character)
    }
    if ($backslashes -gt 0) {
        [void]$quoted.Append([string]::new([char]92, 2 * $backslashes))
    }
    [void]$quoted.Append([char]34)
    return $quoted.ToString()
}

function Assert-CodexThreadProtocol([object]$HostProfile) {
    $protocolPath = "Registry::HKEY_CLASSES_ROOT\codex"
    if (-not (Test-Path -LiteralPath $protocolPath)) {
        throw "The registered Codex desktop protocol is unavailable."
    }
    $protocol = Get-Item -LiteralPath $protocolPath
    if ($null -eq $protocol.GetValue("URL Protocol", $null)) {
        throw "The registered Codex desktop protocol is invalid."
    }
    $registeredApps = @(
        Get-StartApps |
            Where-Object {
                $_.AppID -ceq [string]$HostProfile.app_id -and
                $_.Name -ceq [string]$HostProfile.start_app_name
            }
    )
    if ($registeredApps.Count -ne 1) {
        throw "The exact target Codex application registration is unavailable."
    }
    $packages = @(
        Get-AppxPackage -Name ([string]$HostProfile.package_name) |
            Where-Object {
                $_.PackageFamilyName -ceq [string]$HostProfile.package_family_name -and
                $_.Status -eq "Ok"
            }
    )
    if ($packages.Count -ne 1) {
        throw "The exact target Codex package is unavailable or unhealthy."
    }
    $manifestPath = Join-Path ([string]$packages[0].InstallLocation) "AppxManifest.xml"
    [xml]$manifest = Get-Content -LiteralPath $manifestPath -Raw
    $expectedApplications = @(
        $manifest.SelectNodes("//*[local-name()='Application']") |
            Where-Object {
                $_.GetAttribute("Id") -ceq "App" -and
                $_.GetAttribute("Executable") -ceq [string]$HostProfile.manifest_executable
            }
    )
    $codexProtocols = @(
        $manifest.SelectNodes("//*[local-name()='Protocol']") |
            Where-Object { $_.GetAttribute("Name") -ceq "codex" }
    )
    if ($expectedApplications.Count -ne 1 -or $codexProtocols.Count -lt 1) {
        throw "The target Codex package does not expose the expected app and Codex protocol."
    }
}

function Get-RootCodexProcess([int]$ProcessId, [object]$HostProfile) {
    $row = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId"
    if ($null -eq $row) { throw "The exact target process does not exist." }
    $path = [string]$row.ExecutablePath
    $command = [string]$row.CommandLine
    if (
        $row.Name -cne [string]$HostProfile.process_name -or
        $command -match "--type=" -or
        $path -notmatch [string]$HostProfile.root_path_pattern
    ) {
        throw "Only the exact root process for the bound Codex host may be restarted."
    }
    return $row
}

function Resolve-RootCodexTarget([int]$ProcessId, [string]$ExpectedAppId = "") {
    $candidateProfiles = if ([string]::IsNullOrWhiteSpace($ExpectedAppId)) {
        @($script:HostAppProfiles.Values)
    }
    else {
        @(Get-HostAppProfile $ExpectedAppId)
    }
    $matches = @()
    foreach ($profile in $candidateProfiles) {
        try {
            $process = Get-RootCodexProcess -ProcessId $ProcessId -HostProfile $profile
            $matches += [ordered]@{ process = $process; profile = $profile }
        }
        catch {}
    }
    if ($matches.Count -ne 1) {
        throw "The exact target process does not resolve to one approved stable/Beta Codex host."
    }
    return $matches[0]
}

function Get-NewRootCodexProcess([int]$PriorProcessId, [object]$HostProfile) {
    $matches = @(
        Get-CimInstance Win32_Process |
            Where-Object {
                [int]$_.ProcessId -ne $PriorProcessId -and
                [string]$_.Name -ceq [string]$HostProfile.process_name -and
                [string]$_.CommandLine -notmatch "--type=" -and
                [string]$_.ExecutablePath -match [string]$HostProfile.root_path_pattern
            }
    )
    if ($matches.Count -gt 1) {
        throw "More than one new root process for the bound Codex host was observed."
    }
    if ($matches.Count -eq 1) { return $matches[0] }
    return $null
}

function Get-CodexHostPackageProcesses([object]$HostProfile) {
    return @(
        Get-CimInstance Win32_Process |
            Where-Object {
                -not [string]::IsNullOrWhiteSpace([string]$_.ExecutablePath) -and
                [string]$_.ExecutablePath -match [string]$HostProfile.package_path_pattern
            }
    )
}

function Invoke-CodexHostActivation([object]$HostProfile, [string]$Arguments) {
    if (-not ("EvidenceLaneCodexHostActivation" -as [type])) {
        $activationSource = @'
using System;
using System.Runtime.InteropServices;

public static class EvidenceLaneCodexHostActivation
{
    [Flags]
    private enum ActivateOptions : uint
    {
        None = 0,
        DesignMode = 0x1,
        NoErrorUI = 0x2,
        NoSplashScreen = 0x4
    }

    [ComImport]
    [Guid("2e941141-7f97-4756-ba1d-9decde894a3d")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IApplicationActivationManager
    {
        [PreserveSig]
        int ActivateApplication(
            [MarshalAs(UnmanagedType.LPWStr)] string appUserModelId,
            [MarshalAs(UnmanagedType.LPWStr)] string arguments,
            ActivateOptions options,
            out uint processId);

        [PreserveSig]
        int ActivateForFile(IntPtr appUserModelId, IntPtr itemArray, IntPtr verb, out uint processId);

        [PreserveSig]
        int ActivateForProtocol(IntPtr appUserModelId, IntPtr itemArray, out uint processId);
    }

    public static uint Activate(string appUserModelId, string arguments)
    {
        Type managerType = Type.GetTypeFromCLSID(
            new Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C"));
        var manager = (IApplicationActivationManager)Activator.CreateInstance(managerType);
        uint processId;
        int result = manager.ActivateApplication(
            appUserModelId,
            arguments,
            ActivateOptions.NoErrorUI,
            out processId);
        Marshal.ThrowExceptionForHR(result);
        return processId;
    }
}
'@
        Add-Type -TypeDefinition $activationSource
    }
    try {
        return [uint32][EvidenceLaneCodexHostActivation]::Activate(
            [string]$HostProfile.app_id,
            $Arguments
        )
    }
    catch {
        throw "The exact bound Codex host activation failed: $($_.Exception.Message)"
    }
}

function Write-JsonReceipt([string]$Path, [System.Collections.IDictionary]$Body) {
    $parent = Split-Path -Parent $Path
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $temporary = Join-Path $parent ("." + [IO.Path]::GetFileName($Path) + "." + [guid]::NewGuid().ToString("N"))
    $utf8NoBom = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllText(
        $temporary,
        ($Body | ConvertTo-Json -Depth 12),
        $utf8NoBom
    )
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Get-EvidenceLaneConfigState([string]$Path) {
    $states = @{}
    $currentSelector = $null
    $currentKind = $null
    foreach ($line in Get-Content -LiteralPath $Path) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[plugins\."(?<selector>evidence-lane-plugin@[^\"]+)"\]$') {
            $currentSelector = [string]$Matches.selector
            $currentKind = "plugin"
        }
        elseif ($trimmed -match '^\[plugins\."(?<selector>evidence-lane-plugin@[^\"]+)"\.mcp_servers\.[^\]]+\]$') {
            $currentSelector = [string]$Matches.selector
            $currentKind = "mcp"
        }
        elseif ($trimmed -match '^\[') {
            $currentSelector = $null
            $currentKind = $null
        }
        elseif (
            $null -ne $currentSelector -and
            $trimmed -match '^enabled\s*=\s*(?<value>true|false)\s*(?:#.*)?$'
        ) {
            if (-not $states.ContainsKey($currentSelector)) {
                $states[$currentSelector] = [ordered]@{
                    plugin_values = @()
                    mcp_values = @()
                }
            }
            $value = [string]$Matches.value -ceq "true"
            if ($currentKind -eq "plugin") {
                $states[$currentSelector].plugin_values = @(
                    $states[$currentSelector].plugin_values
                ) + $value
            }
            elseif ($currentKind -eq "mcp") {
                $states[$currentSelector].mcp_values = @(
                    $states[$currentSelector].mcp_values
                ) + $value
            }
        }
    }

    $records = @(
        foreach ($selector in @($states.Keys | Sort-Object)) {
            $row = $states[$selector]
            if (
                @($row.plugin_values).Count -ne 1 -or
                @($row.mcp_values).Count -ne 1
            ) {
                throw "Every Evidence Lane selector must expose one plugin bit and one MCP bit."
            }
            [pscustomobject]@{
                selector = [string]$selector
                plugin_enabled = [bool]$row.plugin_values[0]
                mcp_enabled = [bool]$row.mcp_values[0]
            }
        }
    )
    if ($records.Count -eq 0) {
        throw "The Codex config exposes no Evidence Lane selector state."
    }
    [pscustomobject]@{
        records = $records
        enabled_plugin_selectors = @(
            $records | Where-Object { $_.plugin_enabled } | ForEach-Object { $_.selector }
        )
        enabled_mcp_selectors = @(
            $records | Where-Object { $_.mcp_enabled } | ForEach-Object { $_.selector }
        )
        mismatched_selectors = @(
            $records | Where-Object { $_.plugin_enabled -ne $_.mcp_enabled } |
                ForEach-Object { $_.selector }
        )
    }
}

$exactInstallReceipt = (Resolve-Path -LiteralPath $InstallReceipt).Path
$taskIdPattern = '^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$'
if ($TaskId -notmatch $taskIdPattern) {
    throw "TaskId must be the exact Codex conversation identifier."
}
$taskUri = "codex://threads/$TaskId"
$taskUriSha256 = Get-StringSha256 $taskUri
$installationDirectory = Split-Path -Parent $exactInstallReceipt
$taskBindingRoot = $installationDirectory
if ((Split-Path -Leaf $installationDirectory) -eq "two-slot") {
    $taskBindingRoot = Split-Path -Parent $installationDirectory
}
$taskBindingDirectory = Join-Path $taskBindingRoot "task-bindings"
$taskBindingPath = Join-Path $taskBindingDirectory ($TaskId.ToLowerInvariant() + ".json")
$observedInstallSha = Get-Sha256 $exactInstallReceipt
if ($InstallReceiptSha256 -and $observedInstallSha -ne $InstallReceiptSha256.ToUpperInvariant()) {
    throw "The exact install receipt SHA-256 does not match."
}
$install = Get-Content -LiteralPath $exactInstallReceipt -Raw | ConvertFrom-Json
$installedPluginVersion = [string]$install.plugin.version
$pluginAddProperty = $install.activation.PSObject.Properties["plugin_add"]
$pluginSelectorProperty = $install.activation.PSObject.Properties["plugin_selector"]
$installedPathProperty = $install.activation.PSObject.Properties["installed_path"]
$activationVersionBound = $false
if ($null -ne $pluginAddProperty) {
    $activationVersionBound = (
        [string]$pluginAddProperty.Value.version -eq $installedPluginVersion
    )
}
elseif (
    $null -ne $pluginSelectorProperty -and
    [string]$pluginSelectorProperty.Value -like "evidence-lane-plugin@*" -and
    $null -ne $installedPathProperty -and
    -not [string]::IsNullOrWhiteSpace([string]$installedPathProperty.Value) -and
    (Test-Path -LiteralPath ([string]$installedPathProperty.Value) -PathType Container)
) {
    # Accepted fallback receipts created before plugin_add was emitted still bind
    # the exact selector, installed cache, version, receipt hash, and registry slot.
    $activationVersionBound = $true
}
elseif (
    $null -ne $install.activation.PSObject.Properties["transaction"] -and
    $null -ne $install.activation_authority.PSObject.Properties["selector"] -and
    [string]$install.activation.transaction.candidate_selector -like "evidence-lane-plugin@*" -and
    [string]$install.activation_authority.selector -ceq [string]$install.activation.transaction.candidate_selector -and
    [string]$install.marketplace.state -ceq "STAGED" -and
    [string]$install.marketplace.name -ceq (
        ([string]$install.activation.transaction.candidate_selector).Split("@", 2)[1]
    )
) {
    # A local-test stage deliberately leaves the candidate disabled. Its exact
    # version binding is the sealed marketplace plus transaction selector; the
    # separate CAS commit below proves the one-time activation.
    $activationVersionBound = $true
}
if (
    $install.schema -ne "evidence-lane.codex-stable-installation.v2" -or
    $install.status -ne "PASS" -or
    $installedPluginVersion -notmatch '^\d+\.\d+\.\d+\+codex\.[0-9A-Za-z.-]+$' -or
    -not $activationVersionBound -or
    $install.candidate_created_or_accepted -ne $false -or
    $install.pointer_moved -ne $false
) {
    throw "The supplied v2 installation receipt is not restart-eligible."
}

$restartAuthorityMode = "GIT_STABLE_INSTALL_RECEIPT"
$exactLocalTestCommit = $null
$observedLocalTestCommitSha = $null
$exactCodexConfig = $null
$observedCodexConfigSha = $null
$localTestCommit = $null
$candidateSelector = $null
$lastKnownGoodSelector = $null
$exactLocalRecoveryRegistry = $null
$observedLocalRecoveryRegistrySha = $null
$localRecoveryRegistryBody = $null
$isLocalCasRestart = (
    [string]$install.activation.state -ceq
        "CANDIDATE_STAGED_DISABLED_RESTART_TRUST_REQUIRED"
)
$isDisabledHookRecoveryRestart = (
    [string]$install.activation.state -ceq
        "LOCAL_2_2_HOOK_RECOVERY_SWITCHED_RESTART_REQUIRED"
)
$isLocalTestRestart = $isLocalCasRestart -or $isDisabledHookRecoveryRestart

if ($isLocalCasRestart) {
    if (
        [string]::IsNullOrWhiteSpace($LocalTestCommitReceipt) -or
        [string]::IsNullOrWhiteSpace($LocalTestCommitReceiptSha256) -or
        [string]::IsNullOrWhiteSpace($CodexConfig)
    ) {
        throw "A local-test restart requires the exact CAS commit receipt, its SHA-256, and -CodexConfig."
    }
    $exactLocalTestCommit = (Resolve-Path -LiteralPath $LocalTestCommitReceipt).Path
    $observedLocalTestCommitSha = Get-Sha256 $exactLocalTestCommit
    if ($observedLocalTestCommitSha -cne $LocalTestCommitReceiptSha256.ToUpperInvariant()) {
        throw "The exact local-test CAS commit receipt SHA-256 does not match."
    }
    $exactCodexConfig = (Resolve-Path -LiteralPath $CodexConfig).Path
    $observedCodexConfigSha = Get-Sha256 $exactCodexConfig
    $localTestCommit = Get-Content -LiteralPath $exactLocalTestCommit -Raw | ConvertFrom-Json
    $candidateSelector = [string]$install.activation.transaction.candidate_selector
    $lastKnownGoodSelector = [string]$install.activation.transaction.last_known_good_selector
    $expectedHookEvents = @(
        "postCompact",
        "postToolUse",
        "preCompact",
        "preToolUse",
        "sessionEnd",
        "sessionStart",
        "stop",
        "userPromptSubmit"
    )
    $hookRecords = @($localTestCommit.hook_trust.records)
    $actualHookEvents = @($hookRecords | ForEach-Object { [string]$_.event_name } | Sort-Object -Unique)
    $expectedSortedEvents = @($expectedHookEvents | Sort-Object)
    $hookEventDifference = @(
        Compare-Object -ReferenceObject $expectedSortedEvents -DifferenceObject $actualHookEvents
    )
    $invalidHookRecords = @(
        $hookRecords | Where-Object {
            [string]$_.hook_key -cnotlike ($candidateSelector + ":hooks/hooks.json:*") -or
            [string]$_.trust_status -cne "trusted" -or
            $_.enabled -ne $true -or
            [string]$_.current_hash -cnotmatch '^sha256:[0-9a-f]{64}$'
        }
    )
    $rollbackBackup = [string]$localTestCommit.rollback_config_backup
    if (
        $install.activation.transaction.schema -cne "evidence-lane.codex-local-test-cas-transaction.v1" -or
        $install.activation.transaction.state -cne "CANDIDATE_STAGED_DISABLED" -or
        $install.activation.transaction.compare_and_swap -ne $true -or
        $install.activation.transaction.candidate_enabled -ne $false -or
        [int]$install.activation.transaction.switch_count -ne 0 -or
        $install.activation.transaction.rollback_capable -ne $true -or
        $install.activation_authority.status -cne "PASS" -or
        [string]$install.activation_authority.selector -cne $candidateSelector -or
        $localTestCommit.schema -cne "evidence-lane.codex-local-test-cas-commit.v1" -or
        $localTestCommit.status -cne "PASS" -or
        $localTestCommit.state -cne "CANDIDATE_SWITCHED_ONCE_RESTART_OR_RELOAD_REQUIRED" -or
        [string]$localTestCommit.stage_installation_receipt_sha256 -cne $observedInstallSha -or
        [string]$localTestCommit.transaction_id -cne [string]$install.activation.transaction.transaction_id -or
        [string]$localTestCommit.candidate_selector -cne $candidateSelector -or
        [string]$localTestCommit.last_known_good_selector -cne $lastKnownGoodSelector -or
        $localTestCommit.compare_and_swap -ne $true -or
        $localTestCommit.candidate_enabled -ne $true -or
        $localTestCommit.last_known_good_enabled -ne $false -or
        [int]$localTestCommit.switch_count -ne 1 -or
        $localTestCommit.rollback_capable -ne $true -or
        $localTestCommit.accepted_two_slot_registry_mutated -ne $false -or
        $localTestCommit.task_binding_used_for_authorization -ne $false -or
        $localTestCommit.goal_recovery_invoked -ne $false -or
        $localTestCommit.tunnel_invoked -ne $false -or
        $localTestCommit.candidate_created_or_accepted -ne $false -or
        $localTestCommit.pointer_moved -ne $false -or
        $localTestCommit.hil_inferred -ne $false -or
        $localTestCommit.config.activation_mode -cne "COMMIT_CANDIDATE" -or
        $localTestCommit.config.compare_and_swap -ne $true -or
        [int]$localTestCommit.config.switch_count -ne 1 -or
        $localTestCommit.config.candidate_enabled_after_write -ne $true -or
        $localTestCommit.config.last_known_good_enabled_after_write -ne $false -or
        [string]$localTestCommit.config.candidate_selector -cne $candidateSelector -or
        [string]$localTestCommit.config.last_known_good_selector -cne $lastKnownGoodSelector -or
        [string]$localTestCommit.config.after_sha256 -cne $observedCodexConfigSha -or
        $localTestCommit.hook_trust.schema -cne "evidence-lane.codex-hook-trust.v1" -or
        $localTestCommit.hook_trust.status -cne "PASS" -or
        [string]$localTestCommit.hook_trust.plugin_selector -cne $candidateSelector -or
        $localTestCommit.hook_trust.candidate_enabled -ne $true -or
        [int]$localTestCommit.hook_trust.hook_count -ne 8 -or
        $localTestCommit.hook_trust.unrelated_hook_state_mutated -ne $false -or
        $hookRecords.Count -ne 8 -or
        $hookEventDifference.Count -ne 0 -or
        $invalidHookRecords.Count -ne 0 -or
        [string]$localTestCommit.readiness.state -cne "INSTALLED_RESTART_OR_RELOAD_REQUIRED" -or
        $localTestCommit.readiness.ready -ne $false -or
        $localTestCommit.readiness.gates.hooks_trusted -ne $true -or
        $localTestCommit.readiness.gates.restart_or_reload_completed -ne $false -or
        [string]::IsNullOrWhiteSpace($rollbackBackup) -or
        (Get-Sha256 $rollbackBackup) -cne [string]$localTestCommit.rollback_config_backup_sha256 -or
        [string]$localTestCommit.rollback_config_backup_sha256 -cne
            [string]$install.activation.transaction.rollback_config_backup_sha256
    ) {
        throw "The supplied local-test stage and CAS commit receipts are not restart-eligible."
    }
    $restartAuthorityMode = "LOCAL_TEST_STAGED_INSTALL_PLUS_CAS_COMMIT"
}
elseif ($isDisabledHookRecoveryRestart) {
    if (
        [string]::IsNullOrWhiteSpace($LocalTestCommitReceipt) -or
        [string]::IsNullOrWhiteSpace($LocalTestCommitReceiptSha256) -or
        [string]::IsNullOrWhiteSpace($CodexConfig) -or
        [string]::IsNullOrWhiteSpace($LocalRecoveryRegistry) -or
        [string]::IsNullOrWhiteSpace($LocalRecoveryRegistrySha256)
    ) {
        throw "A disabled-hook recovery restart requires the exact prior CAS receipt, live config, and local 2.2 recovery registry with both file seals."
    }
    $exactLocalTestCommit = (Resolve-Path -LiteralPath $LocalTestCommitReceipt).Path
    $observedLocalTestCommitSha = Get-Sha256 $exactLocalTestCommit
    if ($observedLocalTestCommitSha -cne $LocalTestCommitReceiptSha256.ToUpperInvariant()) {
        throw "The exact prior local-test CAS receipt SHA-256 does not match."
    }
    $exactCodexConfig = (Resolve-Path -LiteralPath $CodexConfig).Path
    $observedCodexConfigSha = Get-Sha256 $exactCodexConfig
    $localTestCommit = Get-Content -LiteralPath $exactLocalTestCommit -Raw | ConvertFrom-Json
    $candidateSelector = [string]$install.activation.transaction.candidate_selector
    $lastKnownGoodSelector = [string]$install.activation.local_test_reinstall.last_known_good_selector
    $priorAuthority = $install.activation.transaction.prior_commit_authority
    $reinstallPriorAuthority = $install.activation.local_test_reinstall.prior_commit_authority
    $exclusiveChannel = $install.activation.exclusive_channel
    $hookTrust = $install.activation.hook_trust
    $hookIsolation = $install.activation.hook_event_isolation
    $runtimeReadiness = $install.activation.readiness
    $exactLocalRecoveryRegistry = (Resolve-Path -LiteralPath $LocalRecoveryRegistry).Path
    $observedLocalRecoveryRegistrySha = Get-Sha256 $exactLocalRecoveryRegistry
    if ($observedLocalRecoveryRegistrySha -cne $LocalRecoveryRegistrySha256.ToUpperInvariant()) {
        throw "The exact local 2.2 recovery registry SHA-256 does not match."
    }
    $localRecoveryRegistryBody = Get-Content -LiteralPath $exactLocalRecoveryRegistry -Raw | ConvertFrom-Json
    $configState = Get-EvidenceLaneConfigState $exactCodexConfig
    $expectedHookEvents = @(
        "postCompact",
        "postToolUse",
        "preCompact",
        "preToolUse",
        "sessionEnd",
        "sessionStart",
        "stop",
        "userPromptSubmit"
    )
    $hookRecords = @($hookTrust.records)
    $actualHookEvents = @(
        $hookRecords | ForEach-Object { [string]$_.event_name } | Sort-Object -Unique
    )
    $hookEventDifference = @(
        Compare-Object -ReferenceObject @($expectedHookEvents | Sort-Object) -DifferenceObject $actualHookEvents
    )
    $invalidHookRecords = @(
        $hookRecords | Where-Object {
            [string]$_.hook_key -cnotlike ($candidateSelector + ":hooks/hooks.json:*") -or
            [string]$_.trust_status -cne "trusted" -or
            $_.enabled -ne $true -or
            [string]$_.current_hash -cnotmatch '^sha256:[0-9a-f]{64}$'
        }
    )
    $rollbackBackup = [string]$install.activation.transaction.rollback_config_backup
    if (
        $install.activation.transaction.schema -cne "evidence-lane.codex-local-test-disabled-hook-recovery.v1" -or
        $install.activation.transaction.state -cne "LOCAL_SELECTOR_SWITCHED_ONCE" -or
        $install.activation.transaction.compare_and_swap -ne $true -or
        $install.activation.transaction.candidate_enabled -ne $true -or
        [int]$install.activation.transaction.switch_count -ne 1 -or
        $install.activation.transaction.rollback_capable -ne $true -or
        $install.activation.transaction.stable_and_fallback_enabled -ne $false -or
        $install.activation.transaction.exact_eight_hook_hashes_trusted -ne $true -or
        $install.activation.transaction.hook_event_isolation_verified_before_activation -ne $true -or
        $install.activation.transaction.restart_or_reload_required -ne $true -or
        $install.activation.transaction.candidate_created_or_accepted -ne $false -or
        $install.activation.transaction.pointer_moved -ne $false -or
        $install.activation.transaction.hil_inferred -ne $false -or
        [string]$priorAuthority.path -cne $exactLocalTestCommit -or
        [string]$priorAuthority.file_sha256 -cne $observedLocalTestCommitSha -or
        [string]$priorAuthority.transaction_id -cne [string]$localTestCommit.transaction_id -or
        [string]$priorAuthority.failed_candidate_config_sha256 -cne [string]$localTestCommit.config.after_sha256 -or
        [string]$reinstallPriorAuthority.path -cne [string]$priorAuthority.path -or
        [string]$reinstallPriorAuthority.file_sha256 -cne [string]$priorAuthority.file_sha256 -or
        [string]$reinstallPriorAuthority.transaction_id -cne [string]$priorAuthority.transaction_id -or
        $localTestCommit.schema -cne "evidence-lane.codex-local-test-cas-commit.v1" -or
        $localTestCommit.status -cne "PASS" -or
        $localTestCommit.state -cne "CANDIDATE_SWITCHED_ONCE_RESTART_OR_RELOAD_REQUIRED" -or
        [string]$localTestCommit.candidate_selector -cne $candidateSelector -or
        [string]$localTestCommit.last_known_good_selector -cne $lastKnownGoodSelector -or
        $localTestCommit.candidate_enabled -ne $true -or
        [int]$localTestCommit.switch_count -ne 1 -or
        $localTestCommit.rollback_capable -ne $true -or
        $localTestCommit.candidate_created_or_accepted -ne $false -or
        $localTestCommit.pointer_moved -ne $false -or
        $localTestCommit.hil_inferred -ne $false -or
        $install.activation.local_test_reinstall.schema -cne "evidence-lane.codex-local-test-reinstall.v1" -or
        $install.activation.local_test_reinstall.status -cne "PASS" -or
        $install.activation.local_test_reinstall.transaction_mode -cne "DISABLED_LOCAL_HOOK_RECOVERY" -or
        [string]$install.activation.local_test_reinstall.transaction_id -cne [string]$install.activation.transaction.transaction_id -or
        [string]$install.activation.local_test_reinstall.plugin_selector -cne $candidateSelector -or
        [string]$install.activation.local_test_reinstall.recovery_switch_target -cne $candidateSelector -or
        $install.activation.local_test_reinstall.accepted_two_slot_registry_mutated -ne $false -or
        $exclusiveChannel.status -cne "LOCAL_SELECTOR_SWITCHED_ONCE" -or
        [int]$exclusiveChannel.enabled_evidence_lane_count -ne 1 -or
        [string]$exclusiveChannel.enabled_selector -cne $candidateSelector -or
        [string]$exclusiveChannel.candidate_selector -cne $candidateSelector -or
        $exclusiveChannel.candidate_enabled -ne $true -or
        [int]$exclusiveChannel.switch_count -ne 1 -or
        $exclusiveChannel.stable_and_fallback_enabled -ne $false -or
        $exclusiveChannel.accepted_two_slot_registry_mutated -ne $false -or
        $hookTrust.schema -cne "evidence-lane.codex-hook-trust.v1" -or
        $hookTrust.status -cne "PASS" -or
        [string]$hookTrust.plugin_selector -cne $candidateSelector -or
        $hookTrust.candidate_enabled -ne $true -or
        $hookTrust.disabled_local_recovery -ne $true -or
        [int]$hookTrust.hook_count -ne 8 -or
        $hookTrust.unrelated_hook_state_mutated -ne $false -or
        $hookRecords.Count -ne 8 -or
        $hookEventDifference.Count -ne 0 -or
        $invalidHookRecords.Count -ne 0 -or
        $hookIsolation.schema -cne "evidence-lane.codex-installed-hook-event-isolation.v1" -or
        $hookIsolation.status -cne "PASS" -or
        $hookIsolation.state -cne "INACTIVE_KILL_SWITCH_VERIFIED" -or
        $hookIsolation.persistent_kill_switch -ne $true -or
        $hookIsolation.verified_before_install_activation -ne $true -or
        [string]$hookIsolation.installation_id -cne [string]$install.activation.transaction.transaction_id -or
        $runtimeReadiness.state -cne "INSTALLED_RESTART_OR_RELOAD_REQUIRED" -or
        $runtimeReadiness.ready -ne $false -or
        $runtimeReadiness.runtime_ready_before_task_reopen -ne $false -or
        $runtimeReadiness.gates.hooks_trusted -ne $true -or
        $runtimeReadiness.gates.restart_or_reload_completed -ne $false -or
        $install.activation_authority.status -cne "PASS" -or
        $install.activation_authority.boundary -cne "EXPLICIT_DISABLED_LOCAL_2_2_HOOK_RECOVERY" -or
        [string]$install.activation_authority.selector -cne $candidateSelector -or
        $install.activation_authority.accepted_two_slot_registry_mutated -ne $false -or
        $install.runtime_ready_before_task_reopen -ne $false -or
        $install.restart_required -ne $true -or
        $install.candidate_created_or_accepted -ne $false -or
        $install.pointer_moved -ne $false -or
        $install.hil_inferred -ne $false -or
        $localRecoveryRegistryBody.schema -cne "evidence-lane.codex-local-v220-recovery-registry.v1" -or
        $localRecoveryRegistryBody.status -cne "PASS" -or
        $localRecoveryRegistryBody.state -cne "PRIMARY_LOCAL_ACTIVE_RECOVERY_DISABLED_BYTE_IDENTICAL" -or
        [string]$localRecoveryRegistryBody.package.plugin_version -cne $installedPluginVersion -or
        [string]$localRecoveryRegistryBody.package.archive_sha256 -cne [string]$install.archive_sha256 -or
        [string]$localRecoveryRegistryBody.primary.selector -cne $candidateSelector -or
        $localRecoveryRegistryBody.primary.enabled -ne $true -or
        $localRecoveryRegistryBody.primary.native_mcp_enabled -ne $true -or
        [string]$localRecoveryRegistryBody.primary.installation_receipt -cne $exactInstallReceipt -or
        [string]$localRecoveryRegistryBody.primary.installation_receipt_sha256 -cne $observedInstallSha -or
        [string]$localRecoveryRegistryBody.recovery.selector -cne "evidence-lane-plugin@evidence-lane-v220-stable-recovery" -or
        $localRecoveryRegistryBody.recovery.slot_role -cne "local-stable-recovery" -or
        $localRecoveryRegistryBody.recovery.enabled -ne $false -or
        $localRecoveryRegistryBody.recovery.native_mcp_enabled -ne $false -or
        $localRecoveryRegistryBody.recovery.byte_identical_to_primary -ne $true -or
        $localRecoveryRegistryBody.accepted_two_slot_registry.mutated -ne $false -or
        $localRecoveryRegistryBody.selection_law.accepted_2_1_stable_or_fallback_automatic_recovery_allowed -ne $false -or
        $localRecoveryRegistryBody.selection_law.host_restart_required_after_selector_switch -ne $true -or
        $localRecoveryRegistryBody.selection_law.restart_loop_allowed -ne $false -or
        $localRecoveryRegistryBody.candidate_created_or_accepted -ne $false -or
        $localRecoveryRegistryBody.pointer_moved -ne $false -or
        $localRecoveryRegistryBody.hil_inferred -ne $false -or
        @($configState.enabled_plugin_selectors).Count -ne 1 -or
        @($configState.enabled_mcp_selectors).Count -ne 1 -or
        [string]$configState.enabled_plugin_selectors[0] -cne $candidateSelector -or
        [string]$configState.enabled_mcp_selectors[0] -cne $candidateSelector -or
        @($configState.mismatched_selectors).Count -ne 0 -or
        [string]::IsNullOrWhiteSpace($rollbackBackup) -or
        -not (Test-Path -LiteralPath $rollbackBackup -PathType Leaf) -or
        (Get-Sha256 $rollbackBackup) -cne [string]$install.activation.transaction.rollback_config_backup_sha256
    ) {
        throw "The supplied disabled-hook recovery receipt, prior CAS authority, and live selector state are not restart-eligible."
    }
    $restartAuthorityMode = "LOCAL_TEST_DISABLED_HOOK_RECOVERY_INSTALL_RECEIPT"
}
elseif (
    [string]$install.activation.state -cne "INSTALLED_RESTART_REQUIRED" -or
    -not [string]::IsNullOrWhiteSpace($LocalTestCommitReceipt) -or
    -not [string]::IsNullOrWhiteSpace($LocalTestCommitReceiptSha256) -or
    -not [string]::IsNullOrWhiteSpace($CodexConfig)
) {
    throw "The supplied v2 installation receipt is not restart-eligible."
}

$restartAuthority = [ordered]@{
    schema = "evidence-lane.codex-restart-authority.v1"
    mode = $restartAuthorityMode
    install_receipt_sha256 = $observedInstallSha
    plugin_version = $installedPluginVersion
}
if ($isLocalCasRestart) {
    $restartAuthority.local_test_commit_receipt = $exactLocalTestCommit
    $restartAuthority.local_test_commit_receipt_sha256 = $observedLocalTestCommitSha
    $restartAuthority.codex_config = $exactCodexConfig
    $restartAuthority.codex_config_sha256 = $observedCodexConfigSha
    $restartAuthority.transaction_id = [string]$localTestCommit.transaction_id
    $restartAuthority.candidate_selector = $candidateSelector
    $restartAuthority.last_known_good_selector = $lastKnownGoodSelector
    $restartAuthority.hook_trust_receipt_sha256 = [string]$localTestCommit.hook_trust.receipt_sha256
    $restartAuthority.hook_count = 8
}
elseif ($isDisabledHookRecoveryRestart) {
    $restartAuthority.prior_commit_receipt = $exactLocalTestCommit
    $restartAuthority.prior_commit_receipt_sha256 = $observedLocalTestCommitSha
    $restartAuthority.codex_config = $exactCodexConfig
    $restartAuthority.codex_config_sha256 = $observedCodexConfigSha
    $restartAuthority.transaction_id = [string]$install.activation.transaction.transaction_id
    $restartAuthority.prior_transaction_id = [string]$localTestCommit.transaction_id
    $restartAuthority.candidate_selector = $candidateSelector
    $restartAuthority.last_known_good_selector = $lastKnownGoodSelector
    $restartAuthority.hook_trust_receipt_sha256 = [string]$install.activation.hook_trust.receipt_sha256
    $restartAuthority.hook_count = 8
    $restartAuthority.enabled_evidence_lane_selector_count = 1
    $restartAuthority.local_recovery_registry = $exactLocalRecoveryRegistry
    $restartAuthority.local_recovery_registry_sha256 = $observedLocalRecoveryRegistrySha
    $restartAuthority.local_recovery_selector = [string]$localRecoveryRegistryBody.recovery.selector
    $restartAuthority.local_recovery_byte_identical_to_primary = $true
    $restartAuthority.accepted_2_1_automatic_recovery_allowed = $false
}
$restartAuthoritySha256 = Get-StringSha256 (
    $restartAuthority | ConvertTo-Json -Compress -Depth 8
)

if ($Action -eq "Prepare") {
    if ($TargetProcessId -le 0) { throw "Prepare requires -TargetProcessId." }
    $target = Resolve-RootCodexTarget -ProcessId $TargetProcessId -ExpectedAppId $AppId
    $process = $target.process
    $hostProfile = $target.profile
    $AppId = [string]$hostProfile.app_id
    Assert-CodexThreadProtocol $hostProfile
    $receiptPath = Join-Path $ReceiptDirectory "CODEX_RESTART_PREPARATION.json"
    $body = [ordered]@{
        schema = "evidence-lane.codex-restart-preparation.v2"
        state = "PREPARED_NOT_RESTARTED"
        project_id = $ProjectId
        evidence_session_id = $EvidenceSessionId
        task_id = $TaskId
        host_session_id = $HostSessionId
        install_receipt = $exactInstallReceipt
        install_receipt_sha256 = $observedInstallSha
        restart_authority = $restartAuthority
        restart_authority_sha256 = $restartAuthoritySha256
        plugin_version = [string]$install.plugin.version
        target = [ordered]@{
            host_application = [string]$hostProfile.host_application
            package_family_name = [string]$hostProfile.package_family_name
            process_id = [int]$process.ProcessId
            process_name = [string]$process.Name
            executable_path = [string]$process.ExecutablePath
            command_line_has_renderer_type = $false
            app_id = [string]$hostProfile.app_id
        }
        continuation = [ordered]@{
            same_task_required = $true
            task_2_used = $false
            user_reentry_action = "NONE_AUTO_OPEN_EXACT_TASK"
            task_navigation_mode = "CODEX_THREAD_DEEPLINK"
            task_uri_sha256 = $taskUriSha256
            coordinate_clicking_used = $false
            native_workspace_binding_source = "EXISTING_CODEX_TASK_STATE"
            native_workspace_binding_mutated = $false
            codex_native_changes_ui_owned_by_host = $true
            goal_resumes_from_persistent_task_and_change_display = $true
            lifecycle_resume_call_required = $false
            state_travel_required = $false
        }
        hot_reload_claimed = $false
        process_stopped = $false
        source_mutated = $false
        candidate_created_or_accepted = $false
        pointer_moved = $false
        hil_inferred = $false
        prepared_at_utc = [DateTimeOffset]::UtcNow.ToString("o")
    }
    Write-JsonReceipt $receiptPath $body
    $preparationReceiptSha256 = Get-Sha256 $receiptPath
    $taskBinding = [ordered]@{
        schema = "evidence-lane.codex-task-binding.v1"
        state = "EXACT_TASK_BINDING_PREPARED"
        project_id = $ProjectId
        evidence_session_id = $EvidenceSessionId
        task_id = $TaskId
        governed_host_session_id = $HostSessionId
        plugin_version = [string]$install.plugin.version
        task_uri_sha256 = $taskUriSha256
        preparation_receipt = $receiptPath
        preparation_receipt_sha256 = $preparationReceiptSha256
        install_receipt = $exactInstallReceipt
        install_receipt_sha256 = $observedInstallSha
        restart_authority = $restartAuthority
        restart_authority_sha256 = $restartAuthoritySha256
        claim_scope = "EXACT_CODEX_THREAD_ID_ONLY"
        alias_claim_allowed = $true
        native_workspace_binding_source = "EXISTING_CODEX_TASK_STATE"
        native_workspace_binding_mutated = $false
        codex_native_changes_ui_mutated = $false
        source_mutated = $false
        candidate_created_or_accepted = $false
        pointer_moved = $false
        hil_inferred = $false
        prepared_at_utc = [DateTimeOffset]::UtcNow.ToString("o")
    }
    Write-JsonReceipt $taskBindingPath $taskBinding
    [ordered]@{
        status = "PASS"
        state = "PREPARED_NOT_RESTARTED"
        receipt_path = $receiptPath
        receipt_sha256 = $preparationReceiptSha256
        task_binding_receipt_path = $taskBindingPath
        task_binding_receipt_sha256 = Get-Sha256 $taskBindingPath
        app_id = [string]$hostProfile.app_id
        restart_authority_mode = $restartAuthorityMode
        next_action = "RUN_RESTART_WITH_EXACT_RECEIPT_SHA_AND_CONFIRMRESTART"
    } | ConvertTo-Json -Depth 8
    exit 0
}

if ($Action -eq "Restart") {
    if (-not $ConfirmRestart) { throw "Restart requires -ConfirmRestart." }
    if (-not $PreparationReceipt -or -not $PreparationReceiptSha256) {
        throw "Restart requires the exact preparation receipt path and SHA-256."
    }
    $exactPreparation = (Resolve-Path -LiteralPath $PreparationReceipt).Path
    if ((Get-Sha256 $exactPreparation) -ne $PreparationReceiptSha256.ToUpperInvariant()) {
        throw "The preparation receipt SHA-256 does not match."
    }
    $prepared = Get-Content -LiteralPath $exactPreparation -Raw | ConvertFrom-Json
    $hostProfile = Get-HostAppProfile $AppId
    if (-not (Test-Path -LiteralPath $taskBindingPath -PathType Leaf)) {
        throw "The exact Codex task binding receipt is missing."
    }
    $taskBinding = Get-Content -LiteralPath $taskBindingPath -Raw | ConvertFrom-Json
    if (
        $prepared.schema -ne "evidence-lane.codex-restart-preparation.v2" -or
        $prepared.state -ne "PREPARED_NOT_RESTARTED" -or
        $prepared.project_id -ne $ProjectId -or
        $prepared.evidence_session_id -ne $EvidenceSessionId -or
        $prepared.task_id -ne $TaskId -or
        $prepared.host_session_id -ne $HostSessionId -or
        $prepared.install_receipt_sha256 -ne $observedInstallSha -or
        $prepared.restart_authority_sha256 -ne $restartAuthoritySha256 -or
        $prepared.target.host_application -ne [string]$hostProfile.host_application -or
        $prepared.target.package_family_name -ne [string]$hostProfile.package_family_name -or
        $prepared.target.process_name -ne [string]$hostProfile.process_name -or
        $prepared.target.app_id -ne $AppId -or
        [int]$prepared.target.process_id -ne $TargetProcessId -or
        $taskBinding.schema -ne "evidence-lane.codex-task-binding.v1" -or
        $taskBinding.state -ne "EXACT_TASK_BINDING_PREPARED" -or
        $taskBinding.project_id -ne $ProjectId -or
        $taskBinding.evidence_session_id -ne $EvidenceSessionId -or
        $taskBinding.task_id -ne $TaskId -or
        $taskBinding.governed_host_session_id -ne $HostSessionId -or
        $taskBinding.task_uri_sha256 -ne $taskUriSha256 -or
        $taskBinding.preparation_receipt_sha256 -ne $PreparationReceiptSha256.ToUpperInvariant() -or
        $taskBinding.install_receipt_sha256 -ne $observedInstallSha -or
        $taskBinding.restart_authority_sha256 -ne $restartAuthoritySha256 -or
        $taskBinding.alias_claim_allowed -ne $true
    ) {
        throw "The preparation receipt does not bind this exact task and process."
    }
    $process = Get-RootCodexProcess -ProcessId $TargetProcessId -HostProfile $hostProfile
    if ([string]$process.ExecutablePath -ne [string]$prepared.target.executable_path) {
        throw "The exact target executable changed after preparation."
    }
    $powershell = (Get-Command powershell.exe -ErrorAction Stop).Source
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $PSCommandPath,
        "-Action", "Relaunch",
        "-InstallReceipt", $exactInstallReceipt,
        "-InstallReceiptSha256", $observedInstallSha,
        "-ProjectId", $ProjectId,
        "-EvidenceSessionId", $EvidenceSessionId,
        "-TaskId", $TaskId,
        "-HostSessionId", $HostSessionId,
        "-TargetProcessId", [string]$TargetProcessId,
        "-PreparationReceipt", $exactPreparation,
        "-PreparationReceiptSha256", $PreparationReceiptSha256,
        "-ReceiptDirectory", $ReceiptDirectory,
        "-AppId", $AppId
    )
    if ($isLocalTestRestart) {
        $arguments += @(
            "-LocalTestCommitReceipt", $exactLocalTestCommit,
            "-LocalTestCommitReceiptSha256", $observedLocalTestCommitSha,
            "-CodexConfig", $exactCodexConfig
        )
    }
    if ($isDisabledHookRecoveryRestart) {
        $arguments += @(
            "-LocalRecoveryRegistry", $exactLocalRecoveryRegistry,
            "-LocalRecoveryRegistrySha256", $observedLocalRecoveryRegistrySha
        )
    }
    $argumentLine = ($arguments | ForEach-Object {
        ConvertTo-WindowsCommandLineArgument ([string]$_)
    }) -join " "
    Start-Process -FilePath $powershell -ArgumentList $argumentLine -WindowStyle Hidden | Out-Null
    Stop-Process -Id $TargetProcessId -Force
    exit 0
}

if ($Action -eq "Relaunch") {
    $relaunchPath = Join-Path $ReceiptDirectory "CODEX_RELAUNCH_RECEIPT.json"
    $failurePath = Join-Path $ReceiptDirectory "CODEX_RELAUNCH_FAILURE.json"
    try {
        if (-not $PreparationReceipt -or -not $PreparationReceiptSha256) {
            throw "Internal relaunch requires the sealed preparation receipt."
        }
        if ((Get-Sha256 $PreparationReceipt) -ne $PreparationReceiptSha256.ToUpperInvariant()) {
            throw "Internal relaunch receipt mismatch."
        }
        $prepared = Get-Content -LiteralPath $PreparationReceipt -Raw | ConvertFrom-Json
        $hostProfile = Get-HostAppProfile $AppId
        if (-not (Test-Path -LiteralPath $taskBindingPath -PathType Leaf)) {
            throw "The exact Codex task binding receipt is missing."
        }
        $taskBinding = Get-Content -LiteralPath $taskBindingPath -Raw | ConvertFrom-Json
        if (
            $prepared.schema -ne "evidence-lane.codex-restart-preparation.v2" -or
            $prepared.state -ne "PREPARED_NOT_RESTARTED" -or
            $prepared.project_id -ne $ProjectId -or
            $prepared.evidence_session_id -ne $EvidenceSessionId -or
            $prepared.task_id -ne $TaskId -or
            $prepared.host_session_id -ne $HostSessionId -or
            $prepared.install_receipt_sha256 -ne $observedInstallSha -or
            $prepared.restart_authority_sha256 -ne $restartAuthoritySha256 -or
            $prepared.continuation.task_uri_sha256 -ne $taskUriSha256 -or
            $prepared.target.host_application -ne [string]$hostProfile.host_application -or
            $prepared.target.package_family_name -ne [string]$hostProfile.package_family_name -or
            $prepared.target.process_name -ne [string]$hostProfile.process_name -or
            $prepared.target.app_id -ne $AppId -or
            [int]$prepared.target.process_id -ne $TargetProcessId -or
            $taskBinding.schema -ne "evidence-lane.codex-task-binding.v1" -or
            $taskBinding.state -ne "EXACT_TASK_BINDING_PREPARED" -or
            $taskBinding.project_id -ne $ProjectId -or
            $taskBinding.evidence_session_id -ne $EvidenceSessionId -or
            $taskBinding.task_id -ne $TaskId -or
            $taskBinding.governed_host_session_id -ne $HostSessionId -or
            $taskBinding.task_uri_sha256 -ne $taskUriSha256 -or
            $taskBinding.preparation_receipt_sha256 -ne $PreparationReceiptSha256.ToUpperInvariant() -or
            $taskBinding.install_receipt_sha256 -ne $observedInstallSha -or
            $taskBinding.restart_authority_sha256 -ne $restartAuthoritySha256 -or
            $taskBinding.alias_claim_allowed -ne $true
        ) {
            throw "The relaunch request does not bind the exact prepared task and process."
        }
        $deadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while (Get-Process -Id $TargetProcessId -ErrorAction SilentlyContinue) {
            if ([DateTimeOffset]::UtcNow -ge $deadline) {
                throw "The exact Codex root process did not stop within 60 seconds."
            }
            Start-Sleep -Milliseconds 250
        }
        $treeDeadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while (@(Get-CodexHostPackageProcesses $hostProfile).Count -gt 0) {
            if ([DateTimeOffset]::UtcNow -ge $treeDeadline) {
                throw "The exact bound Codex host process tree did not stop within 60 seconds."
            }
            Start-Sleep -Milliseconds 250
        }
        Assert-CodexThreadProtocol $hostProfile
        $launchRequestProcessId = Invoke-CodexHostActivation -HostProfile $hostProfile -Arguments $taskUri
        $newRoot = $null
        $launchDeadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
        while ($null -eq $newRoot) {
            if ([DateTimeOffset]::UtcNow -ge $launchDeadline) {
                throw "No new root process for the bound Codex host appeared after exact AppUserModelID activation."
            }
            Start-Sleep -Milliseconds 250
            $newRoot = Get-NewRootCodexProcess -PriorProcessId $TargetProcessId -HostProfile $hostProfile
        }
        $verifiedRoot = Get-RootCodexProcess -ProcessId ([int]$newRoot.ProcessId) -HostProfile $hostProfile
        $navigationRequestProcessId = Invoke-CodexHostActivation -HostProfile $hostProfile -Arguments $taskUri
        Start-Sleep -Milliseconds 500
        [void](Get-RootCodexProcess -ProcessId ([int]$verifiedRoot.ProcessId) -HostProfile $hostProfile)
        Write-JsonReceipt $relaunchPath ([ordered]@{
            schema = "evidence-lane.codex-relaunch-receipt.v2"
            state = "BOUND_CODEX_HOST_ROOT_RELAUNCHED_EXACT_TASK_REQUESTED_AWAITING_NATIVE_PROOF"
            project_id = $ProjectId
            evidence_session_id = $EvidenceSessionId
            task_id = $TaskId
            prior_host_session_id = $HostSessionId
            preparation_receipt_sha256 = $PreparationReceiptSha256.ToUpperInvariant()
            task_binding_receipt_sha256 = Get-Sha256 $taskBindingPath
            install_receipt_sha256 = $observedInstallSha
            restart_authority_sha256 = $restartAuthoritySha256
            restart_authority_mode = $restartAuthorityMode
            host_application = [string]$hostProfile.host_application
            package_family_name = [string]$hostProfile.package_family_name
            app_id = [string]$hostProfile.app_id
            prior_bound_host_process_tree_fully_stopped = $true
            task_navigation = [ordered]@{
                mode = "EXACT_BOUND_APPUSERMODELID_WITH_CODEX_THREAD_ARGUMENT"
                task_uri_sha256 = $taskUriSha256
                coordinate_clicking_used = $false
                launch_request_process_id = [uint32]$launchRequestProcessId
                navigation_request_process_id = [uint32]$navigationRequestProcessId
                new_root_process_id = [int]$verifiedRoot.ProcessId
                new_root_process_name = [string]$verifiedRoot.Name
                new_root_executable_path = [string]$verifiedRoot.ExecutablePath
                request_observed = $true
                user_opened_host_manually = $false
                task_2_used = $false
                active_task_ui_independently_proven = $false
                native_local_workspace_and_changes_proof_pending = $true
                codex_native_changes_ui_mutated = $false
                native_catalog_and_project_session_proof_pending = $true
            }
            source_mutated = $false
            candidate_created_or_accepted = $false
            pointer_moved = $false
            hil_inferred = $false
            requested_at_utc = [DateTimeOffset]::UtcNow.ToString("o")
        })
    }
    catch {
        Write-JsonReceipt $failurePath ([ordered]@{
            schema = "evidence-lane.codex-relaunch-failure.v1"
            state = "BOUND_CODEX_HOST_RELAUNCH_FAILED"
            project_id = $ProjectId
            evidence_session_id = $EvidenceSessionId
            task_id = $TaskId
            prior_host_session_id = $HostSessionId
            app_id = $AppId
            failure = $_.Exception.Message
            operator_recovery_required = $true
            manual_open_can_satisfy_helper_success = $false
            native_proof_claimed = $false
            candidate_created_or_accepted = $false
            pointer_moved = $false
            hil_inferred = $false
            failed_at_utc = [DateTimeOffset]::UtcNow.ToString("o")
        })
        throw
    }
    exit 0
}
