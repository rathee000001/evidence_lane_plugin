"""Deterministic Codex turn receipts over governed Evidence Lane sessions.

This module is deliberately host-specific.  It strengthens the documented Codex
hook path without pretending that tool hooks observe hosted tools or every
specialized host path.  The accepted pointer, Entry/Prepare receipts, active
ENV/UOP mode, and persistent Plan row remain the authority; task-window
scrollback and transcript files are never read here.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import time
import tomllib
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

from .constants import ENGINE_VERSION
from .errors import EvidenceLaneError
from .git_adapter import calculate_worktree_sha256, inspect_repository, run_git
from .hashing import (
    atomic_write_json,
    canonical_json_bytes,
    sha256_bytes,
    sha256_file,
)
from .lineage import ChatLineage
from .prompt_index import PromptIndex
from .redaction import contains_secret, redact_text
from .store import ProjectStore

_SHA256_RE = re.compile(r"^[A-F0-9]{64}$")
_CODEX_TASK_ID_RE = re.compile(
    r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-"
    r"[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$"
)
_LINK_RE = re.compile(r"\[[^\]]*\]\(([^)]+)\)|https?://[^\s)>]+")
_TURN_SECRET_ASSIGNMENT_RE = re.compile(
    r"(?i)\b(?:authorization|password|token|secret|api[_-]?key|"
    r"access[_-]?token|refresh[_-]?token)\b\s*[:=]\s*[^\s,;]+"
)
_TURN_BEARER_RE = re.compile(r"(?i)\bbearer\s+[^\s,;]+")
_ACTIVE_PLAN_STATUSES = {"ACTIVE", "IN_PROGRESS"}
_MAX_VISIBLE_EVENT_CHARS = 12_000
_MAX_PERSISTENT_CHANGE_PATHS = 200
_TOKEN_METRIC_KEYS = {
    "input_tokens",
    "output_tokens",
    "total_tokens",
    "cached_input_tokens",
    "cache_read_input_tokens",
    "cache_creation_input_tokens",
    "reasoning_tokens",
}
_GOAL_USAGE_SEMANTICS = {
    "GOAL_FINAL_COUNTER",
    "GOAL_CUMULATIVE_SNAPSHOT",
    "TURN_DELTA",
}
_LIFECYCLE_EXIT_REASONS = {
    "HIL_WAIT",
    "EXPLICIT_PAUSE",
    "GENUINE_BLOCK",
    "GOVERNED_ERROR",
    "EXIT_BOOT",
    "STATE_TRAVEL_HANDOFF",
    "STATELESS_EPHEMERAL_END",
}
_PROJECT_TASK_PRIVATE_ANALYSIS = "PROJECT_TASK_PRIVATE_ANALYSIS"
_MEMORY_PLUS_LEARNING_RESEARCH_QUESTION = (
    "How can this governed project preserve exact task memory and measure learning "
    "continuity across its turns without cross-project disclosure, shared telemetry, "
    "or private-reasoning storage?"
)


class TurnControlError(RuntimeError):
    """One deterministic fail-closed Codex turn-control failure."""

    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.details = details

    def as_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
        }


def resolve_codex_hook_store_root(
    *,
    environment: dict[str, str] | None = None,
    home: Path | None = None,
) -> Path:
    """Resolve the governed local authority used by every Codex hook.

    Codex injects ``PLUGIN_DATA`` as installation-scoped private storage for
    each plugin selector.  Evidence Lane project, session, PV, PromptIndex,
    and ChatLineage state is deliberately user-owned and shared across the
    stable/fallback selectors, so that host value must never become its
    authority root.  Tests and explicitly configured deployments may bind an
    alternate durable authority through ``EVIDENCE_LANE_DATA_ROOT`` only.
    """

    values = os.environ if environment is None else environment
    configured_root = values.get("EVIDENCE_LANE_DATA_ROOT")
    if configured_root is not None:
        configured_root = str(configured_root).strip()
        if not configured_root:
            raise TurnControlError(
                "EVIDENCE_LANE_DATA_ROOT_INVALID",
                "EVIDENCE_LANE_DATA_ROOT cannot be empty when configured.",
            )
        return Path(configured_root).expanduser().resolve()
    durable_home = (home or Path.home()).expanduser().resolve()
    return (durable_home / "EvidenceLanePV").resolve()


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _turn_redact_text(value: str) -> str:
    safe = redact_text(value)
    safe = _TURN_SECRET_ASSIGNMENT_RE.sub("[REDACTED]", safe)
    return _TURN_BEARER_RE.sub("[REDACTED]", safe)


def _turn_redact(value: Any) -> Any:
    if isinstance(value, str):
        return _turn_redact_text(value)
    if isinstance(value, dict):
        return {str(key): _turn_redact(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_turn_redact(item) for item in value]
    return value


def _lineage_host_identity(host_payload: dict[str, Any]) -> dict[str, Any]:
    """Return a privacy-safe host identity for visible ChatLineage events."""

    runtime_context_value = host_payload.get("runtime_context")
    runtime_context: dict[str, Any] = (
        cast(dict[str, Any], runtime_context_value)
        if isinstance(runtime_context_value, dict)
        else {}
    )
    host_session_id = str(host_payload.get("session_id") or "").strip()
    identity = {
        "host_kind": _turn_redact_text(
            str(
                host_payload.get("host_kind")
                or host_payload.get("host")
                or runtime_context.get("host_kind")
                or "CODEX"
            )
        ),
        "host_profile": _turn_redact_text(
            str(
                host_payload.get("host_profile")
                or runtime_context.get("host_profile")
                or "UNAVAILABLE"
            )
        ),
        "host_app": _turn_redact_text(
            str(
                host_payload.get("host_app")
                or host_payload.get("app")
                or runtime_context.get("host_app")
                or "UNAVAILABLE"
            )
        ),
        "host_session_id_sha256": (
            sha256_bytes(host_session_id.encode("utf-8"))
            if host_session_id
            else None
        ),
        "raw_host_session_id_stored": False,
    }
    _require(
        not contains_secret(identity),
        "TURN_CONTROL_HOST_IDENTITY_REDACTION_FAILED",
        "A secret-like value remained in the privacy-safe host identity.",
    )
    return identity


def _require(condition: bool, code: str, message: str, **details: Any) -> None:
    if not condition:
        raise TurnControlError(code, message, **details)


def _json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise TurnControlError(
            "TURN_CONTROL_AUTHORITY_UNREADABLE",
            "A required governed authority file could not be verified.",
            path=str(path),
            error_type=type(exc).__name__,
        ) from exc
    _require(
        isinstance(payload, dict),
        "TURN_CONTROL_AUTHORITY_INVALID",
        "A required governed authority is not a JSON object.",
        path=str(path),
    )
    return payload


def _within(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def _runtime_activation(root: Path) -> dict[str, Any]:
    path = root / "installation" / "runtime_activation.json"
    if not path.is_file():
        return {"state": "DETACHED", "active_sessions": []}
    try:
        payload = _json(path)
    except TurnControlError:
        return {
            "state": "DETACHED",
            "active_sessions": [],
            "reason": "RUNTIME_ACTIVATION_RECEIPT_INVALID",
        }
    sessions = payload.get("active_sessions")
    if (
        payload.get("schema") != "evidence-lane.runtime-activation.v1"
        or payload.get("plugin_id") != "evidence-lane-plugin"
        or payload.get("state") != "ACTIVE"
        or not isinstance(sessions, list)
        or not sessions
        or payload.get("prompt_capture_active") is not True
        or payload.get("visible_response_capture_active") is not True
    ):
        return {"state": "DETACHED", "active_sessions": []}
    return payload


def _package_surface_inventory() -> dict[str, Any]:
    plugin_root = Path(__file__).resolve().parents[2]
    hook_paths = [
        plugin_root / "hooks" / "hooks.json",
        *sorted((plugin_root / "hooks").glob("*.py")),
    ]
    skill_paths = sorted((plugin_root / "skills").glob("*/SKILL.md"))
    _require(
        all(path.is_file() for path in hook_paths),
        "TURN_CONTROL_PACKAGE_HOOK_INVENTORY_REQUIRED",
        "The installed persistent hook inventory is incomplete.",
    )

    def inventory(paths: list[Path], *, skill: bool) -> dict[str, Any]:
        records = [
            {
                "name": path.parent.name if skill else path.name,
                "sha256": sha256_file(path),
            }
            for path in paths
        ]
        _require(
            len(records) == len({row["name"] for row in records}),
            "TURN_CONTROL_PACKAGE_SURFACE_DUPLICATE",
            "An installed hook or skill name is duplicated.",
        )
        return {
            "count": len(records),
            "records": records,
            "inventory_sha256": sha256_bytes(canonical_json_bytes(records)),
        }

    hook_files = inventory(hook_paths, skill=False)
    hook_configuration = _json(plugin_root / "hooks" / "hooks.json")
    hook_events = dict(hook_configuration.get("hooks") or {})
    registered_events = sorted(hook_events)
    handler_count = sum(
        len(group.get("hooks") or [])
        for groups in hook_events.values()
        if isinstance(groups, list)
        for group in groups
        if isinstance(group, dict)
    )
    _require(
        registered_events
        == [
            "PostCompact",
            "PostToolUse",
            "PreCompact",
            "PreToolUse",
            "SessionEnd",
            "SessionStart",
            "Stop",
            "UserPromptSubmit",
        ]
        and handler_count == 8,
        "TURN_CONTROL_PACKAGE_HOOK_EVENT_INVENTORY_REQUIRED",
        "The installed persistent hook event inventory is not exact.",
    )
    hook_inventory = {
        "count": len(registered_events),
        "count_semantics": "REGISTERED_EVENT_COUNT",
        "registered_event_count": len(registered_events),
        "registered_events": registered_events,
        "handler_count": handler_count,
        "hook_file_count": hook_files["count"],
        "records": hook_files["records"],
        "file_inventory_sha256": hook_files["inventory_sha256"],
        "event_inventory_sha256": sha256_bytes(
            canonical_json_bytes(registered_events)
        ),
    }
    hook_inventory["inventory_sha256"] = sha256_bytes(
        canonical_json_bytes(hook_inventory)
    )
    manifest = _json(plugin_root / ".codex-plugin" / "plugin.json")
    release_path = plugin_root / "scripts" / "codex-release-channel.json"
    release = _json(release_path)
    stable = dict(release.get("stable") or {})
    core = {
        "schema": "evidence-lane.codex-installed-surface-inventory.v2",
        "plugin_version": str(manifest.get("version") or ""),
        "hooks": hook_inventory,
        "skills": inventory(skill_paths, skill=True),
        "catalog": {
            "tools": stable.get("native_tool_count"),
            "read": stable.get("native_read_tool_count"),
            "write": stable.get("native_write_tool_count"),
            "skills": stable.get("skill_count"),
        },
        "raw_paths_included": False,
    }
    core["surface_inventory_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return {
        **core,
        "release_policy_sha256": sha256_file(release_path),
        "tunnel_channel": stable.get("tunnel_channel"),
    }


def package_surface_inventory() -> dict[str, Any]:
    """Return the sealed installed Codex surface inventory for native receipts."""

    return _package_surface_inventory()


def _powershell_ordered_json_sha256(value: dict[str, Any]) -> str:
    """Match ConvertTo-Json -Compress for the bounded ASCII recovery registry."""

    return sha256_bytes(
        json.dumps(
            value,
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )


def verify_codex_fallback_prewarmer(
    root: Path,
    *,
    project_id: str,
    session_id: str,
    codex_home: Path | None = None,
) -> dict[str, Any]:
    """Verify the disabled accepted-PV fallback and exact task recovery bind.

    This is a local read-only proof.  It does not activate a plugin, start a
    server or tunnel, restart Codex, mutate source, build a candidate, or move
    the accepted pointer.  The registry is self-sealed and every referenced
    installation/preparation byte is re-hashed before the proof is returned.
    """

    installation_root = root / "installations" / "codex-v200"
    registry_path = installation_root / "two-slot" / "CODEX_TWO_SLOT_REGISTRY.json"
    _require(
        registry_path.is_file(),
        "FALLBACK_PREWARM_REGISTRY_REQUIRED",
        "The sealed Codex two-slot recovery registry is missing.",
    )
    registry = _json(registry_path)
    registry_body = {
        key: value
        for key, value in registry.items()
        if key not in {"seal", "registry_body_sha256"}
    }
    sealed_registry_body = {
        key: value for key, value in registry.items() if key != "seal"
    }
    seal = dict(registry.get("seal") or {})
    _require(
        registry.get("schema") == "evidence-lane.codex-two-slot-registry.v1"
        and registry.get("status") == "PASS"
        and registry.get("state") == "STABLE_ACTIVE_FALLBACK_PREWARMED_DISABLED"
        and registry.get("project_id") == project_id
        and registry.get("evidence_session_id") == session_id
        and registry.get("accepted_pv") == "PV11"
        and registry.get("accepted_generation") == 11
        and registry.get("prior_generation") == 10
        and registry.get("active_slot") == "stable-build"
        and registry.get("exact_live_slot_count") == 2
        and registry.get("max_enabled_plugin_count") == 1
        and registry.get("max_active_native_mcp_count") == 1
        and registry.get("max_active_tunnel_count") == 0
        and registry.get("tunnel_required") is False
        and registry.get("tunnel_started") is False
        and registry.get("server_has_durable_filesystem") is True
        and registry.get("secret_material_present") is False
        and registry.get("registry_body_sha256")
        == _powershell_ordered_json_sha256(registry_body)
        and seal.get("algorithm") == "SHA256"
        and seal.get("body_sha256")
        == _powershell_ordered_json_sha256(sealed_registry_body),
        "FALLBACK_PREWARM_REGISTRY_INVALID",
        "The Codex two-slot recovery registry is not the exact sealed PV11 boundary.",
    )
    slots = dict(registry.get("slots") or {})
    stable = dict(slots.get("stable-build") or {})
    fallback = dict(slots.get("fallback") or {})
    _require(
        len(slots) == 2
        and stable.get("slot_role") == "stable-build"
        and stable.get("enabled") is True
        and stable.get("native_mcp_enabled") is True
        and stable.get("byte_frozen") is False
        and fallback.get("slot_role") == "fallback"
        and fallback.get("enabled") is False
        and fallback.get("native_mcp_enabled") is False
        and fallback.get("byte_frozen") is True
        and fallback.get("accepted_pv") == "PV11"
        and fallback.get("accepted_generation") == 11
        and fallback.get("package_sha256")
        == registry.get("accepted_package_sha256")
        and fallback.get("plugin_version")
        == registry.get("accepted_plugin_version")
        and dict(stable.get("tunnel") or {}).get("required") is False
        and dict(fallback.get("tunnel") or {}).get("required") is False,
        "FALLBACK_PREWARM_SLOT_INVALID",
        "Stable and fallback are not the exact mutually exclusive two-slot boundary.",
    )

    fallback_receipt_path = Path(str(fallback.get("install_receipt") or ""))
    _require(
        fallback_receipt_path.is_absolute()
        and _within(fallback_receipt_path, installation_root)
        and fallback_receipt_path.is_file(),
        "FALLBACK_PREWARM_INSTALL_RECEIPT_REQUIRED",
        "The fallback installation receipt is missing or outside its authority root.",
    )
    fallback_receipt_file_sha256 = sha256_file(fallback_receipt_path)
    _require(
        fallback_receipt_file_sha256 == fallback.get("install_receipt_sha256"),
        "FALLBACK_PREWARM_INSTALL_RECEIPT_FILE_SEAL_MISMATCH",
        "The fallback installation receipt file seal does not match the registry.",
    )
    fallback_receipt = _json(fallback_receipt_path)
    fallback_receipt_body = {
        key: value
        for key, value in fallback_receipt.items()
        if key != "receipt_sha256"
    }
    activation = dict(fallback_receipt.get("activation") or {})
    catalog = dict((fallback_receipt.get("plugin") or {}).get("catalog") or {})
    source_parity = dict(fallback_receipt.get("source_parity") or {})
    fallback_install_stable_selector = str(
        activation.get("stable_selector") or ""
    )
    known_stable_selectors = {
        str(stable.get("plugin_selector") or ""),
        *(
            str(value)
            for value in registry.get("historical_disabled_entries") or []
        ),
    }
    _require(
        fallback_receipt.get("schema")
        == "evidence-lane.codex-stable-installation.v2"
        and fallback_receipt.get("status") == "PASS"
        and fallback_receipt.get("project_id") == project_id
        and fallback_receipt.get("evidence_session_id") == session_id
        and fallback_receipt.get("task_id") == registry.get("task_id")
        and fallback_receipt.get("host_session_id")
        == registry.get("host_session_id")
        and fallback_receipt.get("accepted_pv") == "PV11"
        and fallback_receipt.get("accepted_generation") == 11
        and fallback_receipt.get("accepted_manifest_sha256")
        == registry.get("accepted_manifest_sha256")
        and fallback_receipt.get("archive_sha256")
        == fallback.get("package_sha256")
        and fallback_receipt.get("byte_frozen") is True
        and fallback_receipt.get("slot_role") == "fallback"
        and fallback_receipt.get("receipt_sha256")
        == _powershell_ordered_json_sha256(fallback_receipt_body)
        and activation.get("plugin_selector") == fallback.get("plugin_selector")
        and activation.get("plugin_enabled") is False
        and activation.get("mcp_enabled") is False
        and activation.get("active_server_started") is False
        and activation.get("restart_invoked") is False
        and fallback_install_stable_selector in known_stable_selectors
        and fallback_install_stable_selector != fallback.get("plugin_selector")
        and activation.get("stable_plugin_enabled") is True
        and activation.get("stable_mcp_enabled") is True
        and catalog == {"tools": 62, "read": 21, "write": 41, "skills": 15}
        and source_parity.get("mismatch_count") == 0
        and fallback_receipt.get("generated_cache_written_directly") is False
        and fallback_receipt.get("supported_cli_materialization") is True
        and fallback_receipt.get("shadow_junction_removed") is True
        and fallback_receipt.get("source_mutated") is False
        and fallback_receipt.get("git_mutated") is False
        and fallback_receipt.get("candidate_created_or_accepted") is False
        and fallback_receipt.get("pointer_moved") is False
        and fallback_receipt.get("hil_inferred") is False
        and fallback_receipt.get("tunnel_started") is False,
        "FALLBACK_PREWARM_INSTALL_RECEIPT_INVALID",
        "The fallback installation receipt is not an exact disabled accepted-PV11 proof.",
    )

    exact_codex_home = (codex_home or (Path.home() / ".codex")).resolve()
    config_path = exact_codex_home / "config.toml"
    _require(
        config_path.is_file(),
        "FALLBACK_PREWARM_CODEX_CONFIG_REQUIRED",
        "The live Codex configuration is unavailable.",
    )
    try:
        configured = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, tomllib.TOMLDecodeError) as exc:
        raise TurnControlError(
            "FALLBACK_PREWARM_CODEX_CONFIG_INVALID",
            "The live Codex configuration could not be parsed.",
            error_type=type(exc).__name__,
        ) from exc
    plugin_config = dict(configured.get("plugins") or {})
    evidence_selectors = sorted(
        key for key in plugin_config if str(key).startswith("evidence-lane-plugin@")
    )
    expected_selectors = {
        str(stable.get("plugin_selector")),
        str(fallback.get("plugin_selector")),
    }
    _require(
        expected_selectors.issubset(evidence_selectors),
        "FALLBACK_PREWARM_CODEX_SLOT_CONFIG_MISSING",
        "The live Codex configuration is missing a current recovery slot.",
    )
    enabled_selectors: list[str] = []
    for selector in evidence_selectors:
        entry = dict(plugin_config.get(selector) or {})
        mcp = dict((entry.get("mcp_servers") or {}).get("evidence-lane") or {})
        plugin_enabled = entry.get("enabled") is True
        mcp_enabled = mcp.get("enabled") is True
        _require(
            plugin_enabled == mcp_enabled,
            "FALLBACK_PREWARM_CODEX_SLOT_CONFIG_SPLIT",
            "One Evidence Lane plugin/MCP registration has split activation state.",
            selector=selector,
        )
        if plugin_enabled:
            enabled_selectors.append(selector)
        elif selector not in expected_selectors:
            _require(
                entry.get("enabled") is False and mcp.get("enabled") is False,
                "FALLBACK_PREWARM_HISTORICAL_SLOT_NOT_DISABLED",
                "An older Evidence Lane registration is not explicitly disabled.",
                selector=selector,
            )
    _require(
        enabled_selectors == [stable.get("plugin_selector")],
        "FALLBACK_PREWARM_CODEX_EXCLUSIVE_ACTIVATION_MISMATCH",
        "Stable must remain the sole enabled Evidence Lane route.",
        enabled_selectors=enabled_selectors,
    )

    cache_root = exact_codex_home / "plugins" / "cache"
    marketplace_root = exact_codex_home / "local-marketplaces"
    for name, slot in (("stable-build", stable), ("fallback", fallback)):
        cache = Path(str(slot.get("cache_root") or ""))
        marketplace = Path(str(slot.get("marketplace_root") or ""))
        _require(
            cache.is_dir()
            and marketplace.is_dir()
            and _within(cache, cache_root)
            and _within(marketplace, marketplace_root),
            "FALLBACK_PREWARM_SLOT_BYTES_REQUIRED",
            "A current Codex recovery slot is missing or outside the installed roots.",
            slot=name,
        )
        plugin_manifest = cache / ".codex-plugin" / "plugin.json"
        marketplace_manifest = marketplace / ".agents" / "plugins" / "marketplace.json"
        _require(
            plugin_manifest.is_file()
            and marketplace_manifest.is_file()
            and sha256_file(plugin_manifest) == slot.get("plugin_manifest_sha256")
            and sha256_file(marketplace_manifest)
            == slot.get("marketplace_catalog_sha256")
            and _json(plugin_manifest).get("version") == slot.get("plugin_version"),
            "FALLBACK_PREWARM_SLOT_MANIFEST_SEAL_MISMATCH",
            "An installed recovery-slot manifest or version does not match its seal.",
            slot=name,
        )

    task_id = str(registry.get("task_id") or "")
    task_binding_path = Path(
        str(registry.get("fallback_recovery_task_binding") or "")
    )
    _require(
        _CODEX_TASK_ID_RE.fullmatch(task_id) is not None
        and task_binding_path.is_absolute()
        and _within(task_binding_path, installation_root / "two-slot")
        and task_binding_path.is_file()
        and sha256_file(task_binding_path)
        == registry.get("fallback_recovery_task_binding_sha256"),
        "FALLBACK_PREWARM_TASK_BINDING_REQUIRED",
        "The exact sealed fallback task recovery binding is missing or stale.",
    )
    task_binding = _json(task_binding_path)
    preparation_path = Path(str(task_binding.get("preparation_receipt") or ""))
    install_path = Path(str(task_binding.get("install_receipt") or ""))
    _require(
        task_binding.get("schema") == "evidence-lane.codex-task-binding.v1"
        and task_binding.get("state") == "EXACT_TASK_BINDING_PREPARED"
        and task_binding.get("project_id") == project_id
        and task_binding.get("evidence_session_id") == session_id
        and task_binding.get("task_id") == task_id
        and task_binding.get("governed_host_session_id")
        == registry.get("host_session_id")
        and task_binding.get("plugin_version") == fallback.get("plugin_version")
        and task_binding.get("task_uri_sha256")
        == sha256_bytes(f"codex://threads/{task_id}".encode())
        and task_binding.get("claim_scope") == "EXACT_CODEX_THREAD_ID_ONLY"
        and task_binding.get("alias_claim_allowed") is True
        and task_binding.get("source_mutated") is False
        and task_binding.get("candidate_created_or_accepted") is False
        and task_binding.get("pointer_moved") is False
        and task_binding.get("hil_inferred") is False
        and preparation_path.is_absolute()
        and _within(preparation_path, installation_root)
        and preparation_path.is_file()
        and install_path == fallback_receipt_path
        and task_binding.get("install_receipt_sha256")
        == fallback_receipt_file_sha256
        and task_binding.get("preparation_receipt_sha256")
        == sha256_file(preparation_path),
        "FALLBACK_PREWARM_TASK_BINDING_INVALID",
        "The current Codex task recovery binding is stale, cross-task, or promoting.",
    )
    preparation = _json(preparation_path)
    continuation = dict(preparation.get("continuation") or {})
    _require(
        preparation.get("schema") == "evidence-lane.codex-restart-preparation.v2"
        and preparation.get("state") == "PREPARED_NOT_RESTARTED"
        and preparation.get("project_id") == project_id
        and preparation.get("evidence_session_id") == session_id
        and preparation.get("task_id") == task_id
        and preparation.get("host_session_id") == registry.get("host_session_id")
        and preparation.get("install_receipt_sha256")
        == fallback_receipt_file_sha256
        and preparation.get("plugin_version") == fallback.get("plugin_version")
        and continuation.get("same_task_required") is True
        and continuation.get("task_navigation_mode") == "CODEX_THREAD_DEEPLINK"
        and continuation.get("task_uri_sha256")
        == task_binding.get("task_uri_sha256")
        and continuation.get("coordinate_clicking_used") is False
        and continuation.get("lifecycle_resume_call_required") is False
        and continuation.get("state_travel_required") is False
        and preparation.get("hot_reload_claimed") is False
        and preparation.get("process_stopped") is False
        and preparation.get("source_mutated") is False
        and preparation.get("candidate_created_or_accepted") is False
        and preparation.get("pointer_moved") is False
        and preparation.get("hil_inferred") is False,
        "FALLBACK_PREWARM_RESTART_PREPARATION_INVALID",
        "The recovery helper did not prepare this exact task without restarting it.",
    )

    running_plugin_root = Path(__file__).resolve().parents[2]
    switch_helper = running_plugin_root / "scripts" / "codex_release" / "Switch-EvidenceLaneCodexSlot.ps1"
    restart_helper = running_plugin_root / "scripts" / "codex_release" / "Restart-EvidenceLaneCodex.ps1"
    _require(
        switch_helper.is_file()
        and restart_helper.is_file()
        and sha256_file(switch_helper) == registry.get("switch_helper_sha256")
        and sha256_file(restart_helper) == registry.get("restart_helper_sha256"),
        "FALLBACK_PREWARM_RECOVERY_HELPER_SEAL_MISMATCH",
        "The running stable package does not contain the helpers sealed by the recovery registry.",
    )

    proof = {
        "schema": "evidence-lane.codex-fallback-prewarm-proof.v1",
        "status": "PASS",
        "project_id": project_id,
        "session_id": session_id,
        "task_id": task_id,
        "host_session_id": registry.get("host_session_id"),
        "accepted_pv": "PV11",
        "accepted_generation": 11,
        "accepted_manifest_sha256": registry.get("accepted_manifest_sha256"),
        "registry_sha256": sha256_file(registry_path),
        "fallback_install_receipt_sha256": fallback_receipt_file_sha256,
        "task_binding_receipt_sha256": sha256_file(task_binding_path),
        "restart_preparation_receipt_sha256": sha256_file(preparation_path),
        "config_sha256": sha256_file(config_path),
        "stable_plugin_selector": stable.get("plugin_selector"),
        "fallback_plugin_selector": fallback.get("plugin_selector"),
        "fallback_package_sha256": fallback.get("package_sha256"),
        "fallback_byte_frozen": True,
        "stable_enabled": True,
        "fallback_enabled": False,
        "enabled_evidence_lane_plugin_count": 1,
        "active_tunnel_count": 0,
        "tunnel_required": False,
        "current_task_recovery_prepared": True,
        "restart_invoked": False,
        "fallback_activated": False,
        "source_mutated": False,
        "git_mutated": False,
        "candidate_created": False,
        "pending_hil": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "verified_at": _now(),
    }
    return {
        **proof,
        "receipt_sha256": sha256_bytes(canonical_json_bytes(proof)),
    }


def _package_update_status(root: Path) -> dict[str, Any]:
    current = _package_surface_inventory()
    receipt_path = (
        root
        / "installations"
        / "codex-v200"
        / "CURRENT_INSTALLATION.json"
    )
    installation: dict[str, Any] | None = None
    change: dict[str, Any] | None = None
    if receipt_path.is_file():
        candidate = _json(receipt_path)
        claimed = str(candidate.get("receipt_sha256") or "")
        actual = sha256_bytes(
            canonical_json_bytes(
                {
                    key: value
                    for key, value in candidate.items()
                    if key != "receipt_sha256"
                }
            )
        )
        if claimed == actual:
            candidate_change = dict(candidate.get("surface_change_display") or {})
            if (
                candidate.get("schema")
                == "evidence-lane.codex-stable-installation.v2"
                and candidate.get("status") == "PASS"
                and candidate_change.get("schema")
                == "evidence-lane.codex-installed-surface-change-display.v2"
                and candidate_change.get("current_surface_inventory_sha256")
                == current["surface_inventory_sha256"]
                and candidate_change.get("raw_paths_included") is False
                and candidate_change.get("private_research_question_included")
                is False
            ):
                installation = candidate
                change = candidate_change

    activation = _runtime_activation(root)
    if installation is not None and change is not None:
        state = "INSTALLED_SURFACE_RECEIPT_VERIFIED"
        installed_version = str((installation.get("plugin") or {}).get("version") or "")
        hook_change = dict(change.get("hooks") or {})
        skill_change = dict(change.get("skills") or {})
        catalog = dict(change.get("catalog") or {})
        install_receipt_sha256 = installation.get("receipt_sha256")
        activation_state = str(
            (installation.get("activation") or {}).get("state") or "UNSPECIFIED"
        )
    else:
        state = "PACKAGE_SURFACE_VISIBLE_INSTALL_RECEIPT_UNAVAILABLE_OR_STALE"
        installed_version = None
        hook_change = {
            "count": current["hooks"]["count"],
            "count_semantics": "REGISTERED_EVENT_COUNT",
            "registered_event_count": current["hooks"][
                "registered_event_count"
            ],
            "registered_events": current["hooks"]["registered_events"],
            "handler_count": current["hooks"]["handler_count"],
            "hook_file_count": current["hooks"]["hook_file_count"],
            "added": [],
            "changed": [],
            "removed": [],
            "inventory_sha256": current["hooks"]["inventory_sha256"],
            "change_classification": "INSTALL_RECEIPT_UNAVAILABLE",
        }
        skill_change = {
            "count": current["skills"]["count"],
            "added": [],
            "changed": [],
            "removed": [],
            "inventory_sha256": current["skills"]["inventory_sha256"],
            "change_classification": "INSTALL_RECEIPT_UNAVAILABLE",
        }
        catalog = dict(current["catalog"])
        catalog["changed_from_previous"] = None
        install_receipt_sha256 = None
        activation_state = "INSTALL_RECEIPT_UNAVAILABLE"

    manifest_version = str(current["plugin_version"])
    version_state = (
        "EXACT"
        if installed_version == manifest_version
        and manifest_version.split("+", 1)[0] == ENGINE_VERSION
        else "SOURCE_RUNTIME_EXACT_INSTALL_RECEIPT_UNAVAILABLE"
        if installed_version is None
        and manifest_version.split("+", 1)[0] == ENGINE_VERSION
        else "MISMATCH"
    )
    core = {
        "schema": "evidence-lane.codex-package-update-status.v2",
        "state": state,
        "source_plugin_version": manifest_version,
        "installed_plugin_version": installed_version,
        "runtime_engine_version": ENGINE_VERSION,
        "version_state": version_state,
        "hooks": hook_change,
        "skills": skill_change,
        "catalog": catalog,
        "surface_inventory_sha256": current["surface_inventory_sha256"],
        "release_policy_sha256": current["release_policy_sha256"],
        "install_receipt_sha256": install_receipt_sha256,
        "installation_activation_state": activation_state,
        "runtime_activation_state": activation.get("state"),
        "tunnel_channel": current["tunnel_channel"],
        "refresh_state": "BOUND_LATER_TO_CURRENT_CANDIDATE_BOUNDARY",
        "raw_paths_included": False,
        "private_research_question_included": False,
        "private_reasoning_stored": False,
    }
    core["package_update_status_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def _host_binding_epoch(session: dict[str, Any]) -> str:
    """Seal the exact governed host binding without storing its raw identity."""

    metadata = dict(session.get("metadata") or {})
    travel = dict(metadata.get("state_travel") or {})
    resume_contract = dict(travel.get("resume_contract") or {})
    governed_host_session_id = str(
        metadata.get("current_host_session_id") or ""
    ).strip()
    core = {
        "schema": "evidence-lane.codex-host-binding-epoch.v1",
        "project_id": session.get("project_id"),
        "evidence_session_id": session.get("session_id"),
        "governed_host_session_id_sha256": sha256_bytes(
            governed_host_session_id.encode("utf-8")
        ),
        "accepted_pv": session.get("accepted_pv"),
        "accepted_pointer_generation": session.get(
            "accepted_pointer_generation"
        ),
        "active_backlog_task_id": metadata.get("active_backlog_task_id"),
        "active_backlog_task_status": metadata.get("active_backlog_task_status"),
        "runtime_task_id": (
            dict(session.get("task") or {}).get("task_id")
            if isinstance(session.get("task"), dict)
            else None
        ),
        "state_travel_handoff_sha256": travel.get("handoff_sha256"),
        "state_travel_verified_snapshot_sha256": travel.get(
            "verified_snapshot_sha256"
        ),
        "state_travel_task_list_sha256": resume_contract.get(
            "task_list_sha256"
        ),
        "state_travel_additive_deltas_sha256": resume_contract.get(
            "additive_deltas_sha256"
        ),
    }
    return sha256_bytes(canonical_json_bytes(core))


def _host_transcript_sha256(transcript_path: str) -> str | None:
    exact = str(transcript_path or "").strip()
    if not exact:
        return None
    path = Path(exact)
    if not path.is_absolute() or not path.is_file():
        return None
    try:
        normalized = os.path.normcase(str(path.resolve(strict=True)))
    except OSError:
        return None
    return sha256_bytes(normalized.encode("utf-8"))


def _read_codex_task_binding(
    root: Path,
    *,
    observed_host_session_id: str,
) -> dict[str, Any] | None:
    """Verify one installer-prepared exact Codex thread binding.

    A Codex task can intentionally use a task-shell workspace that is outside the
    governed repository.  In that case repository CWD is not a valid discovery
    signal.  The stable restart helper therefore prepares one receipt that binds
    the exact Codex thread UUID to the already-governed project/session before a
    restart.  This reader accepts only the current installed package and never
    searches by task title, CWD, or another active project.
    """

    task_id = str(observed_host_session_id or "").strip()
    if not _CODEX_TASK_ID_RE.fullmatch(task_id):
        return None
    installation_root = root / "installations" / "codex-v200"
    path = installation_root / "task-bindings" / f"{task_id.lower()}.json"
    if not path.is_file():
        return None
    binding = _json(path)
    _require(
        binding.get("schema") == "evidence-lane.codex-task-binding.v1"
        and binding.get("state") == "EXACT_TASK_BINDING_PREPARED"
        and binding.get("task_id") == task_id
        and binding.get("alias_claim_allowed") is True
        and binding.get("claim_scope") == "EXACT_CODEX_THREAD_ID_ONLY"
        and binding.get("source_mutated") is False
        and binding.get("candidate_created_or_accepted") is False
        and binding.get("pointer_moved") is False
        and binding.get("hil_inferred") is False,
        "TURN_CONTROL_CODEX_TASK_BINDING_INVALID",
        "The exact Codex task binding receipt is invalid.",
        task_id=task_id,
    )
    expected_task_uri_sha256 = sha256_bytes(
        f"codex://threads/{task_id}".encode()
    )
    _require(
        binding.get("task_uri_sha256") == expected_task_uri_sha256,
        "TURN_CONTROL_CODEX_TASK_URI_MISMATCH",
        "The exact Codex task binding does not match its deeplink identity.",
    )
    preparation_path = Path(str(binding.get("preparation_receipt") or ""))
    install_path = Path(str(binding.get("install_receipt") or ""))
    _require(
        preparation_path.is_absolute()
        and install_path.is_absolute()
        and _within(preparation_path, installation_root)
        and _within(install_path, installation_root)
        and preparation_path.is_file()
        and install_path.is_file(),
        "TURN_CONTROL_CODEX_TASK_BINDING_AUTHORITY_REQUIRED",
        "The exact Codex task binding authorities are missing or out of scope.",
    )
    preparation_sha256 = _sha(
        binding.get("preparation_receipt_sha256"),
        field="task_binding.preparation_receipt_sha256",
    )
    install_sha256 = _sha(
        binding.get("install_receipt_sha256"),
        field="task_binding.install_receipt_sha256",
    )
    _require(
        sha256_file(preparation_path) == preparation_sha256
        and sha256_file(install_path) == install_sha256,
        "TURN_CONTROL_CODEX_TASK_BINDING_SEAL_MISMATCH",
        "The exact Codex task binding authority seal does not match.",
    )
    preparation = _json(preparation_path)
    installation = _json(install_path)
    current_installation_path = installation_root / "CURRENT_INSTALLATION.json"
    _require(
        current_installation_path.is_file()
        and sha256_file(current_installation_path) == install_sha256,
        "TURN_CONTROL_CODEX_TASK_BINDING_INSTALLATION_STALE",
        "The exact Codex task binding does not reference the current stable installation.",
    )
    plugin_manifest = _json(
        Path(__file__).resolve().parents[2] / ".codex-plugin" / "plugin.json"
    )
    plugin_version = str(plugin_manifest.get("version") or "")
    _require(
        preparation.get("schema") == "evidence-lane.codex-restart-preparation.v2"
        and preparation.get("state") == "PREPARED_NOT_RESTARTED"
        and preparation.get("project_id") == binding.get("project_id")
        and preparation.get("evidence_session_id")
        == binding.get("evidence_session_id")
        and preparation.get("task_id") == task_id
        and preparation.get("host_session_id")
        == binding.get("governed_host_session_id")
        and preparation.get("install_receipt_sha256") == install_sha256
        and preparation.get("plugin_version") == plugin_version
        and installation.get("schema")
        == "evidence-lane.codex-stable-installation.v2"
        and installation.get("status") == "PASS"
        and dict(installation.get("plugin") or {}).get("version") == plugin_version
        and binding.get("plugin_version") == plugin_version,
        "TURN_CONTROL_CODEX_TASK_BINDING_DRIFT",
        "The exact Codex task, preparation, and current stable installation do not agree.",
    )
    return {
        **binding,
        "task_binding_receipt_sha256": sha256_file(path),
        "preparation_receipt_sha256": preparation_sha256,
        "install_receipt_sha256": install_sha256,
    }


def _read_host_alias(
    project_root: Path,
    *,
    session: dict[str, Any],
    observed_host_session_id: str,
    transcript_path: str,
) -> dict[str, Any] | None:
    transcript_sha256 = _host_transcript_sha256(transcript_path)
    if not observed_host_session_id or transcript_sha256 is None:
        return None
    database = project_root / "lineage" / "codex_turn_control.sqlite"
    if not database.is_file():
        return None
    observed_sha256 = sha256_bytes(observed_host_session_id.encode("utf-8"))
    binding_epoch_sha256 = _host_binding_epoch(session)
    try:
        connection = sqlite3.connect(
            f"file:{database.as_posix()}?mode=ro",
            uri=True,
            timeout=5,
        )
        connection.row_factory = sqlite3.Row
        try:
            row = connection.execute(
                """
                SELECT alias_receipt_sha256, record_json
                FROM host_session_alias
                WHERE observed_host_session_id_sha256=?
                  AND binding_epoch_sha256=?
                """,
                (observed_sha256, binding_epoch_sha256),
            ).fetchone()
        finally:
            connection.close()
    except sqlite3.Error:
        return None
    if row is None:
        return None
    try:
        record = json.loads(row["record_json"])
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    claimed = str(record.get("alias_receipt_sha256") or "")
    actual = sha256_bytes(
        canonical_json_bytes(
            {
                key: value
                for key, value in record.items()
                if key != "alias_receipt_sha256"
            }
        )
    )
    if (
        claimed != actual
        or claimed != row["alias_receipt_sha256"]
        or record.get("project_id") != session.get("project_id")
        or record.get("evidence_session_id") != session.get("session_id")
        or record.get("observed_host_session_id_sha256") != observed_sha256
        or record.get("transcript_path_sha256") != transcript_sha256
        or record.get("binding_epoch_sha256") != binding_epoch_sha256
        or record.get("governed_host_session_id_sha256")
        != sha256_bytes(
            str(
                session.get("metadata", {}).get("current_host_session_id") or ""
            ).encode("utf-8")
        )
        or record.get("raw_host_identity_stored") is not False
        or record.get("raw_transcript_path_stored") is not False
    ):
        return None
    return record


def _session_candidates(
    root: Path,
    *,
    host_session_id: str,
    cwd: str,
    transcript_path: str = "",
) -> list[dict[str, Any]]:
    projects_root = root / "projects"
    if not projects_root.is_dir():
        return []
    exact: list[dict[str, Any]] = []
    cwd_matches: list[dict[str, Any]] = []
    task_binding = _read_codex_task_binding(
        root,
        observed_host_session_id=host_session_id,
    )
    current_cwd = Path(cwd).resolve() if cwd else None
    for project_root in sorted(projects_root.iterdir(), key=lambda item: item.name):
        if not project_root.is_dir():
            continue
        try:
            active = _json(project_root / "active_session.json")
            session = _json(project_root / "sessions" / f"{active['session_id']}.json")
            project = _json(project_root / "project.json")
        except (TurnControlError, KeyError):
            continue
        if session.get("metadata", {}).get("closed_at"):
            continue
        row = {
            "project_root": project_root,
            "project": project,
            "session": session,
            "binding_match": "UNRESOLVED",
        }
        if (
            session.get("metadata", {}).get("current_host_session_id")
            == host_session_id
        ):
            row["binding_match"] = "EXACT_HOST_SESSION"
            exact.append(row)
        elif _read_host_alias(
            project_root,
            session=session,
            observed_host_session_id=host_session_id,
            transcript_path=transcript_path,
        ) is not None:
            row["binding_match"] = "SEALED_CODEX_HOST_ALIAS"
            exact.append(row)
        elif (
            task_binding is not None
            and task_binding.get("project_id") == session.get("project_id")
            and task_binding.get("evidence_session_id") == session.get("session_id")
            and task_binding.get("governed_host_session_id")
            == session.get("metadata", {}).get("current_host_session_id")
        ):
            row["binding_match"] = "PREPARED_CODEX_TASK_BINDING"
            row["task_binding"] = task_binding
            exact.append(row)
        elif current_cwd and _within(
            current_cwd, Path(str(project["repository_path"]))
        ):
            row["binding_match"] = "CWD_ONLY_STALE_OR_MISSING_HOST"
            cwd_matches.append(row)
    if exact:
        return exact
    return cwd_matches


def policy_state(
    store_root: str | Path,
    *,
    host_session_id: str,
    cwd: str,
    transcript_path: str = "",
) -> dict[str, Any]:
    """Return whether this host turn is governed and strict-control eligible."""

    root = Path(store_root).resolve()
    candidates = _session_candidates(
        root,
        host_session_id=host_session_id.strip(),
        cwd=cwd,
        transcript_path=transcript_path,
    )
    if not candidates:
        return {
            "governed_session": False,
            "strict_required": False,
            "reason": "NO_BOUND_EVIDENCE_LANE_SESSION",
        }
    if len(candidates) != 1:
        return {
            "governed_session": True,
            "strict_required": True,
            "reason": "AMBIGUOUS_GOVERNED_SESSION_BINDING",
        }
    candidate = candidates[0]
    session = candidate["session"]
    metadata = session.get("metadata") or {}
    active_mode = metadata.get("active_mode_binding")
    resume_contract = (metadata.get("state_travel") or {}).get("resume_contract") or {}
    task_list = resume_contract.get("task_list") or []
    active_rows = [
        row
        for row in task_list
        if isinstance(row, dict)
        and str(row.get("status") or "").upper() in _ACTIVE_PLAN_STATUSES
    ]
    required = metadata.get("turn_control_required") is True or (
        isinstance(active_mode, dict) and bool(active_mode) and bool(active_rows)
    )
    return {
        "governed_session": True,
        "strict_required": required,
        "binding_match": candidate.get("binding_match"),
        "reason": (
            "EXACT_GOVERNED_SESSION_BINDING"
            if candidate.get("binding_match") == "EXACT_HOST_SESSION"
            else "SEALED_CODEX_HOST_ALIAS_BINDING"
            if candidate.get("binding_match") == "SEALED_CODEX_HOST_ALIAS"
            else "PREPARED_EXACT_CODEX_TASK_BINDING"
            if candidate.get("binding_match") == "PREPARED_CODEX_TASK_BINDING"
            else "STALE_OR_MISSING_HOST_SESSION_NO_CWD_REBIND"
        ),
        "project_id": session.get("project_id"),
        "evidence_session_id": session.get("session_id"),
        "runtime_state": _runtime_activation(root).get("state"),
        "active_plan_row_count": len(active_rows),
    }


def _one_bound_session(
    root: Path,
    *,
    host_session_id: str,
    cwd: str,
    transcript_path: str = "",
) -> dict[str, Any]:
    candidates = _session_candidates(
        root,
        host_session_id=host_session_id,
        cwd=cwd,
        transcript_path=transcript_path,
    )
    _require(
        len(candidates) == 1,
        "TURN_CONTROL_SESSION_BINDING_REQUIRED",
        "The Codex host turn must bind exactly one governed Evidence Lane session.",
        matching_sessions=len(candidates),
    )
    candidate = candidates[0]
    _require(
        candidate.get("binding_match")
        in {"EXACT_HOST_SESSION", "SEALED_CODEX_HOST_ALIAS"},
        "TURN_CONTROL_EXACT_HOST_BINDING_REQUIRED",
        "Repository location cannot substitute for the exact governed host-session identity.",
        binding_match=candidate.get("binding_match"),
        supplied_host_session_id=host_session_id,
    )
    activation = _runtime_activation(root)
    session = candidate["session"]
    attached = any(
        isinstance(row, dict)
        and row.get("project_id") == session.get("project_id")
        and row.get("session_id") == session.get("session_id")
        for row in activation.get("active_sessions", [])
    )
    _require(
        activation.get("state") == "ACTIVE" and attached,
        "TURN_CONTROL_RUNTIME_ATTACHMENT_REQUIRED",
        "The governed session is not attached to the active Evidence Lane runtime.",
        runtime_state=activation.get("state"),
    )
    return candidate


def _validate_alias_claim_profile(
    candidate: dict[str, Any],
    host_payload: dict[str, Any],
) -> str:
    session = candidate["session"]
    metadata = dict(session.get("metadata") or {})
    travel = dict(metadata.get("state_travel") or {})
    resume_contract = dict(travel.get("resume_contract") or {})
    expected_profile = dict(resume_contract.get("execution_profile") or {})
    expected_model = str(expected_profile.get("model") or "").strip()
    supplied_model = str(host_payload.get("model") or "").strip()
    _require(
        bool(expected_model and supplied_model),
        "TURN_CONTROL_HOST_ALIAS_MODEL_REQUIRED",
        "A one-time Codex host alias claim requires the sealed and observed model identities.",
    )
    _require(
        supplied_model == expected_model,
        "TURN_CONTROL_HOST_ALIAS_MODEL_MISMATCH",
        "The observed Codex model does not match the sealed State Travel profile.",
        expected_model=expected_model,
        supplied_model=supplied_model,
    )
    return supplied_model


def _active_host_alias_collision(
    root: Path,
    *,
    observed_host_session_id_sha256: str,
    selected_project_id: str,
    selected_evidence_session_id: str,
) -> dict[str, Any] | None:
    projects_root = root / "projects"
    if not projects_root.is_dir():
        return None
    for project_root in sorted(projects_root.iterdir(), key=lambda item: item.name):
        if not project_root.is_dir():
            continue
        try:
            active = _json(project_root / "active_session.json")
            session = _json(
                project_root / "sessions" / f"{active['session_id']}.json"
            )
        except (TurnControlError, KeyError):
            continue
        if session.get("metadata", {}).get("closed_at"):
            continue
        database = project_root / "lineage" / "codex_turn_control.sqlite"
        if not database.is_file():
            continue
        try:
            connection = sqlite3.connect(
                f"file:{database.as_posix()}?mode=ro",
                uri=True,
                timeout=5,
            )
            connection.row_factory = sqlite3.Row
            try:
                row = connection.execute(
                    """
                    SELECT alias_receipt_sha256, record_json
                    FROM host_session_alias
                    WHERE observed_host_session_id_sha256=?
                      AND binding_epoch_sha256=?
                    """,
                    (
                        observed_host_session_id_sha256,
                        _host_binding_epoch(session),
                    ),
                ).fetchone()
            finally:
                connection.close()
        except sqlite3.Error:
            continue
        if row is None:
            continue
        try:
            record = json.loads(row["record_json"])
        except (TypeError, ValueError, json.JSONDecodeError):
            return {"state": "INVALID_SEALED_HOST_ALIAS_RECORD"}
        claimed = str(record.get("alias_receipt_sha256") or "")
        actual = sha256_bytes(
            canonical_json_bytes(
                {
                    key: value
                    for key, value in record.items()
                    if key != "alias_receipt_sha256"
                }
            )
        )
        if (
            claimed != actual
            or claimed != row["alias_receipt_sha256"]
            or record.get("observed_host_session_id_sha256")
            != observed_host_session_id_sha256
            or record.get("binding_epoch_sha256")
            != _host_binding_epoch(session)
        ):
            return {"state": "INVALID_SEALED_HOST_ALIAS_RECORD"}
        owner = (
            str(record.get("project_id") or ""),
            str(record.get("evidence_session_id") or ""),
        )
        if owner != (selected_project_id, selected_evidence_session_id):
            return {
                "project_id": owner[0],
                "evidence_session_id": owner[1],
                "alias_receipt_sha256": record.get("alias_receipt_sha256"),
            }
    return None


def bind_codex_host_payload(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
    event_name: str,
    allow_alias_claim: bool,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Normalize a Codex-native session id to one sealed State Travel identity.

    Codex hook payloads carry Codex's session id, while a governed State Travel
    contract may deliberately use a separate destination identity.  This helper
    permits exactly one receipt-backed association.  It never falls back from a
    task title or an arbitrary workspace path.  A one-time claim requires either
    the exact governed repository CWD or an installer-prepared exact Codex task
    receipt, plus a real transcript path, the sealed model, an attached runtime,
    and one unambiguous active project.
    """

    root = Path(store_root).resolve()
    normalized = dict(host_payload)
    observed_host_session_id = str(normalized.get("session_id") or "").strip()
    cwd = str(normalized.get("cwd") or "")
    transcript_path = str(
        normalized.get("transcript_path")
        or normalized.get("agent_transcript_path")
        or ""
    ).strip()
    if not observed_host_session_id:
        return normalized, None
    candidates = _session_candidates(
        root,
        host_session_id=observed_host_session_id,
        cwd=cwd,
        transcript_path=transcript_path,
    )
    if len(candidates) != 1:
        return normalized, None
    candidate = candidates[0]
    binding_match = str(candidate.get("binding_match") or "")
    if binding_match == "EXACT_HOST_SESSION":
        return normalized, None
    if binding_match == "SEALED_CODEX_HOST_ALIAS":
        _validate_alias_claim_profile(candidate, normalized)
        alias = _read_host_alias(
            Path(candidate["project_root"]),
            session=candidate["session"],
            observed_host_session_id=observed_host_session_id,
            transcript_path=transcript_path,
        )
        _require(
            alias is not None,
            "TURN_CONTROL_HOST_ALIAS_RECEIPT_REQUIRED",
            "The sealed Codex host alias receipt could not be reverified.",
        )
        assert alias is not None
        governed_host_session_id = str(
            candidate["session"].get("metadata", {}).get(
                "current_host_session_id"
            )
            or ""
        ).strip()
        normalized["session_id"] = governed_host_session_id
        normalized["codex_observed_session_id_sha256"] = alias[
            "observed_host_session_id_sha256"
        ]
        return normalized, {
            "state": "SEALED_CODEX_HOST_ALIAS_REUSED",
            "alias_receipt_sha256": alias["alias_receipt_sha256"],
            "binding_epoch_sha256": alias["binding_epoch_sha256"],
            "observed_host_session_id_sha256": alias[
                "observed_host_session_id_sha256"
            ],
            "transcript_path_sha256": alias["transcript_path_sha256"],
            "raw_host_identity_stored": False,
            "raw_transcript_path_stored": False,
        }
    if binding_match not in {
        "CWD_ONLY_STALE_OR_MISSING_HOST",
        "PREPARED_CODEX_TASK_BINDING",
    } or not allow_alias_claim:
        return normalized, None
    transcript = Path(transcript_path)
    if not transcript_path or not transcript.is_absolute() or not transcript.is_file():
        return normalized, None
    supplied_model = _validate_alias_claim_profile(candidate, normalized)
    session = candidate["session"]
    metadata = dict(session.get("metadata") or {})
    governed_host_session_id = str(
        metadata.get("current_host_session_id") or ""
    ).strip()
    _require(
        bool(governed_host_session_id),
        "TURN_CONTROL_GOVERNED_HOST_IDENTITY_REQUIRED",
        "The active Evidence Lane session has no sealed destination host identity.",
    )
    activation = _runtime_activation(root)
    attached = any(
        isinstance(row, dict)
        and row.get("project_id") == session.get("project_id")
        and row.get("session_id") == session.get("session_id")
        for row in activation.get("active_sessions", [])
    )
    _require(
        activation.get("state") == "ACTIVE" and attached,
        "TURN_CONTROL_RUNTIME_ATTACHMENT_REQUIRED",
        "A Codex host alias cannot be claimed for a detached governed session.",
        runtime_state=activation.get("state"),
    )
    observed_sha256 = sha256_bytes(observed_host_session_id.encode("utf-8"))
    collision = _active_host_alias_collision(
        root,
        observed_host_session_id_sha256=observed_sha256,
        selected_project_id=str(session.get("project_id") or ""),
        selected_evidence_session_id=str(session.get("session_id") or ""),
    )
    _require(
        collision is None,
        "TURN_CONTROL_HOST_ALIAS_COLLISION",
        "The observed Codex host identity is already bound to another active governed session.",
        collision=collision,
    )
    transcript_sha256 = _host_transcript_sha256(transcript_path)
    _require(
        transcript_sha256 is not None,
        "TURN_CONTROL_HOST_ALIAS_TRANSCRIPT_REQUIRED",
        "A one-time Codex host alias claim requires an absolute transcript identity.",
    )
    claimed_at = _now()
    task_binding = dict(candidate.get("task_binding") or {})
    record = {
        "schema": "evidence-lane.codex-host-session-alias.v1",
        "project_id": session.get("project_id"),
        "evidence_session_id": session.get("session_id"),
        "governed_host_session_id_sha256": sha256_bytes(
            governed_host_session_id.encode("utf-8")
        ),
        "observed_host_session_id_sha256": observed_sha256,
        "transcript_path_sha256": transcript_sha256,
        "binding_epoch_sha256": _host_binding_epoch(session),
        "model": supplied_model,
        "event_name": str(event_name or "").strip(),
        "permission_mode": str(normalized.get("permission_mode") or "").strip()
        or None,
        "binding_basis": (
            "INSTALLER_PREPARED_EXACT_CODEX_TASK_RUNTIME_ATTACHMENT_"
            "TRANSCRIPT_AND_SEALED_MODEL"
            if binding_match == "PREPARED_CODEX_TASK_BINDING"
            else "ONE_ACTIVE_PROJECT_EXACT_REPOSITORY_RUNTIME_ATTACHMENT_"
            "TRANSCRIPT_AND_SEALED_MODEL"
        ),
        "task_binding_receipt_sha256": (
            task_binding.get("task_binding_receipt_sha256")
            if binding_match == "PREPARED_CODEX_TASK_BINDING"
            else None
        ),
        "raw_host_identity_stored": False,
        "raw_transcript_path_stored": False,
        "source_mutated": False,
        "pointer_moved": False,
        "candidate_created": False,
        "hil_inferred": False,
        "claimed_at": claimed_at,
    }
    record["alias_receipt_sha256"] = sha256_bytes(canonical_json_bytes(record))
    project_root = Path(candidate["project_root"])
    with _connection(project_root) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            """
            SELECT record_json FROM host_session_alias
            WHERE observed_host_session_id_sha256=?
              AND binding_epoch_sha256=?
            """,
            (observed_sha256, record["binding_epoch_sha256"]),
        ).fetchone()
        if existing is None:
            connection.execute(
                "INSERT INTO host_session_alias VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    record["alias_receipt_sha256"],
                    record["project_id"],
                    record["evidence_session_id"],
                    record["governed_host_session_id_sha256"],
                    record["observed_host_session_id_sha256"],
                    record["transcript_path_sha256"],
                    record["binding_epoch_sha256"],
                    json.dumps(record, sort_keys=True, separators=(",", ":")),
                    claimed_at,
                    ENGINE_VERSION,
                ),
            )
        else:
            existing_record = json.loads(existing["record_json"])
            _require(
                existing_record == record,
                "TURN_CONTROL_HOST_ALIAS_CONFLICT",
                "The observed Codex host identity already has a different sealed alias receipt.",
            )
        connection.commit()
    normalized["session_id"] = governed_host_session_id
    normalized["codex_observed_session_id_sha256"] = observed_sha256
    return normalized, {
        "state": "SEALED_CODEX_HOST_ALIAS_CLAIMED",
        "alias_receipt_sha256": record["alias_receipt_sha256"],
        "binding_epoch_sha256": record["binding_epoch_sha256"],
        "observed_host_session_id_sha256": observed_sha256,
        "transcript_path_sha256": transcript_sha256,
        "raw_host_identity_stored": False,
        "raw_transcript_path_stored": False,
    }


def _sha(value: Any, *, field: str) -> str:
    exact = str(value or "").upper()
    _require(
        bool(_SHA256_RE.fullmatch(exact)),
        "TURN_CONTROL_RECEIPT_SHA256_REQUIRED",
        "A required Entry, Prepare, mode, operator, or Plan receipt is missing.",
        field=field,
    )
    return exact


def _binding_snapshot(
    root: Path,
    bound: dict[str, Any],
) -> dict[str, Any]:
    project_root = Path(bound["project_root"])
    project = bound["project"]
    session = bound["session"]
    metadata = session.get("metadata") or {}
    pointer = _json(project_root / "active_pointer.json")
    project_id = str(session.get("project_id") or "")
    evidence_session_id = str(session.get("session_id") or "")
    accepted_pv = str(pointer.get("accepted_pv") or "")
    pointer_generation = int(pointer.get("generation") or 0)
    _require(
        bool(
            project_id
            and evidence_session_id
            and project_id == project.get("project_id") == pointer.get("project_id")
        ),
        "TURN_CONTROL_PROJECT_SESSION_POINTER_MISMATCH",
        "Project, session, and accepted-pointer identities do not agree.",
    )
    _require(
        bool(
            accepted_pv
            and session.get("accepted_pv") == accepted_pv
            and int(session.get("accepted_pointer_generation") or 0)
            == pointer_generation
            and metadata.get("entry_pv") == accepted_pv
        ),
        "TURN_CONTROL_ENTRY_POINTER_MISMATCH",
        "The current accepted pointer does not match the governed Entry boundary.",
        accepted_pv=accepted_pv,
        pointer_generation=pointer_generation,
    )
    manifest_path = project_root / "accepted" / accepted_pv / "manifest.json"
    _require(
        manifest_path.is_file(),
        "TURN_CONTROL_ACCEPTED_MANIFEST_REQUIRED",
        "The accepted Entry manifest is missing.",
        path=str(manifest_path),
    )
    entry_manifest_sha256 = _sha(
        metadata.get("entry_manifest_sha256"), field="entry_manifest_sha256"
    )
    _require(
        sha256_file(manifest_path) == entry_manifest_sha256
        and pointer.get("accepted_manifest_sha256") == entry_manifest_sha256,
        "TURN_CONTROL_ACCEPTED_MANIFEST_MISMATCH",
        "The accepted Entry manifest does not match its sealed SHA-256 identity.",
    )
    entry_package_sha256 = _sha(
        metadata.get("entry_package_sha256"), field="entry_package_sha256"
    )
    state_travel = metadata.get("state_travel") or {}
    prepare_sha256 = _sha(
        state_travel.get("verified_snapshot_sha256"),
        field="state_travel.verified_snapshot_sha256",
    )
    resume_contract = state_travel.get("resume_contract") or {}
    task_list = resume_contract.get("task_list") or []
    resume_active_rows = [
        dict(row)
        for row in task_list
        if isinstance(row, dict)
        and str(row.get("status") or "").upper() in _ACTIVE_PLAN_STATUSES
    ]
    _require(
        len(resume_active_rows) == 1,
        "TURN_CONTROL_PLAN_ROW_REQUIRED",
        "The State Travel contract must preserve exactly one original resume row.",
        active_plan_rows=len(resume_active_rows),
    )
    sealed_resume_row = resume_active_rows[0]
    state_travel_task_list_sha256 = _sha(
        resume_contract.get("task_list_sha256"),
        field="state_travel.resume_contract.task_list_sha256",
    )
    backlog_status = ProjectStore(root).backlog_status(project_id)
    goal_projection = backlog_status.get("goal_projection") or {}
    goal_rows = goal_projection.get("rows") or []
    resume_row_matches = [
        dict(row)
        for row in goal_rows
        if isinstance(row, dict)
        and row.get("task_id") == sealed_resume_row.get("task_id")
    ]
    _require(
        len(resume_row_matches) == 1,
        "TURN_CONTROL_STATE_TRAVEL_RESUME_ROW_MISMATCH",
        "The original State Travel resume row must remain exactly once in Plan history.",
        sealed_task_id=sealed_resume_row.get("task_id"),
        current_match_count=len(resume_row_matches),
    )
    current_active_rows = [
        dict(row)
        for row in goal_rows
        if isinstance(row, dict)
        and str(row.get("status") or "").lower() == "in_progress"
        and str(row.get("lifecycle_status") or "").upper() == "ACTIVE"
    ]
    _require(
        len(current_active_rows) == 1,
        "TURN_CONTROL_CANONICAL_ACTIVE_PLAN_ROW_REQUIRED",
        "Exactly one current canonical Plan row must be active for this Codex turn.",
        current_active_plan_rows=len(current_active_rows),
    )
    plan_row = current_active_rows[0]
    _require(
        metadata.get("active_backlog_task_id") == plan_row.get("task_id")
        and metadata.get("active_backlog_task_status") == "ACTIVE",
        "TURN_CONTROL_SESSION_ACTIVE_PLAN_BINDING_MISMATCH",
        "The governed session and current canonical Plan row do not agree.",
        session_active_task_id=metadata.get("active_backlog_task_id"),
        canonical_active_task_id=plan_row.get("task_id"),
    )
    plan_projection_sha256 = _sha(
        goal_projection.get("projection_sha256"),
        field="goal_projection.projection_sha256",
    )
    plan_task_matches = [
        dict(row)
        for row in backlog_status.get("tasks") or []
        if isinstance(row, dict) and row.get("task_id") == plan_row.get("task_id")
    ]
    _require(
        len(plan_task_matches) == 1,
        "TURN_CONTROL_PLAN_TASK_CONTRACT_REQUIRED",
        "The active Plan row must resolve exactly one bounded task contract.",
        task_id=plan_row.get("task_id"),
        task_contract_count=len(plan_task_matches),
    )
    plan_task_contract = plan_task_matches[0]
    runtime_task = session.get("task") or {}
    if isinstance(runtime_task, dict) and runtime_task.get("task_id"):
        task = dict(runtime_task)
        task_binding_source = "SESSION_RUNTIME_TASK_PLUS_CANONICAL_ACTIVE_PLAN_ROW"
    else:
        task = dict(plan_task_contract)
        task_binding_source = "CANONICAL_ACTIVE_PLAN_ROW_AFTER_STATE_TRAVEL"
    _require(
        bool(task.get("task_id"))
        and plan_row.get("task_id") == plan_task_contract.get("task_id"),
        "TURN_CONTROL_TASK_BINDING_REQUIRED",
        "The governed session has no uniquely resolved active task contract.",
    )
    active_mode = metadata.get("active_mode_binding") or {}
    _require(
        isinstance(active_mode, dict)
        and active_mode.get("schema") == "evidence-lane.active-mode-binding.v1",
        "TURN_CONTROL_MODE_BINDING_REQUIRED",
        "An exact active ENV/UOP Mode binding is required.",
    )
    mode_governance = active_mode.get("mode_governance") or {}
    contracts = mode_governance.get("contracts") or []
    _require(
        isinstance(contracts, list) and bool(contracts),
        "TURN_CONTROL_ENV_UOP_CONTRACT_REQUIRED",
        "The active Mode binding has no ENV/UOP governance contract.",
    )
    env_authorities = []
    for index, contract in enumerate(contracts):
        authority = (contract or {}).get("env_authority") or {}
        env_authorities.append(
            {
                "mode_id": contract.get("mode_id"),
                "canonical_lanes": sorted(contract.get("canonical_lanes") or []),
                "env_sqlite_sha256": _sha(
                    authority.get("env_sqlite_sha256"),
                    field=f"mode.contracts[{index}].env_sqlite_sha256",
                ),
                "uop_sqlite_sha256": _sha(
                    authority.get("uop_sqlite_sha256"),
                    field=f"mode.contracts[{index}].uop_sqlite_sha256",
                ),
                "mode_policy_projection_sha256": _sha(
                    authority.get("mode_policy_projection_sha256"),
                    field=f"mode.contracts[{index}].mode_policy_projection_sha256",
                ),
                "operator_families": sorted(contract.get("operator_families") or []),
                "operator_receipt_sha256": _sha(
                    contract.get("operator_receipt_sha256"),
                    field=f"mode.contracts[{index}].operator_receipt_sha256",
                ),
            }
        )
    steer_delta_receipts = [
        {
            "delta_id": str(row.get("delta_id") or ""),
            "classification": str(row.get("classification") or ""),
            "boundary": str(row.get("boundary") or ""),
            "text_sha256": sha256_bytes(str(row.get("text") or "").encode("utf-8")),
        }
        for row in plan_row.get("steer_deltas") or []
        if isinstance(row, dict) and str(row.get("delta_id") or "").strip()
    ]
    research_basis_text = "\n".join(
        [str(plan_row.get("step") or "")]
        + [
            str(row.get("text") or "")
            for row in plan_row.get("steer_deltas") or []
            if isinstance(row, dict)
        ]
    )
    research_basis_lower = research_basis_text.casefold()
    research_focus = (
        "MEMORY_PLUS_LEARNING"
        if "memory" in research_basis_lower and "learning" in research_basis_lower
        else "PROJECT_TASK_RESEARCH"
    )
    research_policy = {
        "enabled": (
            "research" in set(active_mode.get("canonical_lanes") or [])
            or "RS" in set(active_mode.get("selected_mode_ids") or [])
        ),
        "focus": research_focus,
        "focus_basis_sha256": sha256_bytes(research_basis_text.encode("utf-8")),
        "access_scope": _PROJECT_TASK_PRIVATE_ANALYSIS,
        "cross_project_retrieval": False,
        "shared_telemetry": False,
        "public_output": False,
        "private_reasoning_stored": False,
    }
    binding = {
        "schema": "evidence-lane.codex-turn-binding.v1",
        "project_id": project_id,
        "evidence_session_id": evidence_session_id,
        "task_id": task["task_id"],
        "plan_task_id": plan_row.get("task_id"),
        "task_binding_source": task_binding_source,
        "runtime_task_present": bool(runtime_task),
        "lifecycle_state": session.get("state"),
        "accepted_pv": accepted_pv,
        "pointer_generation": pointer_generation,
        "candidate_boundary": (
            {
                "state": "PENDING_CANDIDATE",
                "candidate_id": session.get("candidate_id"),
            }
            if session.get("candidate_id")
            else {"state": "NO_PENDING_CANDIDATE", "candidate_id": None}
        ),
        "entry_manifest_sha256": entry_manifest_sha256,
        "entry_package_sha256": entry_package_sha256,
        "prepare_verified_snapshot_sha256": prepare_sha256,
        "persistent_plan_row": {
            "position": int(plan_row.get("number") or 0),
            "task_id": plan_row.get("task_id"),
            "status": plan_row.get("status"),
            "lifecycle_status": plan_row.get("lifecycle_status"),
            "step_sha256": sha256_bytes(
                str(plan_row.get("step") or "").encode("utf-8")
            ),
            "state_travel_task_list_sha256": state_travel_task_list_sha256,
            "goal_projection_sha256": plan_projection_sha256,
            "canonical_plan_sha256": goal_projection.get("canonical_plan_sha256"),
            "event_head_sha256": backlog_status.get("event_head_sha256"),
            "goal_projection_task_count": int(goal_projection.get("task_count") or 0),
            "persistent_until": goal_projection.get("persistent_until"),
            "state_travel_resume_row": {
                "position": int(sealed_resume_row.get("position") or 0),
                "task_id": sealed_resume_row.get("task_id"),
                "sealed_status": sealed_resume_row.get("status"),
                "current_status": resume_row_matches[0].get("status"),
                "current_lifecycle_status": resume_row_matches[0].get(
                    "lifecycle_status"
                ),
            },
            "linked_steer_delta_receipts": steer_delta_receipts,
            "bounded_write_scope": list(
                plan_task_contract.get("permitted_paths") or []
            ),
            "permitted_tools": list(plan_task_contract.get("permitted_tools") or []),
            "acceptance_checks_sha256": sha256_bytes(
                canonical_json_bytes(plan_task_contract.get("acceptance_checks") or [])
            ),
            "stop_condition_sha256": sha256_bytes(
                str(plan_task_contract.get("stop_condition") or "").encode("utf-8")
            ),
        },
        "mode_binding_receipt_sha256": _sha(
            active_mode.get("binding_receipt_sha256"),
            field="active_mode_binding.binding_receipt_sha256",
        ),
        "combined_operator_receipt_sha256": _sha(
            mode_governance.get("combined_operator_receipt_sha256"),
            field="active_mode_binding.combined_operator_receipt_sha256",
        ),
        "canonical_lanes": sorted(active_mode.get("canonical_lanes") or []),
        "selected_mode_ids": sorted(active_mode.get("selected_mode_ids") or []),
        "env_uop_authorities": env_authorities,
        "research_policy": research_policy,
        "package_update_status": _package_update_status(root),
        "entry_slip": {
            "accepted_pv": accepted_pv,
            "pointer_generation": pointer_generation,
            "entry_manifest_sha256": entry_manifest_sha256,
            "entry_package_sha256": entry_package_sha256,
            "state_travel_prepare_sha256": prepare_sha256,
            "mode_binding_receipt_sha256": _sha(
                active_mode.get("binding_receipt_sha256"),
                field="active_mode_binding.binding_receipt_sha256",
            ),
            "goal_projection_sha256": plan_projection_sha256,
        },
        "gates": {
            "source_mutation_requires_prepare": True,
            "candidate_acceptance_inferred": False,
            "fuse_inferred": False,
            "pointer_movement_inferred": False,
            "hil_inferred": False,
        },
        "repository_path_sha256": sha256_bytes(
            str(project.get("repository_path") or "").encode("utf-8")
        ),
        "scrollback_authority": False,
        "transcript_authority": False,
    }
    binding["binding_sha256"] = sha256_bytes(canonical_json_bytes(binding))
    return binding


def seal_exact_task_project_session_binding(
    root: str | Path,
    *,
    project_id: str,
    evidence_session_id: str,
    expected_active_task_id: str,
) -> dict[str, Any]:
    """Seal one exact Codex task/project/session/Plan/runtime binding.

    Discovery is deliberately limited to installer-prepared exact Codex task
    receipts whose project, governed session, and governed host-session identity
    already match the active local authority.  Task titles and repository CWDs are
    not accepted as identity signals.  Multiple matching receipts fail closed.
    """

    exact_root = Path(root).resolve()
    project_root = exact_root / "projects" / project_id
    active_session_path = project_root / "active_session.json"
    project_path = project_root / "project.json"
    _require(
        active_session_path.is_file() and project_path.is_file(),
        "CODEX_EXACT_BINDING_PROJECT_AUTHORITY_REQUIRED",
        "The active project/session authority is unavailable.",
    )
    active_session = _json(active_session_path)
    _require(
        active_session.get("project_id") == project_id
        and active_session.get("session_id") == evidence_session_id,
        "CODEX_EXACT_BINDING_ACTIVE_SESSION_MISMATCH",
        "The requested governed session is not the active project session.",
    )
    session_path = project_root / "sessions" / f"{evidence_session_id}.json"
    _require(
        session_path.is_file(),
        "CODEX_EXACT_BINDING_SESSION_REQUIRED",
        "The exact governed session record is missing.",
    )
    session = _json(session_path)
    project = _json(project_path)
    metadata = dict(session.get("metadata") or {})
    governed_host_session_id = str(
        metadata.get("current_host_session_id") or ""
    ).strip()
    _require(
        session.get("project_id") == project_id
        and session.get("session_id") == evidence_session_id
        and not metadata.get("closed_at")
        and bool(governed_host_session_id),
        "CODEX_EXACT_BINDING_SESSION_IDENTITY_MISMATCH",
        "The active governed project, session, and host-session identities do not agree.",
    )

    turn_binding = _binding_snapshot(
        exact_root,
        {
            "project_root": project_root,
            "project": project,
            "session": session,
            "binding_match": "EXACT_INSTALLER_PREPARED_CODEX_TASK",
        },
    )
    active_plan = dict(turn_binding.get("persistent_plan_row") or {})
    _require(
        active_plan.get("task_id") == expected_active_task_id
        and active_plan.get("status") == "in_progress"
        and active_plan.get("lifecycle_status") == "ACTIVE"
        and active_plan.get("persistent_until")
        == "NEXT_SIX_WAY_HIL_PRESENTED",
        "CODEX_EXACT_BINDING_ACTIVE_PLAN_MISMATCH",
        "The requested task is not the sole current executable Plan row.",
        expected_active_task_id=expected_active_task_id,
        actual_active_task_id=active_plan.get("task_id"),
    )

    installation_root = exact_root / "installations" / "codex-v200"
    binding_root = installation_root / "task-bindings"
    _require(
        binding_root.is_dir(),
        "CODEX_EXACT_BINDING_INSTALLER_RECEIPTS_REQUIRED",
        "The installer-prepared Codex task-binding authority is missing.",
    )
    candidates: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(binding_root.glob("*.json"), key=lambda item: item.name):
        try:
            raw = _json(path)
        except TurnControlError:
            continue
        if (
            raw.get("schema") == "evidence-lane.codex-task-binding.v1"
            and raw.get("project_id") == project_id
            and raw.get("evidence_session_id") == evidence_session_id
            and raw.get("governed_host_session_id") == governed_host_session_id
        ):
            candidates.append((path, raw))
    _require(
        len(candidates) == 1,
        "CODEX_EXACT_BINDING_AMBIGUOUS_OR_MISSING",
        "Exactly one installer-prepared Codex task receipt must bind this project, session, and host session.",
        matching_task_bindings=len(candidates),
    )
    task_binding_path, raw_task_binding = candidates[0]
    codex_task_id = str(raw_task_binding.get("task_id") or "").strip()
    _require(
        _CODEX_TASK_ID_RE.fullmatch(codex_task_id) is not None
        and task_binding_path.stem.lower() == codex_task_id.lower(),
        "CODEX_EXACT_BINDING_THREAD_ID_MISMATCH",
        "The installer receipt filename and exact Codex thread UUID do not agree.",
    )
    task_binding = _read_codex_task_binding(
        exact_root,
        observed_host_session_id=codex_task_id,
    )
    _require(
        isinstance(task_binding, dict)
        and task_binding.get("project_id") == project_id
        and task_binding.get("evidence_session_id") == evidence_session_id
        and task_binding.get("governed_host_session_id")
        == governed_host_session_id,
        "CODEX_EXACT_BINDING_TASK_RECEIPT_MISMATCH",
        "The exact Codex thread receipt does not bind the active governed identities.",
    )
    assert task_binding is not None

    install_path = Path(str(task_binding["install_receipt"]))
    installation = _json(install_path)
    plugin = dict(installation.get("plugin") or {})
    activation = dict(installation.get("activation") or {})
    plugin_add = dict(activation.get("plugin_add") or {})
    installed_path = Path(str(plugin_add.get("installedPath") or ""))
    running_plugin_root = Path(__file__).resolve().parents[2]
    _require(
        activation.get("state") == "INSTALLED_RESTART_REQUIRED"
        and plugin.get("version") == task_binding.get("plugin_version")
        and plugin_add.get("version") == plugin.get("version")
        and str(plugin_add.get("pluginId") or "").startswith(
            "evidence-lane-plugin@"
        )
        and installed_path.is_absolute()
        and installed_path.is_dir()
        and installed_path.resolve() == running_plugin_root.resolve(),
        "CODEX_EXACT_BINDING_RUNNING_BUILD_MISMATCH",
        "The running plugin is not the exact installer-bound stable build.",
    )
    surface = _package_surface_inventory()
    _require(
        surface.get("plugin_version") == plugin.get("version")
        and surface.get("catalog")
        == {"tools": 62, "read": 21, "write": 41, "skills": 15},
        "CODEX_EXACT_BINDING_RUNNING_SURFACE_MISMATCH",
        "The running plugin surface does not match the exact v2 catalog.",
    )
    task_uri = f"codex://threads/{codex_task_id}"
    _require(
        task_binding.get("task_uri_sha256")
        == sha256_bytes(task_uri.encode("utf-8")),
        "CODEX_EXACT_BINDING_DEEPLINK_MISMATCH",
        "The exact Codex task UUID and deep-link identity do not agree.",
    )

    receipt_body = {
        "schema": "evidence-lane.codex-exact-task-project-session-binding.v1",
        "status": "PASS",
        "project_id": project_id,
        "evidence_session_id": evidence_session_id,
        "codex_thread_id": codex_task_id,
        "task_uri": task_uri,
        "task_uri_sha256": task_binding.get("task_uri_sha256"),
        "governed_host_session_id": governed_host_session_id,
        "active_plan_row": active_plan,
        "accepted_pointer": {
            "accepted_pv": turn_binding.get("accepted_pv"),
            "generation": turn_binding.get("pointer_generation"),
            "manifest_sha256": turn_binding.get("entry_manifest_sha256"),
            "package_sha256": turn_binding.get("entry_package_sha256"),
        },
        "running_plugin": {
            "plugin_id": plugin.get("plugin_id"),
            "plugin_version": plugin.get("version"),
            "plugin_selector": plugin_add.get("pluginId"),
            "archive_sha256": installation.get("archive_sha256"),
            "install_receipt_sha256": task_binding.get(
                "install_receipt_sha256"
            ),
            "surface_inventory_sha256": surface.get(
                "surface_inventory_sha256"
            ),
            "catalog": surface.get("catalog"),
        },
        "runtime_task_id": dict(session.get("task") or {}).get("task_id"),
        "task_binding_receipt_sha256": task_binding.get(
            "task_binding_receipt_sha256"
        ),
        "preparation_receipt_sha256": task_binding.get(
            "preparation_receipt_sha256"
        ),
        "binding_epoch_sha256": _host_binding_epoch(session),
        "turn_binding_sha256": turn_binding.get("binding_sha256"),
        "identity_basis": "EXACT_CODEX_THREAD_RECEIPT_PLUS_NATIVE_PLAN_AND_POINTER",
        "task_title_used": False,
        "cwd_used": False,
        "candidate_created": False,
        "pending_hil": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "sealed_at": task_binding.get("prepared_at_utc"),
    }
    receipt = {
        **receipt_body,
        "receipt_sha256": sha256_bytes(canonical_json_bytes(receipt_body)),
    }
    binding_epoch_sha256 = str(receipt_body["binding_epoch_sha256"])
    receipt_path = (
        project_root
        / "receipts"
        / "codex-task-bindings"
        / f"{codex_task_id.lower()}__{binding_epoch_sha256[:24].lower()}.json"
    )
    if receipt_path.is_file():
        _require(
            _json(receipt_path) == receipt,
            "CODEX_EXACT_BINDING_RECEIPT_CONFLICT",
            "The exact binding epoch already contains different sealed bytes.",
        )
    else:
        atomic_write_json(receipt_path, receipt)
    return receipt


def seal_active_task_acceptance_checkpoint(
    root: str | Path,
    *,
    project_id: str,
    evidence_session_id: str,
    expected_active_task_id: str,
) -> dict[str, Any]:
    """Seal one acceptance-backed, candidate-free active-task checkpoint.

    The exact Codex task binding remains the identity authority.  Advancement
    additionally requires one current-run ChatLineage activity whose visible
    payload covers the active Plan row's complete acceptance contract.  A
    generic task transition therefore cannot be manufactured from title, CWD,
    an old run, or an unrelated PASS event.
    """

    exact_root = Path(root).resolve()
    project_root = exact_root / "projects" / project_id
    session_path = project_root / "sessions" / f"{evidence_session_id}.json"
    backlog_path = project_root / "task_backlog.json"
    _require(
        session_path.is_file() and backlog_path.is_file(),
        "CODEX_TASK_CHECKPOINT_AUTHORITY_REQUIRED",
        "The active session and Plan authority are required for checkpoint sealing.",
    )
    session = _json(session_path)
    backlog = _json(backlog_path)
    metadata = dict(session.get("metadata") or {})
    runtime_task = dict(session.get("task") or {})
    runtime_task_id = str(runtime_task.get("task_id") or "").strip()
    run_id = str(metadata.get("run_id") or "").strip()
    active_rows = [
        dict(row)
        for row in backlog.get("tasks") or []
        if isinstance(row, dict) and row.get("status") == "ACTIVE"
    ]
    _require(
        len(active_rows) == 1
        and active_rows[0].get("task_id") == expected_active_task_id
        and metadata.get("active_backlog_task_id") == expected_active_task_id
        and metadata.get("active_backlog_task_status") == "ACTIVE"
        and bool(runtime_task_id)
        and bool(run_id),
        "CODEX_TASK_CHECKPOINT_ACTIVE_ROW_MISMATCH",
        "Exactly one active Plan row and current runtime task must match the checkpoint.",
        expected_active_task_id=expected_active_task_id,
    )
    active_task = active_rows[0]
    acceptance_checks = [
        str(value).strip()
        for value in active_task.get("acceptance_checks") or []
        if str(value).strip()
    ]
    _require(
        bool(acceptance_checks),
        "CODEX_TASK_CHECKPOINT_ACCEPTANCE_REQUIRED",
        "The active Plan row has no exact acceptance contract to verify.",
    )

    lineage_path = project_root / "lineage" / f"{evidence_session_id}.jsonl"
    events = ChatLineage(lineage_path).events()
    matching: list[dict[str, Any]] = []
    for event in events:
        if (
            event.get("session_id") != evidence_session_id
            or event.get("task_id") != runtime_task_id
            or event.get("run_id") != run_id
            or event.get("event_type")
            not in {"task.test.output", "task.build.output"}
        ):
            continue
        payload = dict(event.get("visible_payload") or {})
        covered = payload.get("acceptance_checks")
        if not isinstance(covered, list):
            singular = str(payload.get("acceptance_check") or "").strip()
            covered = [singular] if singular else []
        exact_covered = [str(value).strip() for value in covered if str(value).strip()]
        if (
            payload.get("active_task_id", payload.get("task_id"))
            == expected_active_task_id
            and payload.get("result") == "PASS"
            and exact_covered == acceptance_checks
            and payload.get("candidate_created") is False
            and payload.get("pending_hil") is False
            and payload.get("pointer_moved") is False
            and payload.get("hil_inferred") is False
        ):
            matching.append(event)
    _require(
        bool(matching),
        "CODEX_TASK_CHECKPOINT_ACCEPTANCE_EVIDENCE_REQUIRED",
        "No current-run activity proves the active row's complete acceptance contract.",
        expected_active_task_id=expected_active_task_id,
        acceptance_checks=acceptance_checks,
    )
    evidence = matching[-1]
    binding = seal_exact_task_project_session_binding(
        exact_root,
        project_id=project_id,
        evidence_session_id=evidence_session_id,
        expected_active_task_id=expected_active_task_id,
    )
    receipt_body = {
        "schema": "evidence-lane.active-task-acceptance-checkpoint.v1",
        "status": "PASS",
        "verification_kind": "ACTIVE_TASK_ACCEPTANCE",
        "project_id": project_id,
        "evidence_session_id": evidence_session_id,
        "governed_host_session_id": binding["governed_host_session_id"],
        "active_plan_row": binding["active_plan_row"],
        "accepted_pointer": binding["accepted_pointer"],
        "running_plugin": binding["running_plugin"],
        "runtime_task_id": runtime_task_id,
        "run_id": run_id,
        "acceptance_contract": {
            "checks": acceptance_checks,
            "checks_sha256": sha256_bytes(canonical_json_bytes(acceptance_checks)),
        },
        "acceptance_evidence": {
            key: evidence.get(key)
            for key in (
                "event_id",
                "event_type",
                "occurred_at",
                "lineage_index",
                "visible_payload_sha256",
                "event_sha256",
            )
        },
        "exact_binding_receipt_sha256": binding["receipt_sha256"],
        "identity_basis": (
            "EXACT_CODEX_TASK_BINDING_PLUS_CURRENT_RUN_ACCEPTANCE_ACTIVITY"
        ),
        "task_title_used": False,
        "cwd_used": False,
        "candidate_created": False,
        "pending_hil": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "sealed_at": evidence["occurred_at"],
    }
    receipt = {
        **receipt_body,
        "receipt_sha256": sha256_bytes(canonical_json_bytes(receipt_body)),
    }
    receipt_path = (
        project_root
        / "receipts"
        / "task-checkpoints"
        / f"{str(evidence['event_sha256'])[:32].lower()}.json"
    )
    if receipt_path.is_file():
        _require(
            _json(receipt_path) == receipt,
            "CODEX_TASK_CHECKPOINT_RECEIPT_CONFLICT",
            "The acceptance event already seals different checkpoint bytes.",
        )
    else:
        atomic_write_json(receipt_path, receipt)
    return receipt


def _warm_attach_receipt(
    root: Path,
    *,
    bound: dict[str, Any],
    binding: dict[str, Any],
    host_session_id: str,
    started_ns: int,
) -> dict[str, Any]:
    """Prove a warm native Codex attachment without waiting on the tunnel."""

    activation_path = root / "installation" / "runtime_activation.json"
    activation = _runtime_activation(root)
    _require(
        activation_path.is_file() and activation.get("state") == "ACTIVE",
        "TURN_CONTROL_WARM_ATTACH_RUNTIME_REQUIRED",
        "Warm Codex attachment requires an existing durable active-runtime receipt.",
    )
    matching_rows = [
        dict(row)
        for row in activation.get("active_sessions") or []
        if isinstance(row, dict)
        and row.get("project_id") == binding["project_id"]
        and row.get("session_id") == binding["evidence_session_id"]
    ]
    _require(
        len(matching_rows) == 1,
        "TURN_CONTROL_WARM_ATTACH_SESSION_REQUIRED",
        "Warm Codex attachment requires exactly one active project-session row.",
        matching_rows=len(matching_rows),
    )
    activation_row = matching_rows[0]
    _require(
        activation.get("flash_context_attached") is True
        and activation.get("prompt_capture_active") is True
        and activation.get("visible_response_capture_active") is True,
        "TURN_CONTROL_WARM_ATTACH_CAPTURE_REQUIRED",
        "Warm Codex attachment requires Flash plus visible turn capture to already be active.",
    )
    host_session_ids = [
        str(value) for value in activation_row.get("host_session_ids") or []
    ]
    _require(
        host_session_id in host_session_ids,
        "TURN_CONTROL_WARM_ATTACH_HOST_REQUIRED",
        "The active plugin runtime does not bind the exact Codex host session.",
        host_session_id_sha256=sha256_bytes(host_session_id.encode("utf-8")),
    )
    flash_receipt_sha256 = _sha(
        activation_row.get("flash_receipt_sha256"),
        field="runtime_activation.active_sessions.flash_receipt_sha256",
    )
    execution_profile = dict(
        (bound.get("session", {}).get("metadata") or {}).get("execution_profile")
        or {}
    )
    required_profile_fields = (
        "model",
        "submodel",
        "reasoning_effort",
        "reasoning_speed",
    )
    missing_profile_fields = [
        field
        for field in required_profile_fields
        if not str(execution_profile.get(field) or "").strip()
    ]
    _require(
        not missing_profile_fields,
        "TURN_CONTROL_WARM_ATTACH_PROFILE_REQUIRED",
        "The exact unfinished Codex execution profile is incomplete.",
        missing=missing_profile_fields,
    )
    duration_ns = max(0, time.perf_counter_ns() - started_ns)
    persistence_route = dict(
        (bound.get("session", {}).get("metadata") or {}).get("persistence_route")
        or {}
    )
    tunnel_requirement = str(
        persistence_route.get("tunnel_requirement")
        or "HOST_CAPABILITY_UNSPECIFIED"
    )
    interactive_tunnel = (
        tunnel_requirement == "REQUIRED_FOR_INTERACTIVE_CODEX_APP_ENVIRONMENT"
    )
    core = {
        "schema": "evidence-lane.codex-warm-attach-receipt.v1",
        "state": "WARM_ATTACHED_ZERO_TUNNEL_PROVISIONING_WAIT",
        "route": "PACKAGE_LOCAL_NATIVE_MCP_ONLY",
        "native_mcp_namespace": "mcp__evidence_lane__",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "host_session_id_sha256": sha256_bytes(host_session_id.encode("utf-8")),
        "binding_sha256": binding["binding_sha256"],
        "execution_profile": execution_profile,
        "execution_profile_sha256": sha256_bytes(
            canonical_json_bytes(execution_profile)
        ),
        "runtime_already_active": True,
        "exact_host_session_already_attached": True,
        "runtime_activation_generation": int(activation.get("generation") or 0),
        "runtime_activation_receipt_sha256": sha256_file(activation_path),
        "flash_context_already_attached": activation.get("flash_context_attached")
        is True,
        "prompt_capture_already_active": activation.get("prompt_capture_active")
        is True,
        "visible_response_capture_already_active": activation.get(
            "visible_response_capture_active"
        )
        is True,
        "flash_receipt_sha256": flash_receipt_sha256,
        "accepted_pv": binding["accepted_pv"],
        "pointer_generation": binding["pointer_generation"],
        "boot_flash_pointer_plan_verified": True,
        "interaction_profile": persistence_route.get(
            "interaction_profile", "HOST_SURFACE_UNSPECIFIED"
        ),
        "vm_lifetime": persistence_route.get(
            "vm_lifetime", "LOCAL_OR_PERSISTENT"
        ),
        "tunnel_role": (
            "INTERACTIVE_ENVIRONMENT_PRECONDITION_NOT_LIFECYCLE_AUTHORITY"
            if interactive_tunnel
            else "NOT_IN_CODEX_NATIVE_LIFECYCLE_CRITICAL_PATH"
        ),
        "tunnel_requirement": tunnel_requirement,
        "tunnel_setup_frequency": persistence_route.get(
            "tunnel_setup_frequency", "HOST_CAPABILITY_UNSPECIFIED"
        ),
        "tunnel_key_retention": persistence_route.get(
            "tunnel_key_retention", "HOST_CAPABILITY_UNSPECIFIED"
        ),
        "tunnel_action": "NONE_IN_WARM_ATTACH_USE_HOST_ACTIVATION_ENVELOPE",
        "tunnel_onboarding_may_be_required": interactive_tunnel,
        "tunnel_state_queried": False,
        "tunnel_provisioning_wait_ns": 0,
        "tunnel_health_check_wait_ns": 0,
        "codex_tunnel_lifecycle_proof_allowed": False,
        "external_windows_tunnel_health_claimed": False,
        "attach_verification_duration_ns": duration_ns,
        "attach_verification_duration_ms": round(duration_ns / 1_000_000, 3),
        "zero_wall_clock_duration_claimed": False,
        "lifecycle_mutated": False,
        "source_mutated": False,
        "candidate_created_or_accepted": False,
        "pointer_moved": False,
        "hil_inferred": False,
    }
    core["receipt_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def _source_change_snapshot(
    root: Path,
    *,
    binding: dict[str, Any],
    cwd: str,
) -> dict[str, Any]:
    """Read one deterministic Git change surface without mutating the repository."""

    config = ProjectStore(root).config(str(binding["project_id"]))
    repository = Path(config.repository_path).resolve()
    try:
        identity = inspect_repository(
            repository,
            expected_owner=config.expected_owner,
            expected_name=config.expected_name,
        )
        worktree_sha256 = calculate_worktree_sha256(repository)
        status = run_git(
            repository,
            ["status", "--porcelain=v1", "--untracked-files=all"],
        ).stdout
        numstat = run_git(
            repository,
            ["diff", "--numstat", "HEAD", "--"],
        ).stdout
    except EvidenceLaneError as exc:
        raise TurnControlError(
            "TURN_CONTROL_SOURCE_CHANGE_STATUS_UNAVAILABLE",
            "The exact governed repository change status could not be verified.",
            repository_path_sha256=binding["repository_path_sha256"],
            source_error_code=exc.code,
            source_error_status=exc.status,
        ) from exc

    changed_paths: list[dict[str, Any]] = []
    for line in status.splitlines():
        if not line.strip():
            continue
        status_code = line[:2] if len(line) >= 2 else "??"
        raw_path = line[3:].strip() if len(line) > 3 else ""
        raw_path_sha256 = sha256_bytes(raw_path.encode("utf-8"))
        visible_path = _turn_redact_text(raw_path)
        if not visible_path or contains_secret(visible_path):
            visible_path = f"[REDACTED_PATH:{raw_path_sha256[:16]}]"
        changed_paths.append(
            {
                "status": status_code,
                "path_after_redaction": visible_path,
                "path_sha256": raw_path_sha256,
            }
        )

    line_additions = 0
    line_deletions = 0
    binary_change_count = 0
    tracked_diff_path_count = 0
    for line in numstat.splitlines():
        columns = line.split("\t", 2)
        if len(columns) != 3:
            continue
        tracked_diff_path_count += 1
        added, deleted, _ = columns
        if added == "-" or deleted == "-":
            binary_change_count += 1
            continue
        line_additions += int(added)
        line_deletions += int(deleted)

    try:
        exact_cwd = Path(cwd).resolve() if cwd.strip() else None
    except OSError:
        exact_cwd = None
    if exact_cwd == repository:
        workspace_binding = "EXACT_REPOSITORY_ROOT"
    elif exact_cwd is not None and _within(exact_cwd, repository):
        workspace_binding = "INSIDE_REPOSITORY"
    else:
        workspace_binding = "PROJECTLESS_OR_EXTERNAL_TASK_WORKSPACE"

    core = {
        "schema": "evidence-lane.codex-source-change-snapshot.v1",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "repository_path_sha256": binding["repository_path_sha256"],
        "branch": identity.branch,
        "commit_sha": identity.commit_sha,
        "tree_sha": identity.tree_sha,
        "worktree_sha256": worktree_sha256,
        "worktree_status_sha256": sha256_bytes(status.encode("utf-8")),
        "is_clean": identity.is_clean,
        "changed_path_count": len(changed_paths),
        "untracked_path_count": sum(row["status"] == "??" for row in changed_paths),
        "tracked_diff_path_count": tracked_diff_path_count,
        "line_additions": line_additions,
        "line_deletions": line_deletions,
        "binary_change_count": binary_change_count,
        "line_delta_scope": "TRACKED_HEAD_DIFF_ONLY_UNTRACKED_EXCLUDED",
        "changed_paths_after_redaction": changed_paths[:_MAX_PERSISTENT_CHANGE_PATHS],
        "changed_paths_truncated": (len(changed_paths) > _MAX_PERSISTENT_CHANGE_PATHS),
        "task_workspace_binding": workspace_binding,
        "host_native_change_indicator_expected": workspace_binding
        in {"EXACT_REPOSITORY_ROOT", "INSIDE_REPOSITORY"},
        "source_mutated": False,
        "private_reasoning_stored": False,
    }
    core["source_change_snapshot_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def _persistent_change_display(
    *,
    binding: dict[str, Any],
    source_snapshot: dict[str, Any],
    turn_state: str,
    prompt_index: int | None,
    uncommitted_count: int,
    changed_since_prepare: bool | None,
    warm_attach_receipt: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Pair the durable Plan row and read-only source change status for the host."""

    plan_row = dict(binding["persistent_plan_row"])
    changes = [
        {
            "delta_id": row["delta_id"],
            "classification": row["classification"],
            "boundary": row["boundary"],
            "text_sha256": row["text_sha256"],
        }
        for row in plan_row.get("linked_steer_delta_receipts") or []
    ]
    source_status = {
        key: source_snapshot[key]
        for key in (
            "source_change_snapshot_sha256",
            "branch",
            "commit_sha",
            "tree_sha",
            "worktree_sha256",
            "worktree_status_sha256",
            "is_clean",
            "changed_path_count",
            "untracked_path_count",
            "tracked_diff_path_count",
            "line_additions",
            "line_deletions",
            "binary_change_count",
            "line_delta_scope",
            "changed_paths_after_redaction",
            "changed_paths_truncated",
            "task_workspace_binding",
            "host_native_change_indicator_expected",
        )
    }
    display_state = (
        "PERSISTENT_CHANGES_PRESENT"
        if changes or not source_snapshot["is_clean"] or uncommitted_count
        else "NO_PERSISTENT_CHANGES"
    )
    package_change_status = dict(binding["package_update_status"])
    source_package_status_sha256 = package_change_status.pop(
        "package_update_status_sha256"
    )
    package_change_status.update(
        {
            "refresh_state": dict(binding["candidate_boundary"])["state"],
            "source_package_update_status_sha256": source_package_status_sha256,
        }
    )
    package_change_status["package_change_status_sha256"] = sha256_bytes(
        canonical_json_bytes(package_change_status)
    )
    core = {
        "schema": "evidence-lane.codex-persistent-change-display.v1",
        "state": display_state,
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "paired_step_task_list": {
            "task_count": plan_row["goal_projection_task_count"],
            "active_position": plan_row["position"],
            "active_task_id": plan_row["task_id"],
            "active_status": plan_row["status"],
            "state_travel_task_list_sha256": plan_row["state_travel_task_list_sha256"],
            "goal_projection_sha256": plan_row["goal_projection_sha256"],
        },
        "additive_change_summary": {
            "count": len(changes),
            "changes": changes,
            "raw_change_text_included": False,
        },
        "source_change_status": source_status,
        "turn_status": {
            "state": turn_state,
            "prompt_index": prompt_index,
            "uncommitted_count": uncommitted_count,
            "changed_since_prepare": changed_since_prepare,
        },
        "package_change_status": package_change_status,
        "rehydration_source": "SEALED_PROJECT_SESSION_TASK_TURN_CONTROL",
        "scrollback_authority": False,
        "transcript_authority": False,
        "access_scope": "EXACT_PROJECT_SESSION_TASK",
        "private_research_question_included": False,
        "private_reasoning_stored": False,
        "composer_mutated": False,
        "auto_submit": False,
        "lifecycle_mutated": False,
        "host_rendering_authority": "CODEX_HOST_OWNED",
    }
    if warm_attach_receipt is not None:
        core["warm_attach"] = warm_attach_receipt
    core["paired_projection_sha256"] = sha256_bytes(
        canonical_json_bytes(
            {
                "paired_step_task_list": core["paired_step_task_list"],
                "source_change_snapshot_sha256": source_status[
                    "source_change_snapshot_sha256"
                ],
                "additive_change_summary": core["additive_change_summary"],
            }
        )
    )
    core["display_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def persistent_change_system_notice(
    display: dict[str, Any],
    *,
    phase: str,
    turn_receipt: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Project one bounded host-visible notice from the sealed full display.

    Codex owns the exact UI placement of ``systemMessage``.  The plugin therefore
    requests the near-composer warning surface without claiming that it can edit
    or persist the composer itself.  Full source paths and raw Delta text stay in
    the durable receipt; this notice carries only their seals and bounded counts.
    """

    phase_value = str(phase or "").strip().upper()
    _require(
        phase_value
        in {"SESSION_START", "TURN_PREPARE", "POST_TOOL_USE", "TURN_COMMIT"},
        "TURN_CONTROL_CHANGE_NOTICE_PHASE_INVALID",
        "The persistent change notice phase is not supported.",
        phase=phase_value or None,
    )
    _require(
        display.get("schema") == "evidence-lane.codex-persistent-change-display.v1"
        and bool(display.get("display_sha256")),
        "TURN_CONTROL_CHANGE_DISPLAY_INVALID",
        "A sealed persistent change display is required for the host notice.",
    )
    paired = dict(display.get("paired_step_task_list") or {})
    additive = dict(display.get("additive_change_summary") or {})
    changes = [
        dict(row)
        for row in additive.get("changes") or []
        if isinstance(row, dict)
    ]
    source = dict(display.get("source_change_status") or {})
    tail = changes[-12:]
    receipt = dict(turn_receipt or {})
    core = {
        "schema": "evidence-lane.codex-persistent-change-system-notice.v2",
        "state": display.get("state"),
        "phase": phase_value,
        "requested_ui_surface": "CODEX_SYSTEM_MESSAGE_WARNING_NEAR_COMPOSER",
        "exact_above_prompt_bar_placement_claimed": False,
        "host_rendering_authority": "CODEX_HOST_OWNED",
        "composer_mutated": False,
        "paired_step_task_list": {
            "task_count": paired.get("task_count"),
            "active_position": paired.get("active_position"),
            "active_task_id": paired.get("active_task_id"),
            "active_status": paired.get("active_status"),
            "state_travel_task_list_sha256": paired.get(
                "state_travel_task_list_sha256"
            ),
            "goal_projection_sha256": paired.get("goal_projection_sha256"),
        },
        "linked_delta_status": {
            "count": len(changes),
            "active_delta": tail[-1] if tail else None,
            "delta_ids_tail": [row.get("delta_id") for row in tail],
            "tail_limit": 12,
            "truncated": len(changes) > len(tail),
            "delta_set_sha256": sha256_bytes(canonical_json_bytes(changes)),
            "raw_change_text_included": False,
        },
        "source_change_status": {
            "branch": source.get("branch"),
            "commit_sha": source.get("commit_sha"),
            "tree_sha": source.get("tree_sha"),
            "worktree_sha256": source.get("worktree_sha256"),
            "is_clean": source.get("is_clean"),
            "changed_path_count": source.get("changed_path_count"),
            "untracked_path_count": source.get("untracked_path_count"),
            "tracked_diff_path_count": source.get("tracked_diff_path_count"),
            "line_additions": source.get("line_additions"),
            "line_deletions": source.get("line_deletions"),
            "binary_change_count": source.get("binary_change_count"),
            "line_delta_scope": source.get("line_delta_scope"),
            "changed_paths_in_notice": False,
            "source_change_snapshot_sha256": source.get(
                "source_change_snapshot_sha256"
            ),
        },
        "turn_status": dict(display.get("turn_status") or {}),
        "package_change_status": dict(display.get("package_change_status") or {}),
        "turn_receipt": {
            key: receipt.get(key)
            for key in (
                "state",
                "prepare_state",
                "turn_id",
                "prompt_index",
                "control_record_sha256",
                "commit_sha256",
                "state_sha256",
                "projection_sha256",
            )
            if receipt.get(key) is not None
        },
        "tool_projection": {
            "tool_name": receipt.get("tool_name"),
            "tool_use_id_sha256": receipt.get("tool_use_id_sha256"),
            "read_only_projection": receipt.get("read_only_projection"),
            "tool_input_stored": False,
            "tool_response_stored": False,
        }
        if phase_value == "POST_TOOL_USE"
        else None,
        "host_binding": {
            "state": dict(receipt.get("host_binding") or {}).get("state"),
            "alias_receipt_sha256": dict(
                receipt.get("host_binding") or {}
            ).get("alias_receipt_sha256"),
            "binding_epoch_sha256": dict(
                receipt.get("host_binding") or {}
            ).get("binding_epoch_sha256"),
            "raw_host_identity_stored": False,
            "raw_transcript_path_stored": False,
        },
        "warm_attach_receipt_sha256": (
            dict(display.get("warm_attach") or {}).get("receipt_sha256")
        ),
        "full_display_sha256": display["display_sha256"],
        "private_research_question_included": False,
        "private_reasoning_stored": False,
    }
    core["notice_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def persistent_change_system_message(notice: dict[str, Any]) -> str:
    """Return one bounded secret-free host warning for the current change.

    ``systemMessage`` is the documented hook output that Codex surfaces in its
    UI. The full sealed projection remains in ``additionalContext``; this string
    stays short enough to remain readable near the composer.
    """

    paired = dict(notice.get("paired_step_task_list") or {})
    linked = dict(notice.get("linked_delta_status") or {})
    active_delta = dict(linked.get("active_delta") or {})
    source = dict(notice.get("source_change_status") or {})
    position = paired.get("active_position") or "?"
    task_count = paired.get("task_count") or "?"
    active_task_id = str(paired.get("active_task_id") or "NO_ACTIVE_TASK")
    delta_id = str(active_delta.get("delta_id") or "NO_LINKED_DELTA")
    changed_paths = int(source.get("changed_path_count") or 0)
    additions = int(source.get("line_additions") or 0)
    deletions = int(source.get("line_deletions") or 0)
    untracked = int(source.get("untracked_path_count") or 0)
    binary = int(source.get("binary_change_count") or 0)
    phase = str(notice.get("phase") or "CURRENT")
    seal = str(notice.get("notice_sha256") or "UNSEALED")[:16]
    return (
        "Evidence Lane CURRENT CHANGE | "
        f"Step {position}/{task_count} | {active_task_id} | "
        f"Delta {delta_id} | {changed_paths} files "
        f"(+{additions}/-{deletions}, {binary} binary, {untracked} untracked) | "
        f"{phase} | seal {seal}"
    )


def _source_change_receipt(
    *,
    entry_snapshot: dict[str, Any],
    exit_snapshot: dict[str, Any],
) -> dict[str, Any]:
    core = {
        "schema": "evidence-lane.codex-turn-source-change.v1",
        "entry_source_change_snapshot_sha256": entry_snapshot[
            "source_change_snapshot_sha256"
        ],
        "exit_source_change_snapshot": exit_snapshot,
        "changed_since_prepare": (
            entry_snapshot["worktree_sha256"] != exit_snapshot["worktree_sha256"]
        ),
        "status_changed_since_prepare": (
            entry_snapshot["worktree_status_sha256"]
            != exit_snapshot["worktree_status_sha256"]
        ),
        "candidate_created": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "source_mutated_by_projection": False,
    }
    core["source_change_receipt_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def _read_only(path: Path) -> sqlite3.Connection:
    _require(
        path.is_file(),
        "TURN_CONTROL_RETRIEVAL_AUTHORITY_REQUIRED",
        "A required governed SQLite retrieval authority is missing.",
        path=str(path),
    )
    connection = sqlite3.connect(str(path), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _behavior_query_handoff_receipt(
    *,
    binding: dict[str, Any],
    visible_text: str,
) -> dict[str, Any]:
    """Seal the handoff from lifecycle PREPARE to skill-owned behavior.

    PREPARE intentionally performs no project or accepted-PV retrieval. The
    active Evidence Lane skill must make the visible native MCP reads and then
    refresh the host Step Task List. Keeping the compatibility receipt field
    avoids rewriting existing turn-control SQLite while making ownership and
    the unsatisfied behavior gate explicit.
    """

    receipt = {
        "schema": "evidence-lane.codex-native-behavior-query-handoff.v1",
        "outcome": "PENDING_NATIVE_SKILL_QUERY",
        "query_sha256": sha256_bytes(visible_text.encode("utf-8")),
        "query_terms_present": False,
        "accepted_pv": binding["accepted_pv"],
        "pointer_generation": binding["pointer_generation"],
        "entry_manifest_sha256": binding["entry_manifest_sha256"],
        "lineage_results": [],
        "accepted_code_results": [],
        "lineage_result_count": 0,
        "accepted_code_result_count": 0,
        "bounded_result_limit_per_authority": 0,
        "candidate_overlay_used": False,
        "scrollback_used": False,
        "transcript_used": False,
        "no_hit_is_valid": False,
        "query_owner": "SKILL",
        "hook_lookup_performed": False,
        "native_behavior_query_required": True,
        "native_behavior_query_satisfied": False,
        "required_native_read_sequence": [
            "pv_status",
            "pv_task_backlog",
            "pv_query",
        ],
        "host_plan_refresh_owner": "SKILL",
        "host_plan_tool": "update_plan",
    }
    receipt["retrieval_receipt_sha256"] = sha256_bytes(canonical_json_bytes(receipt))
    return receipt


def _connection(project_root: Path) -> sqlite3.Connection:
    path = project_root / "lineage" / "codex_turn_control.sqlite"
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA journal_mode=DELETE")
    connection.execute("PRAGMA synchronous=FULL")
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS host_session_alias(
            alias_receipt_sha256 TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            evidence_session_id TEXT NOT NULL,
            governed_host_session_id_sha256 TEXT NOT NULL,
            observed_host_session_id_sha256 TEXT NOT NULL,
            transcript_path_sha256 TEXT NOT NULL,
            binding_epoch_sha256 TEXT NOT NULL,
            record_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            engine_version TEXT NOT NULL,
            UNIQUE(observed_host_session_id_sha256, binding_epoch_sha256)
        ) STRICT;
        CREATE INDEX IF NOT EXISTS host_session_alias_project_session_idx
            ON host_session_alias(project_id, evidence_session_id, recorded_at);
        CREATE TABLE IF NOT EXISTS turn_entry(
            control_record_sha256 TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            evidence_session_id TEXT NOT NULL,
            host_session_id TEXT NOT NULL,
            turn_id TEXT NOT NULL,
            input_kind TEXT NOT NULL CHECK(input_kind IN ('user_prompt','steer','goal')),
            prompt_index INTEGER NOT NULL CHECK(prompt_index > 0),
            prompt_record_sha256 TEXT NOT NULL UNIQUE,
            prior_control_record_sha256 TEXT REFERENCES turn_entry(control_record_sha256),
            binding_sha256 TEXT NOT NULL,
            retrieval_receipt_sha256 TEXT NOT NULL,
            record_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            UNIQUE(project_id, evidence_session_id, prompt_index)
        ) STRICT;
        CREATE VIRTUAL TABLE IF NOT EXISTS turn_entry_fts USING fts5(
            control_record_sha256 UNINDEXED,
            project_id UNINDEXED,
            evidence_session_id UNINDEXED,
            turn_id,
            input_kind,
            visible_text,
            tokenize='unicode61'
        );
        CREATE TABLE IF NOT EXISTS turn_tool_event(
            tool_event_sha256 TEXT PRIMARY KEY,
            control_record_sha256 TEXT NOT NULL REFERENCES turn_entry(control_record_sha256),
            tool_use_id TEXT NOT NULL,
            phase TEXT NOT NULL CHECK(phase IN ('before','after')),
            tool_name TEXT NOT NULL,
            lineage_event_sha256 TEXT NOT NULL,
            event_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            UNIQUE(tool_use_id, phase)
        ) STRICT;
        CREATE TABLE IF NOT EXISTS turn_commit(
            commit_sha256 TEXT PRIMARY KEY,
            control_record_sha256 TEXT NOT NULL REFERENCES turn_entry(control_record_sha256),
            response_record_sha256 TEXT NOT NULL UNIQUE,
            lineage_event_sha256 TEXT NOT NULL,
            commit_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL
        ) STRICT;
        CREATE UNIQUE INDEX IF NOT EXISTS turn_commit_one_per_entry
            ON turn_commit(control_record_sha256);
        CREATE VIRTUAL TABLE IF NOT EXISTS turn_commit_fts USING fts5(
            commit_sha256 UNINDEXED,
            control_record_sha256 UNINDEXED,
            turn_id UNINDEXED,
            project_id UNINDEXED,
            visible_response,
            operational_links,
            tokenize='unicode61'
        );
        CREATE TABLE IF NOT EXISTS turn_research_question(
            research_record_sha256 TEXT PRIMARY KEY,
            control_record_sha256 TEXT NOT NULL UNIQUE
                REFERENCES turn_entry(control_record_sha256),
            project_id TEXT NOT NULL,
            evidence_session_id TEXT NOT NULL,
            task_id TEXT NOT NULL,
            turn_id TEXT NOT NULL,
            prompt_index INTEGER NOT NULL CHECK(prompt_index > 0),
            access_scope TEXT NOT NULL
                CHECK(access_scope='PROJECT_TASK_PRIVATE_ANALYSIS'),
            research_focus TEXT NOT NULL,
            question_sha256_after_redaction TEXT NOT NULL,
            visible_question_after_redaction TEXT NOT NULL,
            prior_research_record_sha256 TEXT
                REFERENCES turn_research_question(research_record_sha256),
            record_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            UNIQUE(project_id, evidence_session_id, task_id, prompt_index)
        ) STRICT;
        CREATE INDEX IF NOT EXISTS turn_research_project_task_idx
            ON turn_research_question(project_id, evidence_session_id, task_id, prompt_index);
        CREATE TABLE IF NOT EXISTS turn_goal_usage(
            usage_record_sha256 TEXT PRIMARY KEY,
            control_record_sha256 TEXT NOT NULL UNIQUE
                REFERENCES turn_entry(control_record_sha256),
            project_id TEXT NOT NULL,
            evidence_session_id TEXT NOT NULL,
            task_id TEXT NOT NULL,
            turn_id TEXT NOT NULL,
            prompt_index INTEGER NOT NULL CHECK(prompt_index > 0),
            availability TEXT NOT NULL CHECK(availability IN ('AVAILABLE','UNAVAILABLE')),
            goal_id TEXT,
            metric_semantics TEXT,
            goal_accounted_tokens INTEGER CHECK(goal_accounted_tokens >= 0),
            prior_usage_record_sha256 TEXT
                REFERENCES turn_goal_usage(usage_record_sha256),
            observation_sha256 TEXT NOT NULL,
            record_json TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            UNIQUE(project_id, evidence_session_id, prompt_index),
            CHECK(
                (availability='AVAILABLE' AND goal_id IS NOT NULL
                    AND metric_semantics IS NOT NULL
                    AND goal_accounted_tokens IS NOT NULL)
                OR
                (availability='UNAVAILABLE' AND goal_accounted_tokens IS NULL)
            )
        ) STRICT;
        CREATE INDEX IF NOT EXISTS turn_goal_usage_project_task_idx
            ON turn_goal_usage(project_id, evidence_session_id, task_id, prompt_index);
        """
    )
    return connection


def _ensure_research_question(
    connection: sqlite3.Connection,
    *,
    entry: dict[str, Any],
) -> dict[str, Any]:
    """Append one private project-task research question for a research-mode turn."""

    policy = (entry.get("binding") or {}).get("research_policy") or {}
    if policy.get("enabled") is not True:
        return {
            "state": "NOT_APPLICABLE",
            "reason": "RESEARCH_MODE_NOT_ACTIVE",
            "access_scope": _PROJECT_TASK_PRIVATE_ANALYSIS,
            "cross_project_retrieval": False,
        }
    existing = connection.execute(
        """
        SELECT record_json FROM turn_research_question
        WHERE control_record_sha256=?
        """,
        (entry["control_record_sha256"],),
    ).fetchone()
    if existing is not None:
        record = json.loads(existing["record_json"])
        claimed = str(record.get("research_record_sha256") or "")
        actual = sha256_bytes(
            canonical_json_bytes(
                {
                    key: value
                    for key, value in record.items()
                    if key != "research_record_sha256"
                }
            )
        )
        _require(
            claimed == actual,
            "TURN_CONTROL_RESEARCH_RECORD_MISMATCH",
            "A private project-task research record failed its SHA-256 verification.",
        )
        action = "RECORDED_IDEMPOTENT_REUSE"
    else:
        prior = connection.execute(
            """
            SELECT research_record_sha256 FROM turn_research_question
            WHERE project_id=? AND evidence_session_id=? AND task_id=?
            ORDER BY prompt_index DESC LIMIT 1
            """,
            (entry["project_id"], entry["evidence_session_id"], entry["task_id"]),
        ).fetchone()
        visible_question = str(entry["visible_input_after_redaction"])
        _require(
            not contains_secret(visible_question),
            "TURN_CONTROL_RESEARCH_REDACTION_FAILED",
            "A secret-like value remained in the private project-task research question.",
        )
        research_focus = str(policy.get("focus") or "PROJECT_TASK_RESEARCH")
        aligned_research_question = (
            _MEMORY_PLUS_LEARNING_RESEARCH_QUESTION
            if research_focus == "MEMORY_PLUS_LEARNING"
            else visible_question
        )
        _require(
            not contains_secret(aligned_research_question),
            "TURN_CONTROL_RESEARCH_ALIGNMENT_REDACTION_FAILED",
            "A secret-like value remained in the aligned private research question.",
        )
        record = {
            "schema": "evidence-lane.project-task-research-question.v2",
            "project_id": entry["project_id"],
            "evidence_session_id": entry["evidence_session_id"],
            "task_id": entry["task_id"],
            "plan_task_id": entry["plan_task_id"],
            "host_session_id_sha256": sha256_bytes(
                str(entry["host_session_id"]).encode("utf-8")
            ),
            "turn_id": entry["turn_id"],
            "prompt_index": entry["prompt_index"],
            "control_record_sha256": entry["control_record_sha256"],
            "question_kind": entry["input_kind"],
            "visible_question_after_redaction": visible_question,
            "question_sha256_after_redaction": sha256_bytes(
                visible_question.encode("utf-8")
            ),
            "research_focus": research_focus,
            "research_focus_basis_sha256": policy.get("focus_basis_sha256"),
            "aligned_research_question": aligned_research_question,
            "aligned_research_question_sha256": sha256_bytes(
                aligned_research_question.encode("utf-8")
            ),
            "alignment_basis": "PERSISTENT_PLAN_ROW_AND_LINKED_STEER_DELTAS",
            "autolog_scope": "CURRENT_PROJECT_SESSION_TASK_ONLY",
            "linked_steer_delta_receipts": entry["binding"]["persistent_plan_row"].get(
                "linked_steer_delta_receipts", []
            ),
            "access_scope": _PROJECT_TASK_PRIVATE_ANALYSIS,
            "cross_project_retrieval": False,
            "shared_global_telemetry": False,
            "shared_fts_indexed": False,
            "public_output_included": False,
            "candidate_claim_included": False,
            "raw_question_stored": False,
            "private_reasoning_stored": False,
            "prior_research_record_sha256": (
                prior["research_record_sha256"] if prior else None
            ),
            "recorded_at": entry["prepared_at"],
        }
        record["research_record_sha256"] = sha256_bytes(canonical_json_bytes(record))
        connection.execute(
            """
            INSERT INTO turn_research_question VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                record["research_record_sha256"],
                record["control_record_sha256"],
                record["project_id"],
                record["evidence_session_id"],
                record["task_id"],
                record["turn_id"],
                record["prompt_index"],
                record["access_scope"],
                record["research_focus"],
                record["question_sha256_after_redaction"],
                record["visible_question_after_redaction"],
                record["prior_research_record_sha256"],
                json.dumps(record, sort_keys=True, separators=(",", ":")),
                record["recorded_at"],
            ),
        )
        action = "RECORDED"
    return {
        "state": action,
        "research_record_sha256": record["research_record_sha256"],
        "research_focus": record["research_focus"],
        "access_scope": record["access_scope"],
        "cross_project_retrieval": False,
        "shared_fts_indexed": False,
        "private_reasoning_stored": False,
    }


def _goal_usage_observation(host_payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize only trustworthy Goal-accounted counters exposed by the host."""

    raw = host_payload.get("goal_usage")
    if raw is None:
        observation: dict[str, Any] = {
            "schema": "evidence-lane.goal-usage-observation.v1",
            "availability": "UNAVAILABLE",
            "reason": "HOST_GOAL_ACCOUNTED_COUNTER_NOT_EXPOSED",
            "accounting_basis": "GOAL_ACCOUNTED_TOKENS_ONLY",
            "goal_id": None,
            "metric_semantics": None,
            "goal_accounted_tokens": None,
            "provided_fields": [],
            "aggregation_rule": "NEVER_SUM_CUMULATIVE_SNAPSHOTS",
            "task_status_effect": "NONE",
            "goal_completion_effect": "NONE",
            "private_reasoning_stored": False,
        }
        observation["observation_sha256"] = sha256_bytes(
            canonical_json_bytes(observation)
        )
        return observation
    _require(
        isinstance(raw, dict),
        "TURN_CONTROL_GOAL_USAGE_INVALID",
        "Host Goal usage must be a structured provenance object.",
    )
    safe = _turn_redact(raw)
    serialized = json.dumps(
        safe, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    _require(
        not contains_secret(serialized),
        "TURN_CONTROL_GOAL_USAGE_REDACTION_FAILED",
        "A secret-like value remained in Goal usage provenance.",
    )
    goal_id = str(safe.get("goal_id") or "").strip()
    semantics = str(safe.get("metric_semantics") or "").strip().upper()
    tokens = safe.get("goal_accounted_tokens")
    provenance = safe.get("provenance")
    complete = (
        bool(goal_id)
        and semantics in _GOAL_USAGE_SEMANTICS
        and isinstance(tokens, int)
        and not isinstance(tokens, bool)
        and tokens >= 0
        and isinstance(provenance, dict)
        and bool(str(provenance.get("source") or "").strip())
    )
    if complete:
        elapsed_seconds = safe.get("elapsed_seconds")
        _require(
            elapsed_seconds is None
            or (
                isinstance(elapsed_seconds, int)
                and not isinstance(elapsed_seconds, bool)
                and elapsed_seconds >= 0
            ),
            "TURN_CONTROL_GOAL_ELAPSED_INVALID",
            "Goal elapsed seconds must be an exact non-negative integer when supplied.",
        )
        observation = {
            "schema": "evidence-lane.goal-usage-observation.v1",
            "availability": "AVAILABLE",
            "accounting_basis": "GOAL_ACCOUNTED_TOKENS_ONLY",
            "goal_id": goal_id,
            "metric_semantics": semantics,
            "goal_accounted_tokens": tokens,
            "elapsed_seconds": elapsed_seconds,
            "provenance": provenance,
            "aggregation_rule": "NEVER_SUM_CUMULATIVE_SNAPSHOTS",
            "task_status_effect": "NONE",
            "goal_completion_effect": "NONE",
            "exact_counts_preserved": True,
            "private_reasoning_stored": False,
        }
    else:
        observation = {
            "schema": "evidence-lane.goal-usage-observation.v1",
            "availability": "UNAVAILABLE",
            "reason": "INCOMPLETE_OR_UNTRUSTWORTHY_GOAL_USAGE_PROVENANCE",
            "accounting_basis": "GOAL_ACCOUNTED_TOKENS_ONLY",
            "goal_id": None,
            "metric_semantics": None,
            "goal_accounted_tokens": None,
            "provided_fields": sorted(str(key) for key in safe),
            "aggregation_rule": "NEVER_SUM_CUMULATIVE_SNAPSHOTS",
            "task_status_effect": "NONE",
            "goal_completion_effect": "NONE",
            "private_reasoning_stored": False,
        }
    observation["observation_sha256"] = sha256_bytes(canonical_json_bytes(observation))
    return observation


def _ensure_goal_usage(
    connection: sqlite3.Connection,
    *,
    entry: dict[str, Any],
    observation: dict[str, Any],
    recorded_at: str,
) -> dict[str, Any]:
    """Append one idempotent project-local Goal usage observation per committed turn."""

    existing = connection.execute(
        "SELECT record_json FROM turn_goal_usage WHERE control_record_sha256=?",
        (entry["control_record_sha256"],),
    ).fetchone()
    if existing is not None:
        record = json.loads(existing["record_json"])
        claimed = str(record.get("usage_record_sha256") or "")
        actual = sha256_bytes(
            canonical_json_bytes(
                {
                    key: value
                    for key, value in record.items()
                    if key != "usage_record_sha256"
                }
            )
        )
        _require(
            claimed == actual and record.get("observation") == observation,
            "TURN_CONTROL_GOAL_USAGE_RECORD_MISMATCH",
            "The turn already binds different Goal usage evidence.",
        )
        action = "RECORDED_IDEMPOTENT_REUSE"
    else:
        prior = connection.execute(
            """
            SELECT usage_record_sha256 FROM turn_goal_usage
            WHERE project_id=? AND evidence_session_id=?
            ORDER BY prompt_index DESC LIMIT 1
            """,
            (entry["project_id"], entry["evidence_session_id"]),
        ).fetchone()
        record = {
            "schema": "evidence-lane.project-goal-usage-record.v1",
            "project_id": entry["project_id"],
            "evidence_session_id": entry["evidence_session_id"],
            "task_id": entry["task_id"],
            "turn_id": entry["turn_id"],
            "prompt_index": entry["prompt_index"],
            "control_record_sha256": entry["control_record_sha256"],
            "observation": observation,
            "observation_sha256": observation["observation_sha256"],
            "prior_usage_record_sha256": (
                prior["usage_record_sha256"] if prior else None
            ),
            "project_local_only": True,
            "cross_project_aggregation": False,
            "intermediate_snapshot_double_count_prevented": True,
            "private_reasoning_stored": False,
            "recorded_at": recorded_at,
        }
        record["usage_record_sha256"] = sha256_bytes(canonical_json_bytes(record))
        connection.execute(
            """
            INSERT INTO turn_goal_usage VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                record["usage_record_sha256"],
                record["control_record_sha256"],
                record["project_id"],
                record["evidence_session_id"],
                record["task_id"],
                record["turn_id"],
                record["prompt_index"],
                observation["availability"],
                observation.get("goal_id"),
                observation.get("metric_semantics"),
                observation.get("goal_accounted_tokens"),
                record["prior_usage_record_sha256"],
                record["observation_sha256"],
                json.dumps(record, sort_keys=True, separators=(",", ":")),
                record["recorded_at"],
            ),
        )
        action = "RECORDED"
    return {
        "state": action,
        "availability": observation["availability"],
        "usage_record_sha256": record["usage_record_sha256"],
        "observation_sha256": observation["observation_sha256"],
        "goal_id": observation.get("goal_id"),
        "metric_semantics": observation.get("metric_semantics"),
        "goal_accounted_tokens": observation.get("goal_accounted_tokens"),
        "aggregation_rule": "NEVER_SUM_CUMULATIVE_SNAPSHOTS",
        "project_local_only": True,
        "private_reasoning_stored": False,
    }


@contextmanager
def _control_lock(project_root: Path):
    """Serialize one project's Prepare/Commit projection without a second writer."""

    path = project_root / "lineage" / "codex_turn_control.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor: int | None = None
    for _ in range(200):
        try:
            descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            break
        except FileExistsError:
            time.sleep(0.025)
    _require(
        descriptor is not None,
        "TURN_CONTROL_SINGLE_WRITER_BUSY",
        "The governed Codex turn-control writer is already active.",
        lock_path=str(path),
    )
    try:
        yield
    finally:
        if descriptor is not None:
            os.close(descriptor)
        try:
            path.unlink()
        except FileNotFoundError:
            pass


_GOAL_CONTEXT_MARKER = re.compile(
    r"^\s*<codex_internal_context\b(?=[^>]*\bsource=(?:\"goal\"|'goal'))[^>]*>",
    flags=re.IGNORECASE,
)


def _goal_context_marker_present(visible_input: str) -> bool:
    return _GOAL_CONTEXT_MARKER.match(visible_input) is not None


def _input_kind(host_payload: dict[str, Any]) -> str:
    """Return only the classification knowable without sealed turn history.

    This is used by deterministic gap receipts.  A caller's ``source`` or
    ``is_steer``/``is_goal`` flags are deliberately ignored.
    """

    visible = _turn_redact_text(str(host_payload.get("prompt") or ""))
    return "goal" if _goal_context_marker_present(visible) else "user_prompt"


def _derive_input_kind(
    visible_input: str,
    *,
    prior_same_turn_input: bool,
) -> tuple[str, str]:
    """Derive prompt/steer/Goal from native input plus sealed turn state."""

    if _goal_context_marker_present(visible_input):
        return "goal", "CODEX_INTERNAL_GOAL_CONTEXT_MARKER"
    if prior_same_turn_input:
        return "steer", "PRIOR_SEALED_INPUT_FOR_SAME_HOST_TURN"
    return "user_prompt", "FIRST_SEALED_INPUT_FOR_HOST_TURN"


def _capture_dispatch(
    host_payload: dict[str, Any], *, input_kind: str, classification_basis: str
) -> dict[str, Any]:
    """Seal truthful host-dispatch provenance for one visible input.

    Codex's pending-input dispatcher invokes ``UserPromptSubmit`` for each
    ``TurnInput::UserInput`` before the model sees it. The hook adapter can
    prove that it executed against a host-shaped payload; only a separate
    installed-host acceptance correlation may claim independent dispatch
    proof. Goal control uses ``thread/goal/set`` and fails closed here.
    """

    expected_by_kind: dict[str, dict[str, Any]] = {
        "user_prompt": {
            "surface": "USER_PROMPT_CORRECTION_OR_HIL_TOKEN",
            "host_route": "turn/start -> inspect_pending_input(TurnInput::UserInput)",
            "native_hook_event": "UserPromptSubmit",
        },
        "steer": {
            "surface": "MID_GOAL_STEER",
            "host_route": "turn/steer -> inspect_pending_input(TurnInput::UserInput)",
            "native_hook_event": "UserPromptSubmit",
        },
        "goal": {
            "surface": "GOAL_CONTINUATION",
            "host_route": "thread/goal/set (not TurnInput::UserInput)",
            "native_hook_event": None,
        },
    }
    expected = expected_by_kind[input_kind]
    _require(
        input_kind != "goal",
        "TURN_CONTROL_GOAL_PRE_REASONING_HOOK_UNAVAILABLE",
        "Codex Goal control bypasses UserPromptSubmit; governed Goal PREPARE is unavailable and must fail closed.",
        surface=expected["surface"],
        host_route=expected["host_route"],
        host_capability="UNAVAILABLE",
    )
    supplied = host_payload.get("evidence_lane_capture_dispatch")
    if not isinstance(supplied, dict):
        return {
            **expected,
            "native_dispatch_surface": None,
            "native_dispatch_route": None,
            "host_dispatch_supported": False,
            "pre_reasoning_dispatch_proven": False,
            "adapter_invocation_observed": False,
            "installed_host_dispatch_independently_proven": False,
            "input_kind_derived_from_sealed_state": True,
            "classification_basis": classification_basis,
            "caller_input_kind_authority": False,
            "state": "CALLER_HAS_NO_NATIVE_DISPATCH_RECEIPT",
        }
    exact = {
        "native_dispatch_surface": str(supplied.get("surface") or ""),
        "native_dispatch_route": str(supplied.get("host_route") or ""),
        "native_hook_event": supplied.get("native_hook_event"),
        "host_payload_hook_event_name": str(
            supplied.get("host_payload_hook_event_name") or ""
        ),
        "adapter_invocation_observed": supplied.get(
            "adapter_invocation_observed"
        )
        is True,
        "installed_host_dispatch_independently_proven": supplied.get(
            "installed_host_dispatch_independently_proven"
        )
        is True,
        "input_kind_derived_from_sealed_state": supplied.get(
            "input_kind_derived_from_sealed_state"
        )
        is True,
        "caller_input_kind_authority": supplied.get("caller_input_kind_authority")
        is True,
    }
    proven = (
        exact["native_dispatch_surface"] == "PENDING_VISIBLE_USER_INPUT"
        and exact["native_dispatch_route"]
        == "inspect_pending_input(TurnInput::UserInput)"
        and exact["native_hook_event"] == expected["native_hook_event"]
        and exact["host_payload_hook_event_name"] == "UserPromptSubmit"
        and str(host_payload.get("hook_event_name") or "") == "UserPromptSubmit"
        and exact["adapter_invocation_observed"] is True
        and exact["installed_host_dispatch_independently_proven"] is False
        and exact["input_kind_derived_from_sealed_state"] is True
        and supplied.get("caller_input_kind_authority") is False
        and exact["caller_input_kind_authority"] is False
    )
    _require(
        proven,
        "TURN_CONTROL_NATIVE_DISPATCH_RECEIPT_INVALID",
        "A visible input cannot claim pre-reasoning capture through the wrong host surface.",
        input_kind=input_kind,
        expected_surface="PENDING_VISIBLE_USER_INPUT",
        supplied_surface=exact["native_dispatch_surface"],
    )
    return {
        **expected,
        **exact,
        "host_dispatch_supported": True,
        "pre_reasoning_dispatch_proven": True,
        "pre_reasoning_proof_basis": "VALIDATED_USERPROMPTSUBMIT_HOST_PAYLOAD_AND_ADAPTER_INVOCATION",
        "independent_installed_host_proof_required": True,
        "classification_basis": classification_basis,
        "state": "USERPROMPTSUBMIT_ADAPTER_INVOKED",
    }


def _host_key(host_session_id: str) -> str:
    return "host-" + sha256_bytes(host_session_id.encode("utf-8"))[:40].lower()


def _projection_path(
    root: Path,
    *,
    kind: str,
    host_session_id: str,
    prompt_index: int,
    turn_id: str,
) -> Path:
    turn_key = sha256_bytes(turn_id.encode("utf-8"))[:16].lower()
    return (
        root
        / f"{kind}-index"
        / _host_key(host_session_id)
        / f"{prompt_index:08d}-{turn_key}.json"
    )


def record_non_strict_visible_input(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
) -> dict[str, Any]:
    """Retain the bounded v1 prompt index until sealed Mode plus Plan is active.

    This compatibility path records only the secret-redacted visible user input.
    It does not create a strict PREPARE, authorize source mutation, run research
    retrieval, or persist private reasoning.  Once strict turn control is active,
    ``prepare_turn`` is the sole prompt-entry writer.
    """

    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    turn_id = str(host_payload.get("turn_id") or "").strip()
    _require(
        bool(host_session_id and turn_id),
        "TURN_CONTROL_HOST_TURN_IDENTITY_REQUIRED",
        "Visible-input indexing requires exact host-session and turn identities.",
    )
    policy = policy_state(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    _require(
        policy.get("governed_session") is True
        and policy.get("strict_required") is False,
        "TURN_CONTROL_NON_STRICT_POLICY_NOT_ACTIVE",
        "Compatibility indexing is available only before sealed Mode plus Plan activates.",
        policy=policy,
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    project_root = Path(bound["project_root"])
    project = bound["project"]
    session = bound["session"]
    metadata = session.get("metadata") or {}
    pointer = _json(project_root / "active_pointer.json")
    project_id = str(session.get("project_id") or "")
    evidence_session_id = str(session.get("session_id") or "")
    accepted_pv = pointer.get("accepted_pv")
    pointer_generation = int(pointer.get("generation") or 0)
    _require(
        bool(project_id and evidence_session_id)
        and project_id == project.get("project_id") == pointer.get("project_id"),
        "TURN_CONTROL_PROJECT_SESSION_POINTER_MISMATCH",
        "Project, session, and accepted-pointer identities do not agree.",
    )
    _require(
        session.get("accepted_pv") == accepted_pv
        and int(session.get("accepted_pointer_generation") or 0)
        == pointer_generation
        and metadata.get("entry_pv") == accepted_pv,
        "TURN_CONTROL_ENTRY_POINTER_MISMATCH",
        "The governed Entry boundary does not match the accepted pointer.",
        accepted_pv=accepted_pv,
        pointer_generation=pointer_generation,
    )
    visible_input = _turn_redact_text(str(host_payload.get("prompt") or ""))
    _require(
        bool(visible_input.strip()),
        "TURN_CONTROL_VISIBLE_INPUT_REQUIRED",
        "Visible-input indexing requires a non-empty prompt, steer, or Goal.",
    )
    _require(
        not contains_secret(visible_input),
        "TURN_CONTROL_SECRET_REDACTION_FAILED",
        "A secret-like value remained in the visible input after redaction.",
    )
    visible_input_sha256 = sha256_bytes(visible_input.encode("utf-8"))
    task = session.get("task") if isinstance(session.get("task"), dict) else {}
    task_id = str(task.get("task_id") or "") or None

    with _control_lock(project_root):
        try:
            all_records = PromptIndex(root)._all_records()
        except EvidenceLaneError as exc:
            raise TurnControlError(
                "TURN_CONTROL_PROMPT_INDEX_AUTHORITY_INVALID",
                "The existing prompt-index authority could not be verified.",
                upstream_code=exc.code,
                upstream_status=exc.status,
                **exc.details,
            ) from exc
        records = [
            row
            for row in all_records
            if row.get("project_id") == project_id
            and row.get("evidence_session_id") == evidence_session_id
        ]
        same_turn_records = [
            row
            for row in records
            if row.get("host_session_id") == host_session_id
            and row.get("turn_id") == turn_id
        ]
        duplicate = next(
            (
                row
                for row in same_turn_records
                if row.get("prompt_sha256_after_redaction")
                == visible_input_sha256
            ),
            None,
        )
        if duplicate is None:
            input_kind, classification_basis = _derive_input_kind(
                visible_input,
                prior_same_turn_input=bool(same_turn_records),
            )
            capture_dispatch = _capture_dispatch(
                host_payload,
                input_kind=input_kind,
                classification_basis=classification_basis,
            )
            prior = records[-1] if records else None
            prompt_index = int(prior.get("prompt_index") or 0) + 1 if prior else 1
            recorded_at = _now()
            lineage_telemetry = _response_telemetry(host_payload)
            record = {
                "schema": "evidence-lane.prompt-index.v1",
                "host_session_id": host_session_id,
                "turn_id": turn_id,
                "input_kind": input_kind,
                "input_kind_classification_basis": classification_basis,
                "capture_dispatch": capture_dispatch,
                "prompt_index": prompt_index,
                "visible_prompt_after_redaction": visible_input,
                "prompt_sha256_after_redaction": visible_input_sha256,
                "prompt_chars_after_redaction": len(visible_input),
                "raw_prompt_stored": False,
                "redacted_visible_prompt_stored": True,
                "project_id": project_id,
                "evidence_session_id": evidence_session_id,
                "entry_pv": accepted_pv,
                "pointer_generation": pointer_generation,
                "cwd_sha256": sha256_bytes(
                    str(host_payload.get("cwd") or "").encode("utf-8")
                ),
                "lineage_host_identity": _lineage_host_identity(host_payload),
                "lineage_model": lineage_telemetry["model"],
                "lineage_submodel": lineage_telemetry["submodel"],
                "lineage_token_metrics": lineage_telemetry["token_metrics"],
                "prior_record_sha256": (
                    prior.get("record_sha256") if prior is not None else None
                ),
                "recorded_at": recorded_at,
            }
            record["record_sha256"] = sha256_bytes(canonical_json_bytes(record))
            prompt_path = _projection_path(
                root,
                kind="prompt",
                host_session_id=host_session_id,
                prompt_index=prompt_index,
                turn_id=turn_id,
            )
            _require(
                not prompt_path.exists(),
                "TURN_CONTROL_PROMPT_PROJECTION_CONFLICT",
                "The next prompt-index projection path is already occupied.",
                prompt_index=prompt_index,
            )
            atomic_write_json(prompt_path, record)
            action = "INDEXED"
        else:
            record = duplicate
            input_kind = str(record.get("input_kind") or "user_prompt")
            classification_basis = str(
                record.get("input_kind_classification_basis")
                or (record.get("capture_dispatch") or {}).get(
                    "classification_basis"
                )
                or "LEGACY_EXACT_INPUT_REPLAY"
            )
            capture_dispatch = _capture_dispatch(
                host_payload,
                input_kind=input_kind,
                classification_basis=classification_basis,
            )
            if isinstance(record.get("capture_dispatch"), dict):
                _require(
                    record["capture_dispatch"] == capture_dispatch,
                    "TURN_CONTROL_NATIVE_DISPATCH_RECEIPT_DRIFT",
                    "The replayed visible input no longer matches its native dispatch receipt.",
                )
            prompt_index = int(record["prompt_index"])
            recorded_at = str(record["recorded_at"])
            action = "INDEXED_IDEMPOTENT_REUSE"

        event_id = (
            "evt_"
            + sha256_bytes(
                (str(record["record_sha256"]) + "\0non-strict-visible-input").encode(
                    "utf-8"
                )
            )[:26].lower()
        )
        lineage = ChatLineage(
            project_root / "lineage" / f"{evidence_session_id}.jsonl"
        )
        host_identity = record.get("lineage_host_identity")
        lineage_model_value = record.get("lineage_model")
        lineage_submodel_value = record.get("lineage_submodel")
        lineage_metrics_value = record.get("lineage_token_metrics")
        lineage_model = (
            lineage_model_value if isinstance(lineage_model_value, str) else None
        )
        lineage_submodel = (
            lineage_submodel_value
            if isinstance(lineage_submodel_value, str)
            else None
        )
        lineage_token_metrics = (
            cast(dict[str, Any], lineage_metrics_value)
            if isinstance(lineage_metrics_value, dict)
            else {"availability": "UNAVAILABLE"}
        )
        try:
            event = lineage.append(
                event_type={
                    "steer": "turn.visible_user_steer",
                    "goal": "turn.visible_user_goal",
                }.get(input_kind, "turn.visible_user_prompt"),
                visible_payload={
                    "turn_id": turn_id,
                    "prompt_index": prompt_index,
                    "input_kind": input_kind,
                    "visible_user_prompt_after_redaction": record[
                        "visible_prompt_after_redaction"
                    ],
                    "prompt_sha256_after_redaction": record[
                        "prompt_sha256_after_redaction"
                    ],
                    "prompt_record_sha256": record["record_sha256"],
                    "entry_pv": accepted_pv,
                    "pointer_generation": pointer_generation,
                    "lifecycle_state": session.get("state"),
                    **(
                        {"host_identity": host_identity}
                        if isinstance(host_identity, dict)
                        else {}
                    ),
                    "strict_turn_control_active": False,
                    "private_reasoning_excluded": True,
                },
                occurred_at=recorded_at,
                session_id=evidence_session_id,
                task_id=task_id,
                event_id=event_id,
                actor_type="user",
                model=lineage_model,
                submodel=lineage_submodel,
                token_metrics=lineage_token_metrics,
            )
        except EvidenceLaneError as exc:
            raise TurnControlError(
                "TURN_CONTROL_VISIBLE_INPUT_LINEAGE_INVALID",
                "The visible-input ChatLineage event could not be verified.",
                upstream_code=exc.code,
                upstream_status=exc.status,
                **exc.details,
            ) from exc

    return {
        "schema": "evidence-lane.non-strict-visible-input.v1",
        "state": action,
        "prompt_index": prompt_index,
        "turn_id": turn_id,
        "input_kind": input_kind,
        "input_kind_classification_basis": classification_basis,
        "capture_dispatch": capture_dispatch,
        "pre_reasoning_host_dispatch_proven": capture_dispatch[
            "pre_reasoning_dispatch_proven"
        ],
        "project_id": project_id,
        "evidence_session_id": evidence_session_id,
        "entry_pv": accepted_pv,
        "pointer_generation": pointer_generation,
        "raw_prompt_stored": False,
        "redacted_visible_prompt_stored": True,
        "private_reasoning_stored": False,
        "strict_prepare_created": False,
        "source_mutation_authorized": False,
        "record_sha256": record["record_sha256"],
        "lineage_event_id": event["event_id"],
        "lineage_event_sha256": event["event_sha256"],
    }


def _attachment_identities(
    host_payload: dict[str, Any],
    *,
    repository_path: str,
) -> list[dict[str, Any]]:
    values: list[Any] = []
    for key in ("attachments", "files", "file_paths", "context_files"):
        raw = host_payload.get(key)
        if isinstance(raw, list):
            values.extend(raw)
        elif raw is not None:
            values.append(raw)
    repository = Path(repository_path).resolve()
    identities: list[dict[str, Any]] = []
    seen: set[str] = set()
    for value in values[:200]:
        if isinstance(value, dict):
            identity: dict[str, Any] = {
                str(key): _turn_redact(item)
                for key, item in value.items()
                if str(key)
                in {
                    "id",
                    "name",
                    "path",
                    "file_path",
                    "mime_type",
                    "media_type",
                    "size",
                    "sha256",
                }
            }
            raw_path = identity.get("path") or identity.get("file_path")
        else:
            identity = {"path": _turn_redact_text(str(value))}
            raw_path = identity["path"]
        if isinstance(raw_path, str) and raw_path.strip():
            candidate = Path(raw_path)
            if not candidate.is_absolute():
                candidate = repository / candidate
            try:
                resolved = candidate.resolve()
                if resolved.is_file():
                    identity["content_sha256"] = sha256_file(resolved)
                    identity["size"] = resolved.stat().st_size
                    identity["inside_governed_repository"] = _within(
                        resolved, repository
                    )
            except OSError:
                identity["content_identity_availability"] = "UNAVAILABLE"
        safe_json = json.dumps(
            _turn_redact(identity),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        _require(
            not contains_secret(safe_json),
            "TURN_CONTROL_ATTACHMENT_REDACTION_FAILED",
            "A secret-like value remained in an attachment identity.",
        )
        identity = json.loads(safe_json)
        identity["identity_sha256"] = sha256_bytes(canonical_json_bytes(identity))
        if identity["identity_sha256"] in seen:
            continue
        seen.add(identity["identity_sha256"])
        identities.append(identity)
    return sorted(identities, key=lambda row: str(row["identity_sha256"]))


def gap_receipt(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
    error: TurnControlError,
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Emit one secret-free deterministic gap receipt instead of silent NOT_INDEXED."""

    root = Path(store_root).resolve()
    exact_policy = dict(policy or {})
    visible = _turn_redact_text(
        str(
            host_payload.get("prompt")
            or host_payload.get("last_assistant_message")
            or ""
        )
    )
    core = {
        "schema": "evidence-lane.codex-turn-control-gap.v1",
        "state": "TURN_CONTROL_GAP",
        "code": error.code,
        "message": error.message,
        "host_session_id_sha256": sha256_bytes(
            str(host_payload.get("session_id") or "").encode("utf-8")
        ),
        "turn_id_sha256": sha256_bytes(
            str(host_payload.get("turn_id") or "").encode("utf-8")
        ),
        "cwd_sha256": sha256_bytes(str(host_payload.get("cwd") or "").encode("utf-8")),
        "visible_subject_sha256_after_redaction": sha256_bytes(visible.encode("utf-8")),
        "input_kind": _input_kind(host_payload),
        "project_id": exact_policy.get("project_id"),
        "evidence_session_id": exact_policy.get("evidence_session_id"),
        "binding_match": exact_policy.get("binding_match"),
        "fail_closed": bool(
            exact_policy.get("governed_session") and exact_policy.get("strict_required")
        ),
        "source_mutation_authorized": False,
        "raw_secret_stored": False,
        "private_reasoning_stored": False,
        "scrollback_used": False,
        "transcript_used": False,
    }
    core["gap_receipt_sha256"] = sha256_bytes(canonical_json_bytes(core))
    if exact_policy.get("governed_session"):
        path = root / "turn-control-gaps" / f"{core['gap_receipt_sha256']}.json"
        if path.exists():
            stored = _json(path)
            _require(
                stored == core,
                "TURN_CONTROL_GAP_RECEIPT_CONFLICT",
                "A deterministic gap identity already contains different evidence.",
                path=str(path),
            )
        else:
            atomic_write_json(path, core)
        core["gap_receipt_path"] = str(path)
    return core


def _project_prepared_entry(
    root: Path,
    *,
    project_root: Path,
    entry: dict[str, Any],
) -> dict[str, Any]:
    prompt_record = dict(entry["prompt_record"])
    prompt_path = _projection_path(
        root,
        kind="prompt",
        host_session_id=str(entry["host_session_id"]),
        prompt_index=int(entry["prompt_index"]),
        turn_id=str(entry["turn_id"]),
    )
    if prompt_path.exists():
        _require(
            _json(prompt_path) == prompt_record,
            "TURN_CONTROL_PROMPT_PROJECTION_CONFLICT",
            "The prompt projection already contains different visible evidence.",
            path=str(prompt_path),
        )
    else:
        atomic_write_json(prompt_path, prompt_record)
    lineage_path = project_root / "lineage" / f"{entry['evidence_session_id']}.jsonl"
    lineage = ChatLineage(lineage_path)
    input_event_id = (
        "evt_"
        + sha256_bytes(
            (str(entry["prompt_record_sha256"]) + "\0visible-input").encode("utf-8")
        )[:26].lower()
    )
    input_visible_payload = {
        "turn_id": entry["turn_id"],
        "prompt_index": entry["prompt_index"],
        "input_kind": entry["input_kind"],
        "capture_dispatch": entry["capture_dispatch"],
        "visible_input_after_redaction": entry["visible_input_after_redaction"],
        "visible_input_sha256_after_redaction": entry[
            "visible_input_sha256_after_redaction"
        ],
        "attachment_identities": entry["attachment_identities"],
        "prompt_record_sha256": entry["prompt_record_sha256"],
        "entry_slip": entry["entry_slip"],
        **(
            {"host_identity": entry["lineage_host_identity"]}
            if isinstance(entry.get("lineage_host_identity"), dict)
            else {}
        ),
        "private_reasoning_excluded": True,
    }
    input_event = lineage.append(
        event_type={
            "steer": "turn.visible_user_steer",
            "goal": "turn.visible_user_goal",
        }.get(str(entry["input_kind"]), "turn.visible_user_prompt"),
        visible_payload=input_visible_payload,
        occurred_at=entry["prepared_at"],
        session_id=entry["evidence_session_id"],
        task_id=entry["task_id"],
        event_id=input_event_id,
        actor_type="user",
        model=entry.get("lineage_model"),
        submodel=entry.get("lineage_submodel"),
        token_metrics=entry.get("lineage_token_metrics"),
    )
    prepare_event_id = (
        "evt_"
        + sha256_bytes(
            (str(entry["control_record_sha256"]) + "\0prepare").encode("utf-8")
        )[:26].lower()
    )
    prepare_event = lineage.append(
        event_type="turn.control_prepare",
        visible_payload={
            "state": "PREPARED_NOT_COMMITTED",
            "turn_id": entry["turn_id"],
            "input_kind": entry["input_kind"],
            "capture_dispatch": entry["capture_dispatch"],
            "prompt_index": entry["prompt_index"],
            "prompt_record_sha256": entry["prompt_record_sha256"],
            "control_record_sha256": entry["control_record_sha256"],
            "binding_sha256": entry["binding_sha256"],
            "retrieval_receipt_sha256": entry["retrieval_receipt_sha256"],
            "behavior_query_owner": entry["retrieval"]["query_owner"],
            "hook_lookup_performed": entry["retrieval"][
                "hook_lookup_performed"
            ],
            "native_behavior_query_required": entry["retrieval"][
                "native_behavior_query_required"
            ],
            "native_behavior_query_satisfied": entry["retrieval"][
                "native_behavior_query_satisfied"
            ],
            "prior_lineage_head_sha256": entry["prior_lineage_head_sha256"],
            "persistent_plan_row": entry["binding"]["persistent_plan_row"],
            "lane_classification": entry["lane_classification"],
            "mode_classification": entry["mode_classification"],
            "operators": entry["operators"],
            "gates": entry["gates"],
            "bounded_write_scope": entry["bounded_write_scope"],
            "source_change_entry_sha256": (
                (entry.get("source_change_entry") or {}).get(
                    "source_change_snapshot_sha256"
                )
            ),
            **(
                {"host_identity": entry["lineage_host_identity"]}
                if isinstance(entry.get("lineage_host_identity"), dict)
                else {}
            ),
            "scrollback_authority": False,
            "transcript_authority": False,
            "private_reasoning_excluded": True,
        },
        occurred_at=entry["prepared_at"],
        session_id=entry["evidence_session_id"],
        task_id=entry["task_id"],
        event_id=prepare_event_id,
        actor_type="system",
        model=entry.get("lineage_model"),
        submodel=entry.get("lineage_submodel"),
        token_metrics=entry.get("lineage_token_metrics"),
    )
    projection = lineage.projection_status()
    return {
        "prompt_projection_path": str(prompt_path),
        "visible_input_lineage_event_sha256": input_event["event_sha256"],
        "prepare_lineage_event_sha256": prepare_event["event_sha256"],
        "lineage_projection": projection,
    }


def prepare_turn(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
) -> dict[str, Any]:
    """Create exactly one secret-redacted PREPARE before governed reasoning."""

    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    turn_id = str(host_payload.get("turn_id") or "").strip()
    _require(
        bool(host_session_id and turn_id),
        "TURN_CONTROL_HOST_TURN_IDENTITY_REQUIRED",
        "A governed PREPARE requires exact host-session and turn identities.",
    )
    policy = policy_state(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    _require(
        policy.get("governed_session") is True
        and policy.get("strict_required") is True,
        "TURN_CONTROL_POLICY_NOT_ACTIVE",
        "The exact governed session has not activated the sealed Mode plus Plan contract.",
        policy=policy,
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    raw_visible = str(host_payload.get("prompt") or "")
    visible_input = _turn_redact_text(raw_visible)
    _require(
        bool(visible_input.strip()),
        "TURN_CONTROL_VISIBLE_INPUT_REQUIRED",
        "A governed PREPARE requires a non-empty visible prompt, steer, or Goal.",
    )
    _require(
        not contains_secret(visible_input),
        "TURN_CONTROL_SECRET_REDACTION_FAILED",
        "A secret-like value remained in the visible input after redaction.",
    )
    visible_input_sha256 = sha256_bytes(visible_input.encode("utf-8"))
    attachments = _attachment_identities(
        host_payload,
        repository_path=str(bound["project"].get("repository_path") or ""),
    )
    live_source_snapshot = _source_change_snapshot(
        root,
        binding=binding,
        cwd=str(host_payload.get("cwd") or ""),
    )
    lineage_host_identity = _lineage_host_identity(host_payload)
    lineage_telemetry = _response_telemetry(host_payload)
    with _control_lock(project_root):
        try:
            prompt_records = [
                row
                for row in PromptIndex(root)._all_records()
                if row.get("project_id") == binding["project_id"]
                and row.get("evidence_session_id") == binding["evidence_session_id"]
            ]
        except EvidenceLaneError as exc:
            raise TurnControlError(
                "TURN_CONTROL_PROMPT_INDEX_AUTHORITY_INVALID",
                "The existing prompt-index authority could not be verified.",
                upstream_code=exc.code,
                upstream_status=exc.status,
                **exc.details,
            ) from exc
        with _connection(project_root) as connection:
            existing_rows = connection.execute(
                """
                SELECT record_json FROM turn_entry
                WHERE host_session_id=? AND turn_id=?
                ORDER BY prompt_index
                """,
                (host_session_id, turn_id),
            ).fetchall()
            existing_entries = [
                json.loads(row["record_json"]) for row in existing_rows
            ]
            exact_entries = [
                candidate
                for candidate in existing_entries
                if candidate.get("visible_input_sha256_after_redaction")
                == visible_input_sha256
                and candidate.get("attachment_identities") == attachments
            ]
            _require(
                len(exact_entries) <= 1,
                "TURN_CONTROL_EXACT_INPUT_REPLAY_AMBIGUOUS",
                "The same visible input resolves to multiple PREPARE records for one host turn.",
                matching_records=len(exact_entries),
            )
            existing_entry = exact_entries[0] if exact_entries else None
            if existing_entry is not None:
                input_kind = str(existing_entry.get("input_kind") or "user_prompt")
                classification_basis = str(
                    (existing_entry.get("capture_dispatch") or {}).get(
                        "classification_basis"
                    )
                    or "LEGACY_EXACT_INPUT_REPLAY"
                )
                capture_dispatch = _capture_dispatch(
                    host_payload,
                    input_kind=input_kind,
                    classification_basis=classification_basis,
                )
                _require(
                    existing_entry.get("capture_dispatch") == capture_dispatch,
                    "TURN_CONTROL_NATIVE_DISPATCH_RECEIPT_DRIFT",
                    "The replayed PREPARE no longer matches its native dispatch receipt.",
                )
                _require(
                    existing_entry.get("binding_sha256")
                    == binding["binding_sha256"],
                    "TURN_CONTROL_BINDING_DRIFT",
                    "The exact PREPARE exists but its project, pointer, Mode, or Plan binding drifted.",
                )
                entry = existing_entry
                action = "PREPARED_IDEMPOTENT_REUSE"
            else:
                prior_same_turn_prompt = any(
                    row.get("host_session_id") == host_session_id
                    and row.get("turn_id") == turn_id
                    for row in prompt_records
                )
                input_kind, classification_basis = _derive_input_kind(
                    visible_input,
                    prior_same_turn_input=bool(
                        existing_entries or prior_same_turn_prompt
                    ),
                )
                capture_dispatch = _capture_dispatch(
                    host_payload,
                    input_kind=input_kind,
                    classification_basis=classification_basis,
                )
                latest = connection.execute(
                    """
                    SELECT prompt_index, control_record_sha256, prompt_record_sha256
                    FROM turn_entry
                    WHERE project_id=? AND evidence_session_id=?
                    ORDER BY prompt_index DESC LIMIT 1
                    """,
                    (binding["project_id"], binding["evidence_session_id"]),
                ).fetchone()
                latest_prompt = prompt_records[-1] if prompt_records else None
                if latest is not None:
                    strict_prompt_matches = [
                        row
                        for row in prompt_records
                        if row.get("record_sha256")
                        == latest["prompt_record_sha256"]
                        and int(row.get("prompt_index") or 0)
                        == int(latest["prompt_index"])
                    ]
                    _require(
                        len(strict_prompt_matches) == 1,
                        "TURN_CONTROL_PROMPT_SQLITE_PROJECTION_MISMATCH",
                        "Strict turn-control SQLite does not match its prompt-index projection.",
                    )
                prompt_index = (
                    int(latest_prompt.get("prompt_index") or 0) + 1
                    if latest_prompt is not None
                    else 1
                )
                prior_control = latest["control_record_sha256"] if latest else None
                lineage_path = (
                    project_root / "lineage" / f"{binding['evidence_session_id']}.jsonl"
                )
                lineage_events = ChatLineage(lineage_path).events()
                prior_lineage_head = (
                    lineage_events[-1].get("event_sha256") if lineage_events else None
                )
                retrieval = _behavior_query_handoff_receipt(
                    binding=binding,
                    visible_text=visible_input,
                )
                prepared_at = _now()
                prompt_record = {
                    "schema": "evidence-lane.prompt-index.v2",
                    "host_session_id": host_session_id,
                    "turn_id": turn_id,
                    "input_kind": input_kind,
                    "capture_dispatch": capture_dispatch,
                    "prompt_index": prompt_index,
                    "visible_prompt_after_redaction": visible_input,
                    "prompt_sha256_after_redaction": visible_input_sha256,
                    "prompt_chars_after_redaction": len(visible_input),
                    "attachment_identities": attachments,
                    "raw_prompt_stored": False,
                    "redacted_visible_prompt_stored": True,
                    "project_id": binding["project_id"],
                    "evidence_session_id": binding["evidence_session_id"],
                    "entry_pv": binding["accepted_pv"],
                    "pointer_generation": binding["pointer_generation"],
                    "cwd_sha256": sha256_bytes(
                        str(host_payload.get("cwd") or "").encode("utf-8")
                    ),
                    "prior_record_sha256": (
                        latest_prompt.get("record_sha256")
                        if latest_prompt is not None
                        else None
                    ),
                    "recorded_at": prepared_at,
                }
                prompt_record["record_sha256"] = sha256_bytes(
                    canonical_json_bytes(prompt_record)
                )
                operators = [
                    {
                        "mode_id": row["mode_id"],
                        "operator_families": row["operator_families"],
                        "operator_receipt_sha256": row["operator_receipt_sha256"],
                    }
                    for row in binding["env_uop_authorities"]
                ]
                entry = {
                    "schema": "evidence-lane.codex-turn-entry.v2",
                    "prepare_state": "PREPARED_NOT_COMMITTED",
                    "project_id": binding["project_id"],
                    "evidence_session_id": binding["evidence_session_id"],
                    "task_id": binding["task_id"],
                    "plan_task_id": binding["plan_task_id"],
                    "host_session_id": host_session_id,
                    "turn_id": turn_id,
                    "input_kind": input_kind,
                    "capture_dispatch": capture_dispatch,
                    "prompt_index": prompt_index,
                    "prompt_record": prompt_record,
                    "prompt_record_sha256": prompt_record["record_sha256"],
                    "visible_input_after_redaction": visible_input,
                    "visible_input_sha256_after_redaction": visible_input_sha256,
                    "attachment_identities": attachments,
                    "prior_control_record_sha256": prior_control,
                    "prior_lineage_head_sha256": prior_lineage_head,
                    "binding": binding,
                    "binding_sha256": binding["binding_sha256"],
                    "entry_slip": binding["entry_slip"],
                    "retrieval": retrieval,
                    "retrieval_receipt_sha256": retrieval["retrieval_receipt_sha256"],
                    "lane_classification": {
                        "canonical_lanes": binding["canonical_lanes"],
                        "basis": "SEALED_ENV_UOP_MODE_BINDING",
                        "classified_before_reasoning": True,
                    },
                    "mode_classification": {
                        "selected_mode_ids": binding["selected_mode_ids"],
                        "mode_binding_receipt_sha256": binding[
                            "mode_binding_receipt_sha256"
                        ],
                        "classified_before_reasoning": True,
                    },
                    "operators": operators,
                    "gates": binding["gates"],
                    "bounded_write_scope": binding["persistent_plan_row"][
                        "bounded_write_scope"
                    ],
                    "source_change_entry": live_source_snapshot,
                    "lineage_host_identity": lineage_host_identity,
                    "lineage_model": lineage_telemetry["model"],
                    "lineage_submodel": lineage_telemetry["submodel"],
                    "lineage_token_metrics": lineage_telemetry["token_metrics"],
                    "prepared_at": prepared_at,
                    "scrollback_authority": False,
                    "transcript_authority": False,
                    "private_reasoning_stored": False,
                }
                entry["control_record_sha256"] = sha256_bytes(
                    canonical_json_bytes(entry)
                )
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    """
                    INSERT INTO turn_entry(
                        control_record_sha256, project_id, evidence_session_id,
                        host_session_id, turn_id, input_kind, prompt_index,
                        prompt_record_sha256, prior_control_record_sha256,
                        binding_sha256, retrieval_receipt_sha256, record_json,
                        recorded_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        entry["control_record_sha256"],
                        entry["project_id"],
                        entry["evidence_session_id"],
                        entry["host_session_id"],
                        entry["turn_id"],
                        entry["input_kind"],
                        entry["prompt_index"],
                        entry["prompt_record_sha256"],
                        entry["prior_control_record_sha256"],
                        entry["binding_sha256"],
                        entry["retrieval_receipt_sha256"],
                        json.dumps(entry, sort_keys=True, separators=(",", ":")),
                        entry["prepared_at"],
                    ),
                )
                connection.execute(
                    "INSERT INTO turn_entry_fts VALUES(?,?,?,?,?,?)",
                    (
                        entry["control_record_sha256"],
                        entry["project_id"],
                        entry["evidence_session_id"],
                        entry["turn_id"],
                        entry["input_kind"],
                        visible_input,
                    ),
                )
                action = "PREPARED_NOT_COMMITTED"
            research_receipt = _ensure_research_question(
                connection,
                entry=entry,
            )
            connection.commit()
        projection = _project_prepared_entry(
            root,
            project_root=project_root,
            entry=entry,
        )
        with _connection(project_root) as connection:
            integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]
            entry_count = int(
                connection.execute("SELECT COUNT(*) FROM turn_entry").fetchone()[0]
            )
            fts_count = int(
                connection.execute("SELECT COUNT(*) FROM turn_entry_fts").fetchone()[0]
            )
        _require(
            integrity == ["ok"] and entry_count == fts_count,
            "TURN_CONTROL_SQLITE_INVALID",
            "PREPARE SQLite integrity or input FTS parity failed.",
            integrity=integrity,
            entry_count=entry_count,
            fts_count=fts_count,
        )
    entry_source_snapshot = dict(
        entry.get("source_change_entry") or live_source_snapshot
    )
    persistent_change_display = _persistent_change_display(
        binding=entry["binding"],
        source_snapshot=live_source_snapshot,
        turn_state="PREPARED_NOT_COMMITTED",
        prompt_index=int(entry["prompt_index"]),
        uncommitted_count=1,
        changed_since_prepare=(
            entry_source_snapshot["worktree_sha256"]
            != live_source_snapshot["worktree_sha256"]
        ),
    )
    return {
        "state": action,
        "schema": "evidence-lane.codex-turn-control-receipt.v2",
        "prepare_state": "PREPARED_NOT_COMMITTED",
        "project_id": entry["project_id"],
        "evidence_session_id": entry["evidence_session_id"],
        "turn_id": entry["turn_id"],
        "input_kind": entry["input_kind"],
        "capture_dispatch": entry["capture_dispatch"],
        "pre_reasoning_host_dispatch_proven": entry["capture_dispatch"][
            "pre_reasoning_dispatch_proven"
        ],
        "prompt_index": entry["prompt_index"],
        "prompt_record_sha256": entry["prompt_record_sha256"],
        "record_sha256": entry["prompt_record_sha256"],
        "control_record_sha256": entry["control_record_sha256"],
        "binding_sha256": entry["binding_sha256"],
        "retrieval_receipt_sha256": entry["retrieval_receipt_sha256"],
        "retrieval_outcome": entry["retrieval"]["outcome"],
        "retrieval_lineage_result_count": entry["retrieval"][
            "lineage_result_count"
        ],
        "retrieval_accepted_code_result_count": entry["retrieval"][
            "accepted_code_result_count"
        ],
        "retrieval_candidate_overlay_used": entry["retrieval"][
            "candidate_overlay_used"
        ],
        "behavior_query_owner": entry["retrieval"]["query_owner"],
        "hook_lookup_performed": entry["retrieval"]["hook_lookup_performed"],
        "native_behavior_query_required": entry["retrieval"][
            "native_behavior_query_required"
        ],
        "native_behavior_query_satisfied": entry["retrieval"][
            "native_behavior_query_satisfied"
        ],
        "required_native_read_sequence": entry["retrieval"][
            "required_native_read_sequence"
        ],
        "host_plan_refresh_owner": entry["retrieval"][
            "host_plan_refresh_owner"
        ],
        "host_plan_tool": entry["retrieval"]["host_plan_tool"],
        "persistent_plan_row": entry["binding"]["persistent_plan_row"],
        "accepted_pv": entry["binding"]["accepted_pv"],
        "entry_pv": entry["binding"]["accepted_pv"],
        "pointer_generation": entry["binding"]["pointer_generation"],
        "attachment_identity_count": len(entry["attachment_identities"]),
        "research_question": research_receipt,
        "persistent_change_display": persistent_change_display,
        "scrollback_authority": False,
        "transcript_authority": False,
        "private_reasoning_stored": False,
        **projection,
    }


def _turn_entry(
    store_root: str | Path,
    *,
    host_session_id: str,
    turn_id: str,
    cwd: str,
) -> tuple[dict[str, Any], dict[str, Any], Path]:
    root = Path(store_root).resolve()
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=cwd,
    )
    current_binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    with _connection(project_root) as connection:
        rows = connection.execute(
            """
            SELECT record_json FROM turn_entry
            WHERE host_session_id=? AND turn_id=?
            ORDER BY prompt_index DESC
            """,
            (host_session_id, turn_id),
        ).fetchall()
    _require(
        bool(rows),
        "TURN_CONTROL_PREFLIGHT_REQUIRED",
        "No sealed prompt, steer, or Goal preflight exists for this Codex turn.",
        turn_id=turn_id,
    )
    entry = json.loads(rows[0]["record_json"])
    claimed = str(entry.pop("control_record_sha256"))
    actual = sha256_bytes(canonical_json_bytes(entry))
    entry["control_record_sha256"] = claimed
    _require(
        claimed == actual,
        "TURN_CONTROL_RECORD_MISMATCH",
        "The Codex turn-control receipt failed its SHA-256 check.",
    )
    _require(
        entry.get("binding_sha256") == current_binding.get("binding_sha256"),
        "TURN_CONTROL_BINDING_DRIFT",
        "Project, pointer, Entry/Prepare, mode/operator, task, or Plan binding changed after preflight.",
    )
    return entry, current_binding, project_root


def _bounded_visible(value: Any) -> dict[str, Any]:
    safe = _turn_redact(value)
    text = json.dumps(safe, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    _require(
        not contains_secret(text),
        "TURN_CONTROL_TOOL_SECRET_REDACTION_FAILED",
        "A secret-like value remained in a visible operational event.",
    )
    encoded = text[:_MAX_VISIBLE_EVENT_CHARS]
    return {
        "visible_json_after_redaction": encoded,
        "visible_json_sha256_after_redaction": sha256_bytes(text.encode("utf-8")),
        "visible_json_chars_after_redaction": len(text),
        "truncated": len(text) > _MAX_VISIBLE_EVENT_CHARS,
    }


def record_tool_event(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
    phase: str,
) -> dict[str, Any]:
    _require(
        phase in {"before", "after"},
        "TURN_CONTROL_TOOL_PHASE_INVALID",
        "Tool activity phase must be before or after.",
    )
    host_session_id = str(host_payload.get("session_id") or "").strip()
    turn_id = str(host_payload.get("turn_id") or "").strip()
    tool_name = str(host_payload.get("tool_name") or "").strip()
    tool_use_id = str(host_payload.get("tool_use_id") or "").strip()
    _require(
        bool(host_session_id and turn_id and tool_name and tool_use_id),
        "TURN_CONTROL_TOOL_IDENTITY_REQUIRED",
        "A tool event requires host session, turn, tool name, and tool-use identities.",
    )
    entry, binding, project_root = _turn_entry(
        store_root,
        host_session_id=host_session_id,
        turn_id=turn_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    visible = _bounded_visible(
        host_payload.get("tool_input")
        if phase == "before"
        else host_payload.get("tool_response")
    )
    telemetry = _response_telemetry(host_payload)
    event_payload = {
        "turn_id": turn_id,
        "tool_use_id": tool_use_id,
        "phase": phase,
        "tool_name": tool_name,
        "control_record_sha256": entry["control_record_sha256"],
        "binding_sha256": binding["binding_sha256"],
        "host_identity": _lineage_host_identity(host_payload),
        **visible,
        "private_reasoning_excluded": True,
    }
    tool_event_sha256 = sha256_bytes(canonical_json_bytes(event_payload))
    event_id = (
        "evt_"
        + sha256_bytes(
            (tool_use_id + "\0" + phase + "\0" + tool_event_sha256).encode("utf-8")
        )[:26].lower()
    )
    with _connection(project_root) as connection:
        existing = connection.execute(
            "SELECT event_json FROM turn_tool_event WHERE tool_use_id=? AND phase=?",
            (tool_use_id, phase),
        ).fetchone()
    if existing:
        stored = json.loads(existing["event_json"])
        stored_payload = stored.get("event_payload")
        _require(
            isinstance(stored_payload, dict)
            and sha256_bytes(canonical_json_bytes(stored_payload))
            == stored.get("tool_event_sha256"),
            "TURN_CONTROL_TOOL_EVENT_INTEGRITY_FAILED",
            "The existing tool event failed its payload SHA-256 verification.",
        )
        comparable_payload = event_payload
        if "host_identity" not in stored_payload:
            # v2.0 tool events predate the additive privacy-safe host-identity
            # projection. Replaying that exact visible event must reuse the
            # immutable record instead of appending a second lineage event.
            comparable_payload = {
                key: value
                for key, value in event_payload.items()
                if key != "host_identity"
            }
        _require(
            stored_payload == comparable_payload
            and stored.get("control_record_sha256")
            == entry["control_record_sha256"]
            and stored.get("tool_use_id") == tool_use_id
            and stored.get("phase") == phase
            and stored.get("tool_name") == tool_name,
            "TURN_CONTROL_TOOL_EVENT_CONFLICT",
            "A tool-use identity already binds different visible activity.",
        )
        return {
            "state": "RECORDED_IDEMPOTENT_REUSE",
            "tool_event_sha256": stored["tool_event_sha256"],
            "lineage_event_sha256": stored["lineage_event_sha256"],
            "control_record_sha256": entry["control_record_sha256"],
            "phase": phase,
        }
    lineage_path = project_root / "lineage" / f"{binding['evidence_session_id']}.jsonl"
    lineage_event = ChatLineage(lineage_path).append(
        event_type=f"turn.tool.{phase}",
        visible_payload=event_payload,
        occurred_at=_now(),
        session_id=binding["evidence_session_id"],
        task_id=binding["task_id"],
        event_id=event_id,
        actor_type="tool",
        model=telemetry["model"],
        submodel=telemetry["submodel"],
        token_metrics=telemetry["token_metrics"],
    )
    with _connection(project_root) as connection:
        row = {
            "tool_event_sha256": tool_event_sha256,
            "control_record_sha256": entry["control_record_sha256"],
            "tool_use_id": tool_use_id,
            "phase": phase,
            "tool_name": tool_name,
            "lineage_event_sha256": lineage_event["event_sha256"],
            "event_payload": event_payload,
            "recorded_at": _now(),
        }
        connection.execute(
            "INSERT INTO turn_tool_event VALUES(?,?,?,?,?,?,?,?)",
            (
                tool_event_sha256,
                entry["control_record_sha256"],
                tool_use_id,
                phase,
                tool_name,
                lineage_event["event_sha256"],
                json.dumps(row, sort_keys=True, separators=(",", ":")),
                row["recorded_at"],
            ),
        )
        connection.commit()
    return {
        "state": "RECORDED",
        "tool_event_sha256": tool_event_sha256,
        "lineage_event_sha256": lineage_event["event_sha256"],
        "control_record_sha256": entry["control_record_sha256"],
        "phase": phase,
    }


_LIFECYCLE_BOUNDARY_PHASES = {
    "PreCompact": "COMPACTION_SEAL",
    "PostCompact": "COMPACTION_REHYDRATION",
    "SessionEnd": "BEST_EFFORT_SESSION_BOUNDARY_FLUSH",
}


def record_lifecycle_boundary_event(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
    event_name: str,
) -> dict[str, Any]:
    """Seal one privacy-safe host lifecycle boundary without owning behavior.

    These receipts transport lifecycle state only. They never run PV queries,
    classify a task, mutate Plan Lane, refresh a candidate, or move a pointer;
    those behavior decisions remain owned by the installed Evidence Lane skill.
    """

    phase = _LIFECYCLE_BOUNDARY_PHASES.get(event_name)
    _require(
        bool(phase),
        "TURN_CONTROL_LIFECYCLE_EVENT_UNSUPPORTED",
        "The lifecycle boundary event is not part of the approved hook matrix.",
        event_name=event_name,
    )
    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    _require(
        bool(host_session_id),
        "TURN_CONTROL_HOST_SESSION_REQUIRED",
        "A lifecycle boundary requires the exact Codex host-session identity.",
    )
    candidate = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
        transcript_path=str(
            host_payload.get("transcript_path")
            or host_payload.get("agent_transcript_path")
            or ""
        ),
    )
    session = candidate["session"]
    metadata = dict(session.get("metadata") or {})
    project_id = str(session["project_id"])
    evidence_session_id = str(session["session_id"])
    project_root = root / "projects" / project_id
    occurrence_source = str(
        host_payload.get("hook_event_id")
        or host_payload.get("event_id")
        or host_payload.get("turn_id")
        or host_payload.get("tool_use_id")
        or host_payload.get("source")
        or event_name
    ).strip()
    occurrence_sha256 = sha256_bytes(occurrence_source.encode("utf-8"))
    receipt_id = (
        "lifecycle_"
        + sha256_bytes(
            (
                event_name
                + "\0"
                + evidence_session_id
                + "\0"
                + occurrence_sha256
                + "\0"
                + _host_binding_epoch(session)
            ).encode("utf-8")
        )[:26].lower()
    )
    receipt_path = (
        project_root / "lineage" / "lifecycle_hooks" / f"{receipt_id}.json"
    )
    if receipt_path.is_file():
        receipt = _json(receipt_path)
        claimed = str(receipt.get("receipt_sha256") or "")
        actual = sha256_bytes(
            canonical_json_bytes(
                {key: value for key, value in receipt.items() if key != "receipt_sha256"}
            )
        )
        _require(
            claimed == actual
            and receipt.get("event_name") == event_name
            and receipt.get("project_id") == project_id
            and receipt.get("evidence_session_id") == evidence_session_id
            and receipt.get("occurrence_sha256") == occurrence_sha256,
            "TURN_CONTROL_LIFECYCLE_RECEIPT_CONFLICT",
            "The existing lifecycle boundary receipt failed identity or SHA-256 verification.",
        )
        return {"state": "SEALED_IDEMPOTENT_REUSE", "receipt": receipt}

    core: dict[str, Any] = {
        "schema": "evidence-lane.codex-lifecycle-boundary.v1",
        "receipt_id": receipt_id,
        "event_name": event_name,
        "phase": phase,
        "project_id": project_id,
        "evidence_session_id": evidence_session_id,
        "active_task_id": metadata.get("active_backlog_task_id"),
        "binding_epoch_sha256": _host_binding_epoch(session),
        "occurrence_sha256": occurrence_sha256,
        "host_identity": _lineage_host_identity(host_payload),
        "hook_owns_lifecycle_transport_only": True,
        "skill_owns_behavior_and_native_reads": True,
        "plan_or_delta_mutated": False,
        "candidate_created_or_refreshed": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "raw_prompt_stored": False,
        "raw_tool_payload_stored": False,
        "private_reasoning_stored": False,
        "sealed_at": _now(),
    }
    lineage = ChatLineage(
        project_root / "lineage" / f"{evidence_session_id}.jsonl"
    ).append(
        event_type=f"turn.lifecycle.{event_name.lower()}",
        visible_payload=core,
        occurred_at=core["sealed_at"],
        session_id=evidence_session_id,
        task_id=str(metadata.get("active_backlog_task_id") or "") or None,
        event_id="evt_" + receipt_id,
        actor_type="host",
        model=_response_telemetry(host_payload)["model"],
        submodel=_response_telemetry(host_payload)["submodel"],
        token_metrics={"availability": "UNAVAILABLE"},
    )
    receipt = {
        **core,
        "lineage_event_sha256": lineage["event_sha256"],
    }
    receipt["receipt_sha256"] = sha256_bytes(canonical_json_bytes(receipt))
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(receipt_path, receipt)
    return {"state": "SEALED", "receipt": receipt}


def _response_telemetry(host_payload: dict[str, Any]) -> dict[str, Any]:
    raw_usage = host_payload.get("usage") or host_payload.get("token_usage") or {}
    metrics = (
        {
            str(key): value
            for key, value in raw_usage.items()
            if str(key) in _TOKEN_METRIC_KEYS
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
            and value >= 0
        }
        if isinstance(raw_usage, dict)
        else {}
    )
    return {
        "model": _turn_redact_text(
            str(host_payload.get("model") or host_payload.get("model_name") or "")
        )
        or None,
        "submodel": _turn_redact_text(
            str(host_payload.get("submodel") or host_payload.get("model_slug") or "")
        )
        or None,
        "token_metrics": (
            {"availability": "AVAILABLE", **metrics}
            if metrics
            else {"availability": "UNAVAILABLE"}
        ),
    }


def _operational_links(host_payload: dict[str, Any]) -> dict[str, Any]:
    exact: dict[str, Any] = {}
    for key in (
        "tool_events",
        "tools",
        "tool_outputs",
        "commands",
        "files",
        "tests",
        "builds",
        "outputs",
        "links",
    ):
        if key in host_payload:
            exact[key] = _turn_redact(host_payload[key])
    serialized = json.dumps(
        exact, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    _require(
        not contains_secret(serialized),
        "TURN_CONTROL_OPERATIONAL_LINK_REDACTION_FAILED",
        "A secret-like value remained in tool, command, file, test, build, or output links.",
    )
    return {
        "availability": "AVAILABLE" if exact else "UNAVAILABLE",
        "items_after_redaction": exact,
        "items_sha256_after_redaction": sha256_bytes(serialized.encode("utf-8")),
    }


def _response_links(visible_response: str) -> list[str]:
    values: list[str] = []
    for match in _LINK_RE.finditer(visible_response):
        value = _turn_redact_text((match.group(1) or match.group(0)).strip())
        if value and value not in values:
            values.append(value)
    return values[:100]


def commit_turn(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
) -> dict[str, Any]:
    """COMMIT one exact visible response against the latest PREPARE for this turn."""

    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    turn_id = str(host_payload.get("turn_id") or "").strip()
    _require(
        bool(host_session_id and turn_id),
        "TURN_CONTROL_HOST_TURN_IDENTITY_REQUIRED",
        "A governed COMMIT requires exact host-session and turn identities.",
    )
    visible_response = _turn_redact_text(
        str(host_payload.get("last_assistant_message") or "")
    )
    _require(
        bool(visible_response.strip()),
        "TURN_CONTROL_VISIBLE_RESPONSE_REQUIRED",
        "No visible assistant response is available; the turn remains PREPARED_NOT_COMMITTED.",
    )
    _require(
        not contains_secret(visible_response),
        "TURN_CONTROL_RESPONSE_REDACTION_FAILED",
        "A secret-like value remained in the visible response after redaction.",
    )
    policy = policy_state(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    _require(
        policy.get("governed_session") is True
        and policy.get("strict_required") is True,
        "TURN_CONTROL_POLICY_NOT_ACTIVE",
        "The exact governed session has not activated the sealed Mode plus Plan contract.",
        policy=policy,
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    telemetry = _response_telemetry(host_payload)
    operational = _operational_links(host_payload)
    goal_usage = _goal_usage_observation(host_payload)
    live_source_snapshot = _source_change_snapshot(
        root,
        binding=binding,
        cwd=str(host_payload.get("cwd") or ""),
    )
    response_sha256 = sha256_bytes(visible_response.encode("utf-8"))
    with _control_lock(project_root):
        with _connection(project_root) as connection:
            rows = connection.execute(
                """
                SELECT e.record_json AS entry_json, c.commit_json AS commit_json
                FROM turn_entry e
                LEFT JOIN turn_commit c
                  ON c.control_record_sha256=e.control_record_sha256
                WHERE e.host_session_id=? AND e.turn_id=?
                ORDER BY e.prompt_index DESC
                """,
                (host_session_id, turn_id),
            ).fetchall()
        _require(
            bool(rows),
            "TURN_CONTROL_PREFLIGHT_REQUIRED",
            "No sealed PREPARE exists for this exact Codex turn.",
            turn_id=turn_id,
        )
        selected = rows[0]
        entry = json.loads(selected["entry_json"])
        existing_commit = (
            json.loads(selected["commit_json"])
            if selected["commit_json"] is not None
            else None
        )
        claimed_entry_sha = str(entry.get("control_record_sha256") or "")
        entry_without_sha = {
            key: value for key, value in entry.items() if key != "control_record_sha256"
        }
        _require(
            claimed_entry_sha == sha256_bytes(canonical_json_bytes(entry_without_sha)),
            "TURN_CONTROL_RECORD_MISMATCH",
            "The PREPARE receipt failed its SHA-256 verification.",
        )
        _require(
            entry.get("binding_sha256") == binding.get("binding_sha256"),
            "TURN_CONTROL_BINDING_DRIFT",
            "Project, pointer, Entry, Mode, operator, task, or Plan binding changed after PREPARE.",
        )
        prepare_projection = _project_prepared_entry(
            root,
            project_root=project_root,
            entry=entry,
        )
        response_path = _projection_path(
            root,
            kind="response",
            host_session_id=host_session_id,
            prompt_index=int(entry["prompt_index"]),
            turn_id=turn_id,
        )
        if response_path.exists():
            response_record = _json(response_path)
            _require(
                response_record.get("response_sha256_after_redaction")
                == response_sha256
                and response_record.get("control_record_sha256")
                == entry["control_record_sha256"],
                "TURN_CONTROL_RESPONSE_PROJECTION_CONFLICT",
                "This PREPARE already binds a different visible response.",
                path=str(response_path),
            )
            claimed_response_record_sha256 = str(
                response_record.get("record_sha256") or ""
            )
            _require(
                claimed_response_record_sha256
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            key: value
                            for key, value in response_record.items()
                            if key != "record_sha256"
                        }
                    )
                ),
                "TURN_CONTROL_RESPONSE_RECORD_MISMATCH",
                "The response projection failed its SHA-256 verification.",
                path=str(response_path),
            )
            operational = dict(
                response_record.get("operational_links")
                or {
                    "availability": "UNAVAILABLE",
                    "items_after_redaction": {},
                    "items_sha256_after_redaction": sha256_bytes(b"{}"),
                }
            )
            telemetry = {
                "model": response_record.get("model"),
                "submodel": response_record.get("submodel"),
                "token_metrics": response_record.get("token_metrics")
                or {"availability": "UNAVAILABLE"},
            }
            stored_goal_usage = response_record.get("goal_usage")
            goal_usage = (
                dict(stored_goal_usage)
                if isinstance(stored_goal_usage, dict)
                else _goal_usage_observation({})
            )
            source_change = dict(
                response_record.get("source_change")
                or _source_change_receipt(
                    entry_snapshot=dict(
                        entry.get("source_change_entry") or live_source_snapshot
                    ),
                    exit_snapshot=live_source_snapshot,
                )
            )
            persistent_change_display = dict(
                response_record.get("persistent_change_display")
                or _persistent_change_display(
                    binding=binding,
                    source_snapshot=source_change["exit_source_change_snapshot"],
                    turn_state="COMMITTED",
                    prompt_index=int(entry["prompt_index"]),
                    uncommitted_count=0,
                    changed_since_prepare=bool(source_change["changed_since_prepare"]),
                )
            )
            claimed_goal_observation = str(goal_usage.get("observation_sha256") or "")
            _require(
                claimed_goal_observation
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            key: value
                            for key, value in goal_usage.items()
                            if key != "observation_sha256"
                        }
                    )
                ),
                "TURN_CONTROL_GOAL_USAGE_OBSERVATION_MISMATCH",
                "The stored Goal usage observation failed SHA-256 verification.",
            )
        else:
            source_change = _source_change_receipt(
                entry_snapshot=dict(
                    entry.get("source_change_entry") or live_source_snapshot
                ),
                exit_snapshot=live_source_snapshot,
            )
            persistent_change_display = _persistent_change_display(
                binding=binding,
                source_snapshot=live_source_snapshot,
                turn_state="COMMITTED",
                prompt_index=int(entry["prompt_index"]),
                uncommitted_count=0,
                changed_since_prepare=source_change["changed_since_prepare"],
            )
            response_record = {
                "schema": "evidence-lane.response-index.v2",
                "turn_id": turn_id,
                "prompt_index": entry["prompt_index"],
                "prompt_record_sha256": entry["prompt_record_sha256"],
                "control_record_sha256": entry["control_record_sha256"],
                "visible_assistant_response_after_redaction": visible_response,
                "response_sha256_after_redaction": response_sha256,
                "response_chars_after_redaction": len(visible_response),
                "output_links": _response_links(visible_response),
                "operational_links": operational,
                "goal_usage": goal_usage,
                "source_change": source_change,
                "persistent_change_display": persistent_change_display,
                "host_identity": _lineage_host_identity(host_payload),
                **telemetry,
                "raw_response_stored": False,
                "redacted_visible_response_stored": True,
                "private_reasoning_stored": False,
                "project_id": binding["project_id"],
                "evidence_session_id": binding["evidence_session_id"],
                "entry_pv": binding["accepted_pv"],
                "pointer_generation": binding["pointer_generation"],
                "recorded_at": _now(),
                "hook_continuation_requested": False,
                "composer_mutated": False,
            }
            response_record["record_sha256"] = sha256_bytes(
                canonical_json_bytes(response_record)
            )
            atomic_write_json(response_path, response_record)
        response_record_sha256 = _sha(
            response_record.get("record_sha256"), field="response.record_sha256"
        )
        lineage_path = (
            project_root / "lineage" / f"{binding['evidence_session_id']}.jsonl"
        )
        lineage = ChatLineage(lineage_path)
        lineage_before_response = lineage.events()
        previous_head = (
            lineage_before_response[-1].get("event_sha256")
            if lineage_before_response
            else None
        )
        response_event_id = (
            "evt_"
            + sha256_bytes(
                (response_record_sha256 + "\0visible-response").encode("utf-8")
            )[:26].lower()
        )
        response_event = lineage.append(
            event_type="turn.visible_assistant_response",
            visible_payload={
                "turn_id": turn_id,
                "prompt_index": entry["prompt_index"],
                "prompt_record_sha256": entry["prompt_record_sha256"],
                "control_record_sha256": entry["control_record_sha256"],
                "response_record_sha256": response_record_sha256,
                "visible_assistant_response_after_redaction": visible_response,
                "response_sha256_after_redaction": response_sha256,
                "output_links": response_record["output_links"],
                "operational_links": operational,
                "source_change_receipt_sha256": source_change[
                    "source_change_receipt_sha256"
                ],
                "persistent_change_display_sha256": persistent_change_display[
                    "display_sha256"
                ],
                **(
                    {"host_identity": response_record["host_identity"]}
                    if isinstance(response_record.get("host_identity"), dict)
                    else {}
                ),
                "private_reasoning_excluded": True,
                "hook_continuation_requested": False,
                "composer_mutated": False,
            },
            occurred_at=response_record["recorded_at"],
            session_id=binding["evidence_session_id"],
            task_id=binding["task_id"],
            event_id=response_event_id,
            actor_type="assistant",
            model=telemetry["model"],
            submodel=telemetry["submodel"],
            token_metrics=telemetry["token_metrics"],
        )
        previous_head = response_event.get("previous_event_sha256")
        continuity_state = {
            "control_record_sha256": entry["control_record_sha256"],
            "response_record_sha256": response_record_sha256,
            "binding_sha256": binding["binding_sha256"],
            "prepare_lineage_event_sha256": prepare_projection[
                "prepare_lineage_event_sha256"
            ],
            "response_lineage_event_sha256": response_event["event_sha256"],
            "prior_lineage_head_sha256": previous_head,
            "accepted_pv": binding["accepted_pv"],
            "pointer_generation": binding["pointer_generation"],
            "goal_usage_observation_sha256": goal_usage["observation_sha256"],
            "source_change_receipt_sha256": source_change[
                "source_change_receipt_sha256"
            ],
            "persistent_change_display_sha256": persistent_change_display[
                "display_sha256"
            ],
        }
        state_sha256 = sha256_bytes(canonical_json_bytes(continuity_state))
        if existing_commit is not None:
            claimed_commit_sha256 = str(existing_commit.get("commit_sha256") or "")
            _require(
                claimed_commit_sha256
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            key: value
                            for key, value in existing_commit.items()
                            if key != "commit_sha256"
                        }
                    )
                ),
                "TURN_CONTROL_RESPONSE_COMMIT_MISMATCH",
                "The existing ordinary-turn COMMIT failed its SHA-256 verification.",
            )
            commit = existing_commit
            state_sha256 = str(commit["state_sha256"])
        else:
            commit = {
                "schema": "evidence-lane.codex-turn-commit.v3",
                "state": "COMMITTED",
                "control_record_sha256": entry["control_record_sha256"],
                "response_record_sha256": response_record_sha256,
                "turn_id": turn_id,
                "prompt_index": entry["prompt_index"],
                "project_id": binding["project_id"],
                "evidence_session_id": binding["evidence_session_id"],
                "accepted_pv": binding["accepted_pv"],
                "pointer_generation": binding["pointer_generation"],
                "entry_slip": entry["entry_slip"],
                **(
                    {"host_identity": response_record["host_identity"]}
                    if isinstance(response_record.get("host_identity"), dict)
                    else {}
                ),
                "continuity_commit_receipt": {
                    **continuity_state,
                    "state_sha256": state_sha256,
                    "operational_links_sha256": operational[
                        "items_sha256_after_redaction"
                    ],
                    "token_metrics": telemetry["token_metrics"],
                    "goal_usage": goal_usage,
                    "source_change": source_change,
                    "persistent_change_display": persistent_change_display,
                    "receipt_role": "ORDINARY_TURN_COMMIT_NOT_LIFECYCLE_EXIT",
                },
                "lifecycle_exit_slip_emitted": False,
                "lifecycle_exit_reason": None,
                "state_sha256": state_sha256,
                "private_reasoning_stored": False,
                "committed_at": response_record["recorded_at"],
            }
            commit["commit_sha256"] = sha256_bytes(canonical_json_bytes(commit))
        commit_event_id = (
            "evt_"
            + sha256_bytes((commit["commit_sha256"] + "\0commit").encode("utf-8"))[
                :26
            ].lower()
        )
        commit_event = lineage.append(
            event_type="turn.control_commit",
            visible_payload=commit,
            occurred_at=commit["committed_at"],
            session_id=binding["evidence_session_id"],
            task_id=binding["task_id"],
            event_id=commit_event_id,
            actor_type="system",
            model=telemetry["model"],
            submodel=telemetry["submodel"],
            token_metrics=telemetry["token_metrics"],
        )
        with _connection(project_root) as connection:
            existing = connection.execute(
                "SELECT commit_json FROM turn_commit WHERE control_record_sha256=?",
                (entry["control_record_sha256"],),
            ).fetchone()
            if existing:
                stored = json.loads(existing["commit_json"])
                _require(
                    stored == commit,
                    "TURN_CONTROL_RESPONSE_COMMIT_CONFLICT",
                    "The PREPARE already binds a different COMMIT.",
                )
                action = "COMMITTED_IDEMPOTENT_REUSE"
            else:
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    "INSERT INTO turn_commit VALUES(?,?,?,?,?,?)",
                    (
                        commit["commit_sha256"],
                        entry["control_record_sha256"],
                        response_record_sha256,
                        commit_event["event_sha256"],
                        json.dumps(commit, sort_keys=True, separators=(",", ":")),
                        commit["committed_at"],
                    ),
                )
                connection.execute(
                    "INSERT INTO turn_commit_fts VALUES(?,?,?,?,?,?)",
                    (
                        commit["commit_sha256"],
                        entry["control_record_sha256"],
                        turn_id,
                        binding["project_id"],
                        visible_response,
                        json.dumps(
                            operational["items_after_redaction"],
                            ensure_ascii=False,
                            sort_keys=True,
                            separators=(",", ":"),
                        ),
                    ),
                )
                action = "COMMITTED"
            goal_usage_receipt = _ensure_goal_usage(
                connection,
                entry=entry,
                observation=goal_usage,
                recorded_at=response_record["recorded_at"],
            )
            connection.commit()
            integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]
            commit_count = int(
                connection.execute("SELECT COUNT(*) FROM turn_commit").fetchone()[0]
            )
            fts_count = int(
                connection.execute("SELECT COUNT(*) FROM turn_commit_fts").fetchone()[0]
            )
        _require(
            integrity == ["ok"] and commit_count == fts_count,
            "TURN_CONTROL_SQLITE_INVALID",
            "COMMIT SQLite integrity or response FTS parity failed.",
            integrity=integrity,
            commit_count=commit_count,
            fts_count=fts_count,
        )
        lineage_projection = lineage.projection_status()
    return {
        "state": action,
        "schema": "evidence-lane.codex-turn-control-commit-receipt.v3",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "turn_id": turn_id,
        "prompt_index": entry["prompt_index"],
        "control_record_sha256": entry["control_record_sha256"],
        "response_record_sha256": response_record_sha256,
        "commit_sha256": commit["commit_sha256"],
        "state_sha256": state_sha256,
        "response_lineage_event_sha256": response_event["event_sha256"],
        "commit_lineage_event_sha256": commit_event["event_sha256"],
        "lineage_projection": lineage_projection,
        "response_projection_path": str(response_path),
        "operational_links": operational,
        "token_metrics": telemetry["token_metrics"],
        "goal_usage": goal_usage_receipt,
        "source_change": source_change,
        "persistent_change_display": persistent_change_display,
        "ordinary_turn_commit_receipt": (
            commit.get("continuity_commit_receipt")
            or commit.get("exit_slip")
        ),
        "lifecycle_exit_slip_emitted": bool(
            commit.get("lifecycle_exit_slip_emitted", False)
        ),
        "historical_exit_slip_alias_reused": (
            "exit_slip" in commit and "continuity_commit_receipt" not in commit
        ),
        "private_reasoning_stored": False,
    }


def seal_lifecycle_exit_slip(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
    reason: str,
    visible_reason: str,
) -> dict[str, Any]:
    """Seal one genuine lifecycle exit boundary without advancing the Plan row."""

    exact_reason = reason.strip().upper()
    _require(
        exact_reason in _LIFECYCLE_EXIT_REASONS,
        "TURN_CONTROL_LIFECYCLE_EXIT_REASON_INVALID",
        "Ordinary turn completion is not a lifecycle Exit Slip boundary.",
        allowed_reasons=sorted(_LIFECYCLE_EXIT_REASONS),
    )
    safe_visible_reason = _turn_redact_text(visible_reason.strip())
    _require(
        bool(safe_visible_reason) and not contains_secret(safe_visible_reason),
        "TURN_CONTROL_LIFECYCLE_EXIT_VISIBLE_REASON_REQUIRED",
        "A lifecycle Exit Slip requires one secret-redacted visible reason.",
    )
    if exact_reason == "STATELESS_EPHEMERAL_END":
        runtime_context_value = host_payload.get("runtime_context")
        runtime_context: dict[str, Any] = (
            cast(dict[str, Any], runtime_context_value)
            if isinstance(runtime_context_value, dict)
            else {}
        )
        _require(
            host_payload.get("ephemeral") is True
            or runtime_context.get("ephemeral") is True,
            "TURN_CONTROL_STATELESS_EPHEMERAL_PROOF_REQUIRED",
            "A stateless invocation Exit Slip requires explicit ephemeral-host proof.",
        )
    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    _require(
        bool(host_session_id),
        "TURN_CONTROL_HOST_TURN_IDENTITY_REQUIRED",
        "A lifecycle Exit Slip requires the exact governed host-session identity.",
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    turn_id = str(host_payload.get("turn_id") or "").strip() or None
    latest_control_record_sha256: str | None = None
    latest_turn_state = "NO_TURN_RECEIPT"
    with _connection(project_root) as connection:
        latest = connection.execute(
            """
            SELECT e.control_record_sha256, c.commit_sha256
            FROM turn_entry e
            LEFT JOIN turn_commit c
              ON c.control_record_sha256=e.control_record_sha256
            WHERE e.host_session_id=?
            ORDER BY e.prompt_index DESC LIMIT 1
            """,
            (host_session_id,),
        ).fetchone()
    if latest is not None:
        latest_control_record_sha256 = str(latest["control_record_sha256"])
        latest_turn_state = (
            "COMMITTED" if latest["commit_sha256"] else "PREPARED_NOT_COMMITTED"
        )
    active_row = binding["persistent_plan_row"]
    identity = {
        "schema": "evidence-lane.codex-lifecycle-exit-identity.v1",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "active_row": active_row["position"],
        "host_session_id_sha256": sha256_bytes(host_session_id.encode("utf-8")),
        "turn_id": turn_id,
        "reason": exact_reason,
        "visible_reason_sha256": sha256_bytes(safe_visible_reason.encode("utf-8")),
        "latest_control_record_sha256": latest_control_record_sha256,
    }
    exit_identity_sha256 = sha256_bytes(canonical_json_bytes(identity))
    exit_path = (
        project_root
        / "lineage"
        / "lifecycle-exit-slips"
        / f"{exit_identity_sha256}.json"
    )
    if exit_path.exists():
        receipt = _json(exit_path)
        claimed = str(receipt.get("exit_slip_sha256") or "")
        _require(
            claimed
            == sha256_bytes(
                canonical_json_bytes(
                    {
                        key: value
                        for key, value in receipt.items()
                        if key != "exit_slip_sha256"
                    }
                )
            )
            and receipt.get("exit_identity_sha256") == exit_identity_sha256,
            "TURN_CONTROL_LIFECYCLE_EXIT_RECEIPT_MISMATCH",
            "The existing lifecycle Exit Slip failed identity or SHA-256 verification.",
        )
        state = "SEALED_IDEMPOTENT_REUSE"
    else:
        receipt = {
            **identity,
            "schema": "evidence-lane.codex-lifecycle-exit-slip.v1",
            "exit_identity_sha256": exit_identity_sha256,
            "visible_reason_after_redaction": safe_visible_reason,
            "host_identity": _lineage_host_identity(host_payload),
            "latest_turn_state": latest_turn_state,
            "accepted_pv": binding["accepted_pv"],
            "pointer_generation": binding["pointer_generation"],
            "resume_same_plan_task_id": binding["plan_task_id"],
            "resume_same_row_required": True,
            "active_task_transitioned": False,
            "source_mutated": False,
            "candidate_created_or_accepted": False,
            "pointer_moved": False,
            "hil_inferred": False,
            "private_reasoning_stored": False,
            "emitted_at": _now(),
        }
        receipt["exit_slip_sha256"] = sha256_bytes(canonical_json_bytes(receipt))
        atomic_write_json(exit_path, receipt)
        state = "SEALED"
    event_id = "evt_" + sha256_bytes(
        (str(receipt["exit_slip_sha256"]) + "\0lifecycle-exit").encode("utf-8")
    )[:26].lower()
    telemetry = _response_telemetry(host_payload)
    lineage_event = ChatLineage(
        project_root / "lineage" / f"{binding['evidence_session_id']}.jsonl"
    ).append(
        event_type="turn.lifecycle_exit_slip",
        visible_payload=receipt,
        occurred_at=str(receipt["emitted_at"]),
        session_id=binding["evidence_session_id"],
        task_id=binding["task_id"],
        event_id=event_id,
        actor_type="system",
        model=telemetry["model"],
        submodel=telemetry["submodel"],
        token_metrics=telemetry["token_metrics"],
    )
    return {
        "status": "PASS",
        "state": state,
        "receipt": receipt,
        "exit_slip_path": str(exit_path),
        "lineage_event_sha256": lineage_event["event_sha256"],
    }


def session_start_control(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
) -> dict[str, Any]:
    """Bind one strict host session and visibly recover every uncommitted PREPARE."""

    started_ns = time.perf_counter_ns()
    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    _require(
        bool(host_session_id),
        "TURN_CONTROL_HOST_SESSION_ID_REQUIRED",
        "SessionStart requires the exact governed host-session identity.",
    )
    policy = policy_state(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    _require(
        policy.get("governed_session") is True
        and policy.get("strict_required") is True,
        "TURN_CONTROL_POLICY_NOT_ACTIVE",
        "The exact governed session has not activated strict Mode plus Plan turn control.",
        policy=policy,
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
    )
    binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    live_source_snapshot = _source_change_snapshot(
        root,
        binding=binding,
        cwd=str(host_payload.get("cwd") or ""),
    )
    recovered: list[dict[str, Any]] = []
    with _control_lock(project_root):
        with _connection(project_root) as connection:
            rows = connection.execute(
                """
                SELECT e.record_json
                FROM turn_entry e
                LEFT JOIN turn_commit c
                  ON c.control_record_sha256=e.control_record_sha256
                WHERE e.project_id=? AND e.evidence_session_id=?
                  AND c.commit_sha256 IS NULL
                ORDER BY e.prompt_index
                """,
                (binding["project_id"], binding["evidence_session_id"]),
            ).fetchall()
            latest_rows = connection.execute(
                """
                SELECT e.record_json AS entry_json, c.commit_json AS commit_json
                FROM turn_entry e
                LEFT JOIN turn_commit c
                  ON c.control_record_sha256=e.control_record_sha256
                WHERE e.project_id=? AND e.evidence_session_id=?
                ORDER BY e.prompt_index DESC
                """,
                (
                    binding["project_id"],
                    binding["evidence_session_id"],
                ),
            ).fetchall()
            latest_row = next(
                (
                    row
                    for row in latest_rows
                    if json.loads(row["entry_json"]).get("task_id")
                    == binding["task_id"]
                ),
                None,
            )
        lineage_path = (
            project_root / "lineage" / f"{binding['evidence_session_id']}.jsonl"
        )
        lineage = ChatLineage(lineage_path)
        for row in rows:
            entry = json.loads(row["record_json"])
            claimed = str(entry.get("control_record_sha256") or "")
            _require(
                claimed
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            key: value
                            for key, value in entry.items()
                            if key != "control_record_sha256"
                        }
                    )
                ),
                "TURN_CONTROL_RECORD_MISMATCH",
                "An uncommitted PREPARE failed its SHA-256 verification.",
            )
            _require(
                entry.get("binding_sha256") == binding.get("binding_sha256"),
                "TURN_CONTROL_BINDING_DRIFT",
                "An uncommitted PREPARE no longer matches the exact project, pointer, Mode, or Plan binding.",
                control_record_sha256=claimed,
            )
            prepare_projection = _project_prepared_entry(
                root,
                project_root=project_root,
                entry=entry,
            )
            recovery_event_id = (
                "evt_"
                + sha256_bytes(
                    (claimed + "\0prepared-not-committed-recovery").encode("utf-8")
                )[:26].lower()
            )
            recovery_event = lineage.append(
                event_type="turn.control_recovery",
                visible_payload={
                    "state": "PREPARED_NOT_COMMITTED",
                    "recovery_action": "VISIBLE_REPLAY_SAFE_HOLD",
                    "turn_id": entry["turn_id"],
                    "input_kind": entry["input_kind"],
                    "prompt_index": entry["prompt_index"],
                    "control_record_sha256": claimed,
                    "prepare_lineage_event_sha256": prepare_projection[
                        "prepare_lineage_event_sha256"
                    ],
                    "source_mutation_authorized": False,
                    "automatic_commit_inferred": False,
                    "private_reasoning_excluded": True,
                },
                occurred_at=entry["prepared_at"],
                session_id=binding["evidence_session_id"],
                task_id=binding["task_id"],
                event_id=recovery_event_id,
                actor_type="system",
            )
            recovered.append(
                {
                    "turn_id": entry["turn_id"],
                    "input_kind": entry["input_kind"],
                    "prompt_index": entry["prompt_index"],
                    "control_record_sha256": claimed,
                    "recovery_lineage_event_sha256": recovery_event["event_sha256"],
                    "state": "PREPARED_NOT_COMMITTED",
                }
            )
        projection = lineage.projection_status()
    latest_entry = (
        json.loads(latest_row["entry_json"]) if latest_row is not None else None
    )
    latest_commit = (
        json.loads(latest_row["commit_json"])
        if latest_row is not None and latest_row["commit_json"]
        else None
    )
    entry_source_snapshot = (
        dict(latest_entry.get("source_change_entry") or live_source_snapshot)
        if latest_entry is not None
        else live_source_snapshot
    )
    warm_attach_receipt = _warm_attach_receipt(
        root,
        bound=bound,
        binding=binding,
        host_session_id=host_session_id,
        started_ns=started_ns,
    )
    persistent_change_display = _persistent_change_display(
        binding=binding,
        source_snapshot=live_source_snapshot,
        turn_state=(
            "PREPARED_NOT_COMMITTED"
            if latest_entry is not None and latest_commit is None
            else "COMMITTED"
            if latest_commit is not None
            else "NO_RECORDED_TURN"
        ),
        prompt_index=(
            int(latest_entry["prompt_index"]) if latest_entry is not None else None
        ),
        uncommitted_count=len(recovered),
        changed_since_prepare=(
            entry_source_snapshot["worktree_sha256"]
            != live_source_snapshot["worktree_sha256"]
            if latest_entry is not None
            else None
        ),
        warm_attach_receipt=warm_attach_receipt,
    )
    return {
        "state": (
            "RECOVERED_PREPARED_NOT_COMMITTED"
            if recovered
            else "BOUND_NO_UNCOMMITTED_TURNS"
        ),
        "schema": "evidence-lane.codex-session-turn-control.v1",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "host_session_id_sha256": sha256_bytes(host_session_id.encode("utf-8")),
        "binding_sha256": binding["binding_sha256"],
        "accepted_pv": binding["accepted_pv"],
        "pointer_generation": binding["pointer_generation"],
        "persistent_plan_row": binding["persistent_plan_row"],
        "uncommitted_count": len(recovered),
        "uncommitted": recovered,
        "lineage_projection": projection,
        "warm_attach_receipt": warm_attach_receipt,
        "persistent_change_display": persistent_change_display,
        "scrollback_authority": False,
        "transcript_authority": False,
        "private_reasoning_stored": False,
    }


def current_persistent_change_display(
    store_root: str | Path,
    *,
    host_payload: dict[str, Any],
) -> dict[str, Any]:
    """Read the current Plan/Delta/source display without advancing lifecycle state.

    This projection exists for PostToolUse because a user can steer a running
    Goal without creating a fresh UserPromptSubmit event.  It deliberately reads
    no tool input, tool output, prompt text, assistant response, or transcript.
    """

    root = Path(store_root).resolve()
    host_session_id = str(host_payload.get("session_id") or "").strip()
    _require(
        bool(host_session_id),
        "TURN_CONTROL_HOST_SESSION_ID_REQUIRED",
        "PostToolUse projection requires the exact governed host-session identity.",
    )
    policy = policy_state(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
        transcript_path=str(
            host_payload.get("transcript_path")
            or host_payload.get("agent_transcript_path")
            or ""
        ),
    )
    _require(
        policy.get("governed_session") is True
        and policy.get("strict_required") is True,
        "TURN_CONTROL_POLICY_NOT_ACTIVE",
        "The exact governed session has not activated strict Mode plus Plan turn control.",
        policy=policy,
    )
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id,
        cwd=str(host_payload.get("cwd") or ""),
        transcript_path=str(
            host_payload.get("transcript_path")
            or host_payload.get("agent_transcript_path")
            or ""
        ),
    )
    binding = _binding_snapshot(root, bound)
    project_root = Path(bound["project_root"])
    live_source_snapshot = _source_change_snapshot(
        root,
        binding=binding,
        cwd=str(host_payload.get("cwd") or ""),
    )
    relevant: list[tuple[dict[str, Any], dict[str, Any] | None]] = []
    database = project_root / "lineage" / "codex_turn_control.sqlite"
    if database.is_file():
        connection = _read_only(database)
        try:
            rows = connection.execute(
                """
                SELECT e.record_json AS entry_json, c.commit_json AS commit_json
                FROM turn_entry e
                LEFT JOIN turn_commit c
                  ON c.control_record_sha256=e.control_record_sha256
                WHERE e.project_id=? AND e.evidence_session_id=?
                ORDER BY e.prompt_index DESC
                """,
                (binding["project_id"], binding["evidence_session_id"]),
            ).fetchall()
        finally:
            connection.close()
        for row in rows:
            entry = json.loads(row["entry_json"])
            if entry.get("task_id") != binding["task_id"]:
                continue
            commit = json.loads(row["commit_json"]) if row["commit_json"] else None
            relevant.append((entry, commit))
    latest_entry, latest_commit = relevant[0] if relevant else (None, None)
    uncommitted_count = sum(commit is None for _, commit in relevant)
    entry_source_snapshot = (
        dict(latest_entry.get("source_change_entry") or live_source_snapshot)
        if latest_entry is not None
        else live_source_snapshot
    )
    display = _persistent_change_display(
        binding=binding,
        source_snapshot=live_source_snapshot,
        turn_state=(
            "PREPARED_NOT_COMMITTED"
            if latest_entry is not None and latest_commit is None
            else "COMMITTED"
            if latest_commit is not None
            else "NO_RECORDED_TURN"
        ),
        prompt_index=(
            int(latest_entry["prompt_index"]) if latest_entry is not None else None
        ),
        uncommitted_count=uncommitted_count,
        changed_since_prepare=(
            entry_source_snapshot["worktree_sha256"]
            != live_source_snapshot["worktree_sha256"]
            if latest_entry is not None
            else None
        ),
    )
    tool_name = str(host_payload.get("tool_name") or "").strip() or None
    tool_use_id = str(host_payload.get("tool_use_id") or "").strip()
    core = {
        "schema": "evidence-lane.codex-persistent-change-tool-projection.v1",
        "state": "PROJECTED_READ_ONLY_AFTER_TOOL_USE",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "tool_name": tool_name,
        "tool_use_id_sha256": (
            sha256_bytes(tool_use_id.encode("utf-8")) if tool_use_id else None
        ),
        "persistent_change_display": display,
        "read_only_projection": True,
        "tool_input_stored": False,
        "tool_response_stored": False,
        "transcript_read": False,
        "source_mutated": False,
        "candidate_created_or_accepted": False,
        "pointer_moved": False,
        "hil_inferred": False,
        "private_reasoning_stored": False,
    }
    core["projection_sha256"] = sha256_bytes(canonical_json_bytes(core))
    return core


def project_task_research_status(
    store_root: str | Path,
    *,
    host_session_id: str,
    cwd: str,
) -> dict[str, Any]:
    """Read only the exact bound project's current task research/usage ledger."""

    root = Path(store_root).resolve()
    bound = _one_bound_session(
        root,
        host_session_id=host_session_id.strip(),
        cwd=cwd,
    )
    binding = _binding_snapshot(root, bound)
    database = Path(bound["project_root"]) / "lineage" / "codex_turn_control.sqlite"
    with _read_only(database) as connection:
        research_rows = connection.execute(
            """
            SELECT record_json FROM turn_research_question
            WHERE project_id=? AND evidence_session_id=? AND task_id=?
            ORDER BY prompt_index
            """,
            (
                binding["project_id"],
                binding["evidence_session_id"],
                binding["task_id"],
            ),
        ).fetchall()
        usage_rows = connection.execute(
            """
            SELECT record_json FROM turn_goal_usage
            WHERE project_id=? AND evidence_session_id=? AND task_id=?
            ORDER BY prompt_index
            """,
            (
                binding["project_id"],
                binding["evidence_session_id"],
                binding["task_id"],
            ),
        ).fetchall()
        leaked_research_fts = connection.execute(
            """
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='turn_research_question_fts'
            """
        ).fetchall()
        integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]

    def verified_records(
        rows: list[sqlite3.Row],
        *,
        sha_field: str,
        mismatch_code: str,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for row in rows:
            record = json.loads(row["record_json"])
            claimed = str(record.get(sha_field) or "")
            actual = sha256_bytes(
                canonical_json_bytes(
                    {key: value for key, value in record.items() if key != sha_field}
                )
            )
            _require(
                claimed == actual
                and record.get("project_id") == binding["project_id"]
                and record.get("evidence_session_id") == binding["evidence_session_id"]
                and record.get("task_id") == binding["task_id"],
                mismatch_code,
                "A project-task research ledger record failed identity or SHA-256 verification.",
            )
            records.append(record)
        return records

    research = verified_records(
        research_rows,
        sha_field="research_record_sha256",
        mismatch_code="TURN_CONTROL_RESEARCH_RECORD_MISMATCH",
    )
    usage = verified_records(
        usage_rows,
        sha_field="usage_record_sha256",
        mismatch_code="TURN_CONTROL_GOAL_USAGE_RECORD_MISMATCH",
    )
    _require(
        integrity == ["ok"] and not leaked_research_fts,
        "TURN_CONTROL_RESEARCH_SQLITE_INVALID",
        "The project-task research ledger failed integrity or private-index isolation.",
        integrity=integrity,
        leaked_research_fts=[row["name"] for row in leaked_research_fts],
    )
    final_counters: dict[str, dict[str, Any]] = {}
    for record in usage:
        observation = record.get("observation") or {}
        if (
            observation.get("availability") == "AVAILABLE"
            and observation.get("metric_semantics") == "GOAL_FINAL_COUNTER"
        ):
            final_counters[str(observation["goal_id"])] = {
                "goal_accounted_tokens": observation["goal_accounted_tokens"],
                "observation_sha256": observation["observation_sha256"],
                "usage_record_sha256": record["usage_record_sha256"],
            }
    return {
        "status": "PASS",
        "schema": "evidence-lane.project-task-private-research-status.v1",
        "project_id": binding["project_id"],
        "evidence_session_id": binding["evidence_session_id"],
        "task_id": binding["task_id"],
        "plan_task_id": binding["plan_task_id"],
        "access_scope": _PROJECT_TASK_PRIVATE_ANALYSIS,
        "research_focus": binding["research_policy"]["focus"],
        "research_questions": research,
        "goal_usage_records": usage,
        "final_goal_counters_by_goal_id": final_counters,
        "cumulative_snapshots_summed": False,
        "cross_project_retrieval": False,
        "shared_global_telemetry": False,
        "shared_fts_indexed": False,
        "public_output_included": False,
        "private_reasoning_stored": False,
        "sqlite_integrity": integrity,
    }
