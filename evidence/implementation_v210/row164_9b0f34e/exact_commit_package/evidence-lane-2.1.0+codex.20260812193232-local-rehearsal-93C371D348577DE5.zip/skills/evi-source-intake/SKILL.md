---
name: evi-source-intake
description: Evidence Lane generalized ordered source intake with optional Git history, auto-detection, exact overrides, 18 lanes, Project Engulf, and Chat Lineage.
---

# Evidence Lane Source Intake

Before any tool call, read and apply
`../evidence-lane-code-lifecycle/SKILL.md`, including its Codex hook/skill
ownership contract. This skill owns behavior; hooks provide lifecycle receipts
only.

Call `source_intake_classify` for the user's ordered sources. Auto-detect Git,
local code, SQLite/PV brains, Chat Lineage, discussion, analysis, plan, Mode,
docs, data/Excel, PPT, PDF/OCR, images/OCR, artifacts, custom, research,
Project Engulf, and SQLite Brain; accept exact per-source overrides. Always
include Chat Lineage. Classification alone copies no source, creates no
candidate, and moves no pointer.

The Git history arm is optional for source intake. `AUTO` enriches a Git
worktree with history and otherwise falls back to deterministic content
indexing; `REQUIRED` fails closed without a readable Git worktree and HEAD;
`DISABLED` skips Git history explicitly. None of these modes authorizes a
remote Git write. Use existing internal enrollment and route tools only after
the visible classification is accepted.

For a Git worktree, enumerate current sources from tracked index entries only.
Before reading exact bytes into SQLite, FTS, CAS, history, topology, or a PV
package, apply the shared source policy and exclude `.env` variants,
`.runtime`/cache/build artifacts, credential or private-key paths, configured
secret values, and recognized credential-shaped content. Never place secret
bytes or secret environment-variable names in an exclusion receipt. Non-Git
sources use the same deterministic path/content policy but do not claim a
tracked-only boundary.

## Schema-derived lane pills

When the user asks to add a new Source Intake pill, call
`source_intake_schema_configure` with `operation: ADD`, an exact visible
`pill_name`, a governed Source Intake `batch_id`, and a complete declarative
`schema_definition` whose title exactly matches the pill name and whose version
is `1`.

When the user asks to modify one, call the same tool with `operation: MODIFY`,
the next integer schema version, and `expected_previous_schema_sha256` bound to
the exact prior registered version. MODIFY is append-only: never edit or delete
the old definition, never mutate the canonical eighteen-lane registry, and
never treat schema configuration as source classification, a candidate build,
or HIL approval.

Suggested user forms:

- `/evi-source-intake ADD "<pill name>" --purpose "<need>" --schema <definition>`
- `/evi-source-intake MODIFY "<pill name>" --schema <next-version-definition> --previous-sha256 <exact-sha256>`
